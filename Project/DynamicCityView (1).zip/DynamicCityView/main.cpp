#include <windows.h>
#include <iostream>
#include <utility>
#include <GL/glut.h>
#include <math.h>
#include <string.h>
#include <vector>
using namespace std;


float moveSuntX = 0;
float moveSunY = 0;
float moveSunAngle = 0;
float moveboatX = 0;
float moveboatY = 0;
float movewatercurrentX = 0;
float moveRocketY = 0;
float rotateWheel=0;
float moveCarsX =0 ;
float moveMetroX =0 ;
float moveCarsX1 =0;
float moveCarsX2 =0;
float moveCarsX3 =0;
float movewatercurrentXs = 0;
float moveCarsXs =0 ;
float rotateWheels=0;
float moveBus = 0;
float moveBlueCar = 0;
float moveWhiteCar = 0;
float moveYellowCar = 0;
float moveRedCar = 0;


struct Custom_Color
{
    int r;
    int g;
    int b;
};

struct Scene
{
    string T_scene;
    Custom_Color skyColor;
    Custom_Color riverColor;
    Custom_Color sunColor;
    Custom_Color moonLayers;
    //boat
    Custom_Color boatColor;
    Custom_Color boatbottomColor;
    Custom_Color boatwindowColor;
    //river
    Custom_Color rivershade1Color;
    Custom_Color rivershade2Color;
    Custom_Color rivershade3Color;
    Custom_Color rivershade4Color;
    //stars
    Custom_Color starsColor;

    //Road Color
    Custom_Color roadShoulder;
    Custom_Color roadShoulder2;
    Custom_Color roadShoulder3;
    Custom_Color roadColor;
    Custom_Color roadDivider;
    Custom_Color roadPier1;
    Custom_Color roadPier2;
    Custom_Color roadShadow;
    Custom_Color landColor;
    Custom_Color landColor2;
    Custom_Color groundColor1;
    Custom_Color groundColor2;
    Custom_Color groundColor3;

    // Rocket Color
    Custom_Color rocketGround;
    Custom_Color rocketGround2;
    Custom_Color rocketTower1;
    Custom_Color rocketTower2;
    Custom_Color rocketBody;
    Custom_Color rocketBody2;
    Custom_Color rocketHead;
    Custom_Color rocketHead2;

    //hill
    Custom_Color hillColor;
    Custom_Color hillColor1;
    Custom_Color hillShadow;
    Custom_Color hillShadow1;
    Custom_Color hillShadow2;
    Custom_Color hillShadow3;
    Custom_Color hillShadow4;

    //house
    Custom_Color houseWindow;
    Custom_Color house11;
    Custom_Color house1;
    Custom_Color houseDoor;
    Custom_Color houseTop1;
    Custom_Color houseTop11;
    Custom_Color houseSide1;
    Custom_Color houseLines;
    Custom_Color house2;
    Custom_Color house2Side;
    Custom_Color house2WindowBorder;
    Custom_Color house2Door;
    Custom_Color house3;
    Custom_Color house33;
    Custom_Color house3Side;
    Custom_Color house3Top1;
    Custom_Color house3Top2;
    Custom_Color house3DoorParking;
    Custom_Color house4;
    Custom_Color house44;
    Custom_Color house4Side;
    Custom_Color house4ParkingDoor;
    Custom_Color house4Door;
    Custom_Color house4top;
    Custom_Color house4TopSide;
    Custom_Color house5;
    Custom_Color house55;
    Custom_Color house5top;
    Custom_Color houseLand;
    Custom_Color houseLandShadow;
    Custom_Color houseRoad;

    //cars
    Custom_Color car1Body;
    Custom_Color car1Window;
    Custom_Color car1WindowLine;
    Custom_Color car1Tyre;
    Custom_Color car1TyreUp;
    Custom_Color car1Light;

    Custom_Color car2Body;
    Custom_Color car2Body2;
    Custom_Color car2Window;
    Custom_Color car2Tyre;
    Custom_Color car2Light;

    Custom_Color car3Body;
    Custom_Color car3seat;
    Custom_Color car3Light;

    Custom_Color rightCar1Body;
    Custom_Color rightCar2Body;
    Custom_Color rightCar3Body;

    Custom_Color metroLinesUp;
    Custom_Color metroLinesDown;
    Custom_Color metroBody;
    Custom_Color metroBodyLine;
    Custom_Color metroWindow;
    Custom_Color metroWindowlines;
    Custom_Color metroMiddleJoin;


    //sewview
    Custom_Color sbwaterColor;

    Custom_Color sbbackground;  // sky
    Custom_Color sbbackground2; // white
    Custom_Color sbtreeColor;   // tree
    Custom_Color sbbuilding1;
    Custom_Color sbbuildingd;
    Custom_Color sbbuildingd2;
    Custom_Color sbbuildingd3;
    Custom_Color sbbuildingd4;
    Custom_Color sbbuildingd5;
    Custom_Color sbwindow1;
    Custom_Color sbbuilding2;
    Custom_Color sbbuilding3; // white
    Custom_Color sbwindow2;   // white
    Custom_Color sbwindow3;   // cyn
    Custom_Color sbumbrella;  // red
    Custom_Color sbseat;      // seat
    Custom_Color sbbuilding5; // red
    Custom_Color sbbuilding6; // yellow

    Custom_Color sbbuilding7; // pink
    Custom_Color sbbuilding7u;
    Custom_Color sbtreeu;      // treeu
    Custom_Color sbtreeColoro; // treeColor2
    Custom_Color sbtreeColor2; // treeColor2
    Custom_Color sbcloud;      // sbcloud
    Custom_Color sbroad;       // Road
    Custom_Color sbtreeColor3; // Green

    Custom_Color sbshop3; // orange
    Custom_Color sbshopf; // orange2f

    Custom_Color sbshop3b;  // table
    Custom_Color sbmosque;  // mosque
    Custom_Color sbmosquew; // mosquewindow
    Custom_Color sbmoon;    // mosquewindow
    Custom_Color sbstar;    // mosquewindow


};

Scene Day =
{
    "Day",
    {133, 193, 233},      //skycolor
    {68,121,207},       //rivercolor
    {241, 196, 15},    //sunColor
    {241, 196, 15},      //moonLayers
    //boat
    {255, 255, 255},    //boatcolor
    {39,30,73},         //boatbottomcolor
    {107,111,116},      //boatwindowcolor
    //river
    {61, 109, 186},     //rivershade1color
    {54,102,192},       //rivershade2color
    {33, 59, 122},      //rivershade3color
    {110,161,233},      //rivershade4color
    //stars
    {133, 193, 233},    //starscolor

    //Road Color
    {183, 183, 183},     //roadShoulder
    {200, 200, 200},     //roadShoulder2
    {160, 160, 160},     //roadShoulder3
    {102, 104, 103},     //roadColor
    {255, 230, 81},      //roadBorder;
    {183, 183, 183},     //roadPier1
    {148, 148, 146},     //roadPier2
    {84, 84, 84},        //roadShadow
    //land
    {114, 109, 0},     //landColor
    {151, 105, 71},      //landColor2
    {180, 122, 79},       // groundColor1;
    {73, 26, 10},       //groundColor2;
    {115, 66, 35},         //groundColor3;

    //Rocket Color
    {0, 0, 0},  //rockeGround;
    {117, 133, 88},  //rockeGround2;
    {64, 64, 66}, //rockeTower1;
    {148, 149, 153}, //rockeTower2;
    {255, 255, 255}, //rockeBody;
    {177, 188, 189}, //rockeBody2;
    {178, 76, 34}, //rocketHead;
    {247, 177, 129}, //rocketHead2;

    //hill
    {129, 136, 118}, //hillColor
    {120, 127, 49},//hillColor1
    {145, 192, 164},  //hillShadow;
    {163, 219, 192},   //hillShadow1;
    {86, 84, 61},   //hillShado2;
    {55, 63, 22},   //hillShado3;
    {111, 117, 47},   //hillShado4fronthill;

    //house
    {133, 97, 176},    //houseWindows
    {247, 183, 171},  //house1
    {251, 218, 203},  //house11
    {165, 177, 245},   //housedor
    {112, 35, 53},   //houseTop1
    {154, 64, 89},   ////houseTop11
    {197, 147, 174},  //houseSide1
    {230, 234, 231},  //houseLines

    {113, 176, 160},  //house2
    {32, 71, 100},  //house2Side
    {213, 214, 244},  //house2windowborder
    {164, 62, 49},  //house2door
    {225, 130, 48}, //house3;
    {248, 165, 79}, //house33;
    {165, 50, 59}, //house3Side;
    {64, 66, 1},   //houseTop3;
    {131, 135, 51},   //houseTop33;
    {240, 231, 226},  //house3DoorParking;
    {237, 71, 70},   //house4
    {245, 99, 86}, //house44;
    {126, 30, 56}, //house4side;
    {255, 179, 162}, //house4parkingdoor;
    {100, 28, 28}, //house4door
    {63, 39, 65},   //house4top
    {51, 27, 53},  //house4TopSide
    {119, 177, 237}, //house5;
    {141, 201, 235}, //house55;
    {63, 45, 97}, //house5top;
    {167, 146, 0}, //houseLand;
    {67, 16, 43},  //houseLandshadow;
    {230, 182, 136}, //houseRoad;

    //cars
    {210, 214, 223}, //car1Body;
    {66, 90, 90}, //car1Window;
    {46, 48, 47}, //carWindowLine
    {73, 79, 79}, //car1Tyre;
    {25, 2, 3}, //car1TyreUp;
    {189, 68, 85}, //car1Light;

    {255, 131, 59},  //car2Body;
    {115, 110, 104},  //car2Body2;
    {125, 117, 128},  //car2Window;
    {86, 86, 86},  //car2Tyre;
    {195, 245, 244}, //car2Light;

    {195, 32, 38}, //car3Body;
    {2, 2, 2}, //car3seat;
    {254, 254, 254}, //car3Light;

    {74, 106, 145},  //rightCar1Body;
    {227, 155, 36},  //rightCar2Body;
    {62, 63, 74},  //rightCar3Body;

    //metrotrain
    {206, 206, 204}, //metroLinesUp;
    {157, 158, 150}, //metroLinesDown;
    {14,120,100}, //metroBody;
    {241, 236, 242}, //metroBodyLine;
    {149, 210, 232}, //metroWindow;
    {246, 193, 194}, //metroWindowlines;
    {153, 132, 128}, //metroMiddleJoin;


    //seaview
     {43, 241, 241}, // watercolor

        {12, 245, 242},  // sky
        {176, 205, 214}, // background2
        {54, 173, 56},   // treecolor

        {190, 122, 24}, // building1
        {100, 70, 25},  // buildingd
        {100, 70, 25},  // buildingd2
        {100, 70, 25},  // buildingd3
        {100, 70, 25},  // buildingd4
        {100, 70, 25},  // buildingd5
        {44, 151, 173}, // window1

        {213, 210, 79},  // building2
        {230, 241, 240}, // building3
        {49, 125, 122},  // sbwindow2
        {142, 145, 145}, // sbwindow3
        {91, 115, 100},  // umbrella
        {114, 137, 143}, // sbseat

        {155, 0, 0}, // umbrella

        {221, 208, 57},  // sbbuilding6
        {249, 123, 208}, // sbbuilding7
        {207, 48, 157},  // sbbuilding7u

        {143, 111, 73},  // sbtreeu
        {15, 54, 14},    // sbtreeColoro
        {48, 166, 50},   // sbtreeColor2
        {242, 238, 237}, // sbcloud
        {105, 100, 100}, // sbroad
        {50, 107, 43},   // sbtreeColor3
        {217, 155, 30},  // shop3 orange
        {158, 115, 36},  // sbshopf

        {163, 141, 96},  // shop3b
        {159, 186, 189}, // sbmosque
        {223, 247, 247}, // sbmosquew
        {12, 245, 242},  // sbmoon
        {12, 245, 242},  // sbstar




};

Scene Night =
{
    "Night",
    {48, 89, 124},      //skycolor
    {21, 67, 96},       //rivercolor
    {211, 212, 222},    //planetcolor
    {179, 196, 204},      //planetlayers
    //boat
    {23, 32, 42},    //boatcolor
    {28, 40, 51},         //boatbottomcolor
    {241, 196, 15},      //boatwindowcolor
    //river
    {36, 113, 163},     //rivershade1color
    {26, 82, 118},       //rivershade2color
    {33, 59, 122},      //rivershade3color
    {84, 153, 199},      //rivershade4color
    //stars
    {255, 255, 255},    //starscolor

    // Road Color
    {43, 43, 43},     //roadShoulder
    {112, 35, 53},     //roadShoulder2
    {43, 43, 43},     //roadShoulder3
    {32, 24, 20},     //roadColor
    {255, 230, 81},      //roadBorder;
    {43, 43, 43},     //roadPier1
    {32, 24, 20},     //roadPier2
    {32, 24, 20},     //roadShadow

    //land
    {36,83,16},     //landColor
    {172, 98, 58},     //landColor2
    {122, 84, 83},       // groundColor1;
    {73, 26, 10},       //groundColor2;
    {131, 86, 80},         //groundColor3;

    // Rocket Color
    {0, 0, 0},  //rockeGround;
    {117, 133, 88},  //rockeGround2;
    {64, 64, 66}, //rockeTower1;
    {148, 149, 153}, //rockeTower2;
    {28, 40, 51}, //rockeBody;
    {112, 35, 53}, //rockeBody2;
    {178, 76, 34}, //rocketHead;
    {241, 196, 15}, //rocketHead2;

    //hill
    {32, 24, 20}, //hillColor
    {37, 31, 67}, //hillColor1
    {0, 0, 0},  //hillShadow;
    {0, 0, 0},   //hillShadow1;
    {0, 0, 0},   //hillShado2;
    {0, 0, 0},   //hillShado3;
    {32, 24, 20},   //hillShado4fronthill;

    //house
    {241, 196, 15},    //houseWindows
    {112, 35, 53},  //house1
    {112, 35, 53},  //house11
    {165, 177, 245},   //housedor
    {112, 35, 53},   //houseTop1
    {154, 64, 89},   ////houseTop11
    {154, 64, 89},  //houseSide1
    {43, 43, 43},  //houseLines
    {154, 64, 89},  //house2
    {112, 35, 53},  //house2Side
    {213, 214, 244},  //house2windowborder
    {164, 62, 49},  //house2door

    {154, 64, 89}, //house3;
    {112, 35, 53},//house33;
    {165, 50, 59}, //house3Side;
    {64, 66, 1},   //houseTop3;
    {112, 35, 53},   //houseTop33;
    {112, 35, 53},  //house3DoorParking;

    {112, 35, 53},   //house4
    {154, 64, 89}, //house44;
    {126, 30, 56}, //house4side;
    {154, 64, 89}, //house4parkingdoor;
    {100, 28, 28}, //house4door
    {63, 39, 65},   //house4top
    {51, 27, 53},  //house4TopSide

    {119, 177, 237}, //house5;
    {141, 201, 235}, //house55;
    {63, 45, 97}, //house5top;

    {40,85,20}, //houseLand;
    {36,83,16},  //houseLandshadow;
    {112, 35, 53}, //houseRoad;


    //cars
    {210, 214, 223}, //car1Body;
    {66, 90, 90}, //car1Window;
    {46, 48, 47}, //carWindowLine
    {73, 79, 79}, //car1Tyre;
    {25, 2, 3}, //car1TyreUp;
    {241, 196, 15}, //car1Light;

    {255, 131, 59},  //car2Body;
    {115, 110, 104},  //car2Body2;
    {125, 117, 128},  //car2Window;
    {86, 86, 86},  //car2Tyre;
    {241, 196, 15}, //car2Light;

    {195, 32, 38}, //car3Body;
    {2, 2, 2}, //car3seat;
    {241, 196, 15}, //car3Light;

    {74, 106, 145},  //rightCar1Body;
    {227, 155, 36},  //rightCar2Body;
    {62, 63, 74},  //rightCar3Body;

     //metroTrain
    {112, 35, 53}, //metroLinesUp;
    {32, 24, 20}, //metroLinesDown;
    {64, 64, 66}, //metroBody;
    {43, 43, 43}, //metroBodyLine;
    {241, 196, 15}, //metroWindow;
    {43, 43, 43}, //metroWindowlines;
    {153, 132, 128}, //metroMiddleJoin;


    //seaview
           {25, 56, 50},    // watercolor
        {25, 56, 50},    // skycolor
        {209, 198, 178}, // background2
        {27, 54, 22},    // treecolor
        {12, 13, 12},    // building1
        {12, 13, 12},    // buildingd
        {125, 103, 25},  // buildingd2
        {125, 103, 25},  // buildingd3
        {125, 103, 25},  // buildingd4
        {125, 103, 25},  // buildingd5
        {125, 103, 25},  // window1

        {12, 13, 12},    // building2
        {125, 103, 25},  // building3
        {12, 13, 12},    // sbwindow2
        {142, 145, 145}, // sbwindow3
        {115, 114, 112}, // umbrella
        {115, 114, 112}, // sbseat

        {12, 13, 12}, // red building

        {12, 13, 12}, // sbbuilding6
        {12, 13, 12}, // sbbuilding7
        {12, 13, 12}, // sbbuilding7u

        {12, 13, 12},    // sbtreeu
        {115, 114, 112}, // sbtreeColoro
        {27, 54, 22},    // sbtreeColor2
        {25, 56, 50},    // sbcloud
        {26, 22, 22},    // sbroad
        {27, 54, 22},    // sbtreeColor3
        {115, 114, 112}, // shop3 orange
        {115, 114, 112}, // shop3 orange

        {115, 114, 112}, // shop3b
        {12, 13, 12},    // sbmosque
        {125, 103, 25},  // sbmosquew
        {219, 192, 118}, // sbmosquew

        {255, 255, 255}, // sbstar



};


Scene array[2] = {Day, Night};
int daynighttracker = 0;
Scene currentScene = array[daynighttracker];


// animations function logics

void RotateCarWheel(int val)
{
    rotateWheel -= 10;

    if(rotateWheel > 360.0)
    {
        rotateWheel -= 360;
    }
    glutPostRedisplay();
    glutTimerFunc(20, RotateCarWheel, 0);
}
void AnimateLeftCars1(int val)
{
    moveCarsX+=3;
    if (moveCarsX > 3100)
    {
        moveCarsX = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateLeftCars1, 0);
}

void AnimateCars1(int val)
{
    moveCarsX1+=4;
    if (moveCarsX1 > 3100)
    {
        moveCarsX1 = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateCars1, 0);
}
void AnimateCars2(int val)
{
    moveCarsX2+=3;
    if (moveCarsX2 > 3100)
    {
        moveCarsX2 = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateCars2, 0);
}
void AnimateCars3(int val)
{
    moveCarsX3+=4;
    if (moveCarsX3 > 3100)
    {
        moveCarsX3 = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateCars3, 0);
}
void AnimateMetroTrain(int val)
{
    moveMetroX-=3;
    if (moveMetroX < -2900)
    {
        moveMetroX = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateMetroTrain, 0);
}

void AnimateRocket(int val)
{
    moveRocketY += 1;

    if (moveRocketY > 600)
    {
        moveRocketY = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateRocket, 0);

}

void AnimateSun(int val)
{
    moveSuntX += 0.5;
    moveSunY -= 0.5;

    if (moveSunY < -600)
    {
        moveSuntX = 0;
        moveSunY = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateSun, 0);
}


void AnimateBoatLeft(int val)
{
    moveboatX -= 5;
    moveboatY += 0.4;

    if (moveboatX < -2300)
    {
        moveboatX = 0;
        moveboatY = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateBoatLeft, 0);
}


void AnimateWaterCurrentRight(int val)
{
    movewatercurrentX += 2;

    if (movewatercurrentX > 400)
    {
        movewatercurrentX = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateWaterCurrentRight, 0);

}
void AnimateWaterCurrentRights(int val)
{
    movewatercurrentXs += 2;

    if (movewatercurrentXs > 400)
    {
        movewatercurrentXs = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateWaterCurrentRights, 0);
}
void AnimateLeftCarss(int val)
{
    moveCarsXs+=3;
    if (moveCarsXs > 3100)
    {
        moveCarsXs = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, AnimateLeftCarss, 0);
}

void RotateCarWheels(int val)
{
    rotateWheels -= 10;

    if(rotateWheels > 360.0)
    {
        rotateWheels -= 360;
    }
    glutPostRedisplay();
    glutTimerFunc(20, RotateCarWheels, 0);
}

void AnimateBus(int value)
{
    moveBus-=3;
    if(moveBus < -1300)
    {

        moveBus=0;
    }
    glutPostRedisplay();
    glutTimerFunc(20,AnimateBus,0);
}

void AnimateBlueCar(int value)
{
    moveBlueCar-=3;
    if(moveBlueCar < -1300)
    {

        moveBlueCar=300;
    }
    glutPostRedisplay();
    glutTimerFunc(20,AnimateBlueCar,0);
}
void AnimateRedCar(int value)
{
    moveRedCar+=3;
    if(moveRedCar > 300)
    {

        moveRedCar=-900;
    }
    glutPostRedisplay();
    glutTimerFunc(20,AnimateRedCar,0);
}

void AnimateWhiteCar(int value)
{
    moveWhiteCar+=4;
    if(moveWhiteCar > 1500)
    {

        moveWhiteCar=-700;
    }
    glutPostRedisplay();
    glutTimerFunc(20,AnimateWhiteCar,0);
}
void AnimateYellowCar(int value)
{
    moveYellowCar+=3;
    if(moveYellowCar > 2000)
    {

        moveYellowCar=-400;
    }
    glutPostRedisplay();
    glutTimerFunc(20,AnimateYellowCar,0);
}

class MainView
{
// Custom Functions
void Custom_Points1(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float x = 0, float y = 0, float s = 1)
{
    glPointSize(2);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(x + s * coord[i].first, y + s * coord[i].second);
    }
    glEnd();
}

void Custom_Points2(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float x = 0, float y = 0, float s = 1)
{
    glPointSize(4);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(x + s * coord[i].first, y + s * coord[i].second);
    }
    glEnd();
}

void Custom_Points3(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float x = 0, float y = 0, float s = 1)
{
    glPointSize(10);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(x + s * coord[i].first, y + s * coord[i].second);
    }
    glEnd();
}

void Custom_Polygon(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float x = 0, float y = 0)
{
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POLYGON);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(x +  coord[i].first, y +  coord[i].second);
    }
    glEnd();
}
/*
void Custom_Polygon2(float XStart,float YStart, float Tx , float Ty , Custom_Color Custom_Color = {255,255,255})
{
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POLYGON);
    glVertex2f(XStart,YStart);
    for (int i = 0; i < 3; i++) {
        if(i==0)
            glVertex2f(Tx+XStart, YStart);
        else if(i==1)
            glVertex2f(Tx+XStart, Ty+YStart);
        else
            glVertex2f(XStart, Ty+YStart);
    }
    glEnd();
}*/
void Custom_Polygon(vector<pair<float, float>> coord, float XSize, float YSize, Custom_Color Custom_Color = {255,255,255}, float x = 0, float y = 0)
{
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POLYGON);
    glVertex2f(coord[0].first+x,coord[0].second+y);
    for (int i = 0; i < 3; i++)
    {
        if(i==0)
            glVertex2f(XSize +  coord[0].first+x,coord[0].second+y);
        else if(i==1)
            glVertex2f(XSize +  coord[0].first+x, YSize +  coord[0].second+y);
        else
            glVertex2f(coord[0].first+x, YSize +  coord[0].second+y);
    }
    glEnd();
}



void Halfcircle(float radius, float xC, float yC, Custom_Color Custom_Color = {255,255,255})
{
    glBegin(GL_POLYGON);
    for(int i=0; i<250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+xC, y+yC);
    }
    glEnd();
}
void Halfcircle(float radius, float xC, float yC,float xS,float yS, Custom_Color Custom_Color = {255,255,255})
{
    glBegin(GL_POLYGON);
    for(int i=0; i<250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = xS*r * cos(A);
        float y = yS*r * sin(A);
        glVertex2f(x+xC, y+yC);
    }
    glEnd();
}


void HalfcircleWithLines(float radius, float xC, float yC, Custom_Color Custom_Color = {255,255,255})
{
    glPointSize(0.5);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POINTS);
    for(int i=0; i<250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+xC, y+yC);
    }
    glEnd();
}

void FullcircleWithLines(float radius, float xC, float yC, Custom_Color Custom_Color = {255,255,255})
{
    glPointSize(0.5);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POINTS);
    for(int i=0; i<250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 3.1416;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+xC, y+yC);
    }
    glEnd();
}


void HalfcircleBorder(float radius, float xC, float yC, Custom_Color Custom_Color = {255,255,255})
{
    glPointSize(0.1);
    glBegin(GL_POINTS);
    for(int i=0; i<250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+xC, y+yC);
    }
    glEnd();
}



void Fullcircle(float radius, float xC, float yC, Custom_Color Custom_Color = {255,255,255})
{
    glBegin(GL_POLYGON);
    for(int i=0; i<250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 3.1416;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+xC, y+yC);
    }
    glEnd();
}

void FullcircleBorder(float radius, float xC, float yC, Custom_Color Custom_Color = {255,255,255})
{
    glLineWidth(3);
    glBegin(GL_LINES);
    for(int i=0; i<250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 3.1416;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+xC, y+yC);
    }
    glEnd();
}


void Linestrip(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float x = 0, float y = 0, float s = 1)
{
    glLineWidth(1);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_LINE_STRIP);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(x + s * coord[i].first, y + s * coord[i].second);
    }
    glEnd();
}

void Linestrip(vector<pair<float, float>> coord,float XSize, float YSize, Custom_Color Custom_Color = {255,255,255},float lineWidth=1, float x = 0, float y = 0)
{
    glLineWidth(lineWidth);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_LINE_STRIP);
    glVertex2f(coord[0].first+x,coord[0].second+y);
    for (int i = 0; i < 5; i++)
    {
        if(i==0)
            glVertex2f(coord[0].first+x,coord[0].second+y);
        else if(i==1)
            glVertex2f(XSize +  coord[0].first+x,coord[0].second+y);
        else if(i==2)
            glVertex2f(XSize +  coord[0].first+x, YSize +  coord[0].second+y);
        else if(i==3)
            glVertex2f(coord[0].first+x, YSize +  coord[0].second+y);
        else
            glVertex2f(coord[0].first+x,coord[0].second+y);
    }
    glEnd();
}

void Linestrip2(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255},float lineWidth=1, float x = 0, float y = 0, float s = 1)
{
    glLineWidth(lineWidth);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_LINE_STRIP);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(x + s * coord[i].first, y + s * coord[i].second);
    }
    glEnd();
}



// Project functions

void MetroTrain()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    //glTranslatef(-400,0,0);
    glTranslatef(moveMetroX+800,0,0);
    Custom_Polygon({{1310, 708}},350,55,currentScene.metroBody);
    Custom_Polygon({{1310, 765},{1286, 720},{1286, 708},{1310, 708}},currentScene.metroBody);
    Custom_Polygon({{1305, 752},{1310, 752},{1310, 727},{1293, 727}},currentScene.metroWindow);

    Linestrip2({{1356, 768},{1344, 774},{1356, 780}},currentScene.rocketGround,2);
    Linestrip2({{1330, 766},{1380, 766}},currentScene.metroBody,4);
    Linestrip2({{1356, 768},{1344, 774},{1356, 780}},currentScene.rocketGround,2,130);
    Linestrip2({{1330, 766},{1380, 766}},currentScene.metroBody,4,130);
    Linestrip2({{1356, 768},{1344, 774},{1356, 780}},currentScene.rocketGround,2,260);
    Linestrip2({{1330, 766},{1380, 766}},currentScene.metroBody,4,260);
    Linestrip2({{1356, 768},{1344, 774},{1356, 780}},currentScene.rocketGround,2,360);
    Linestrip2({{1356, 768},{1344, 774},{1356, 780}},currentScene.rocketGround,2,490);
    Linestrip2({{1356, 768},{1344, 774},{1356, 780}},currentScene.rocketGround,2,620);

    Linestrip2({{1286, 715},{1660,715}},currentScene.metroBodyLine,3);
    Linestrip2({{1308, 763},{1660,763}},currentScene.metroBodyLine,3);
    Linestrip({{1315, 708}},15,44,currentScene.metroWindowlines,2);
    Custom_Polygon({{1318,730}},9,18,currentScene.metroWindow);

    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2);//leftDoor
    Linestrip2({{1360, 708},{1360,755}},currentScene.metroBody,2);//leftdoor
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow);//leftdoor

    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,20);
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,20);

    Custom_Polygon({{1385, 725}},32,25,currentScene.metroWindow);//window


    glPushMatrix();
    glTranslated(83,0,0);
    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2);//leftDoor
    Linestrip2({{1360, 708},{1360,755}},currentScene.metroBody,2);//leftdoor
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow);//leftdoor

    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,20);
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,20);

    Custom_Polygon({{1385, 725}},32,25,currentScene.metroWindow);//window
    glPopMatrix();

    glPushMatrix();
    glTranslated(166,0,0);
    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2);//leftDoor
    Linestrip2({{1360, 708},{1360,755}},currentScene.metroBody,2);//leftdoor
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow);//leftdoor
    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,20);
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,20);

    Custom_Polygon({{1385, 725}},32,25,currentScene.metroWindow);//window

    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,82);//leftDoor
    Linestrip2({{1360, 708},{1360,755}},currentScene.metroBody,2,82);//leftdoor
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,82);//leftdoor
    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,102);
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,102);

    Custom_Polygon({{1385, 725}},20,25,currentScene.metroWindow,82);//window
    glPopMatrix();


   Custom_Polygon({{1660, 712}},10,48,currentScene.metroMiddleJoin);
   Linestrip2({{1663, 712},{1663,760}},currentScene.metroBody,2);
   Linestrip2({{1667, 712},{1667,760}},currentScene.metroBody,2);



    //right Side train

    glPushMatrix();
    //glTranslatef(-500,0,0);
    glScalef(-1,1,1);
    glTranslatef(-3330,0,0);
    //glTranslatef(moveMetroX,0,0);
    Custom_Polygon({{1310, 708}},350,55,currentScene.metroBody);
    Custom_Polygon({{1310, 765},{1286, 720},{1286, 708},{1310, 708}},currentScene.metroBody);
    Custom_Polygon({{1305, 752},{1310, 752},{1310, 727},{1293, 727}},currentScene.metroWindow);

    Linestrip2({{1330, 766},{1380, 766}},currentScene.metroBody,4);
    Linestrip2({{1330, 766},{1380, 766}},currentScene.metroBody,4,130);
    Linestrip2({{1330, 766},{1380, 766}},currentScene.metroBody,4,260);

    Linestrip2({{1286, 715},{1660,715}},currentScene.metroBodyLine,3);
    Linestrip2({{1308, 763},{1660,763}},currentScene.metroBodyLine,3);
    Linestrip({{1315, 708}},15,44,currentScene.metroWindowlines,2);
    Custom_Polygon({{1318,730}},9,18,currentScene.metroWindow);

    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2);//leftDoor
    Linestrip2({{1360, 708},{1360,755}},currentScene.metroBody,2);//leftdoor
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow);//leftdoor

    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,20);
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,20);

    Custom_Polygon({{1385, 725}},32,25,currentScene.metroWindow);//window


    glPushMatrix();
    glTranslated(83,0,0);
    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2);//leftDoor
    Linestrip2({{1360, 708},{1360,755}},currentScene.metroBody,2);//leftdoor
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow);//leftdoor

    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,20);
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,20);

    Custom_Polygon({{1385, 725}},32,25,currentScene.metroWindow);//window
    glPopMatrix();

    glPushMatrix();
    glTranslated(166,0,0);
    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2);//leftDoor
    Linestrip2({{1360, 708},{1360,755}},currentScene.metroBody,2);//leftdoor
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow);//leftdoor
    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,20);
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,20);

    Custom_Polygon({{1385, 725}},32,25,currentScene.metroWindow);//window

    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,82);//leftDoor
    Linestrip2({{1360, 708},{1360,755}},currentScene.metroBody,2,82);//leftdoor
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,82);//leftdoor
    Linestrip({{1342, 708}},16,44,currentScene.metroWindowlines,2,102);
    Custom_Polygon({{1345, 722}},10,27,currentScene.metroWindow,102);

    Custom_Polygon({{1385, 725}},20,25,currentScene.metroWindow,82);//window
    glPopMatrix();
    glPopMatrix();

    glPopMatrix();


}



void MetroLine()
{
    MetroTrain();

    Linestrip2({{0, 782},{1920, 782}},currentScene.rocketGround,2);
    Custom_Polygon({{0,695}},1920,15,currentScene.metroLinesUp);
    Custom_Polygon({{0,680}},1920,15,currentScene.metroLinesDown);
    //left to right
    //piler-1
    Custom_Polygon({{200,615}},30,65,currentScene.metroLinesDown);
    Custom_Polygon({{200,615}},10,65,currentScene.metroLinesUp);
    Custom_Polygon({{180,680},{190,665},{240,665},{250,680}},currentScene.metroLinesDown);
    Custom_Polygon({{180,680},{190,665},{200,665},{190,680}},currentScene.metroLinesUp);

    //piler-2
    Custom_Polygon({{200,615}},30,65,currentScene.metroLinesDown,500);
    Custom_Polygon({{200,615}},10,65,currentScene.metroLinesUp,500);
    Custom_Polygon({{180,680},{190,665},{240,665},{250,680}},currentScene.metroLinesDown,500);
    Custom_Polygon({{180,680},{190,665},{200,665},{190,680}},currentScene.metroLinesUp,500);

    //piler-3
    Custom_Polygon({{200,615}},30,65,currentScene.metroLinesDown,1000);
    Custom_Polygon({{200,615}},10,65,currentScene.metroLinesUp,1000);
    Custom_Polygon({{180,680},{190,665},{240,665},{250,680}},currentScene.metroLinesDown,1000);
    Custom_Polygon({{180,680},{190,665},{200,665},{190,680}},currentScene.metroLinesUp,1000);

     //piler-4
    Custom_Polygon({{200,615}},30,65,currentScene.metroLinesDown,1500);
    Custom_Polygon({{200,615}},10,65,currentScene.metroLinesUp,1500);
    Custom_Polygon({{180,680},{190,665},{240,665},{250,680}},currentScene.metroLinesDown,1500);
    Custom_Polygon({{180,680},{190,665},{200,665},{190,680}},currentScene.metroLinesUp,1500);



}


void Left1Cars()
{

    glMatrixMode(GL_MODELVIEW);
    //first car
    glPushMatrix();
    //glTranslatef(-200,0,0);
    glTranslatef(moveCarsX1-800,20,0);
    Custom_Polygon({{24.5, 406.5},{12, 408},{11.5, 413},{12, 416.5},{13.2, 419},{16, 438},{22, 438},{47, 453},{50, 454},{82, 454},{87, 453},{111, 440},{115, 438},
                   {123, 436},{142, 431},{148, 422},{149, 419},{147.5, 415},{147.5, 406.5},{24.5, 406.5}},currentScene.car1Body);//car1body
    Custom_Polygon({{108, 438},{28, 438},{48, 450},{54, 452},{82, 452},{88, 450}},currentScene.car1Window);//window
    Custom_Polygon({{69, 452},{70, 438},{74, 438},{71, 452}},currentScene.car1WindowLine);
    Custom_Polygon({{14, 436},{28, 436},{22, 430},{16, 428},{14, 428.5},{13, 430}},currentScene.car1Light);
    Custom_Polygon({{141, 430.5},{130, 432},{134, 428},{140, 426},{145, 426}},currentScene.car1Light);

    glPushMatrix();
    Halfcircle(16,42.5,406.5,currentScene.car1TyreUp);
    glTranslatef(42.5,406.5,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-42.5,-406.5,0);
    Fullcircle(12,42.5,406.5,currentScene.car1Tyre);
    FullcircleWithLines(7,42.5,406.5,currentScene.car1Body);
    Linestrip2({{36, 406},{49, 406}},currentScene.car1Body,2);
    Linestrip2({{42, 400},{42, 413}},currentScene.car1Body,2);
    Fullcircle(3.5,42.5,406.5,currentScene.car1Body);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(70,0,0);
    Halfcircle(16,42.5,406.5,currentScene.car1TyreUp);
    glTranslatef(42.5,406.5,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-42.5,-406.5,0);
    Fullcircle(12,42.5,406.5,currentScene.car1Tyre);
    FullcircleWithLines(7,42.5,406.5,currentScene.car1Body);
    Linestrip2({{36, 406},{49, 406}},currentScene.car1Body,2);
    Linestrip2({{42, 400},{42, 413}},currentScene.car1Body,2);
    Fullcircle(3.5,42.5,406.5,currentScene.car1Body);
    glPopMatrix();
    glPopMatrix();



}
void Left2Car()
{

    //second cars
    glPushMatrix();
    //glTranslated(-350,55,0);
    glTranslatef(moveCarsX2-800,55,0);
    Custom_Polygon({{184.5, 351.5},{165, 354},{163, 365},{162, 384},{164, 387.5},{246, 386},{245, 350}},currentScene.car2Body);//body

    Custom_Polygon({{245, 350},{246, 386},{248, 400},{249, 403.5},{251, 405},{266.5, 405},{270, 404.5},{274, 403.5},{278, 402},{282, 400},
                  {284.5, 398.5},{299.5, 386.5},{307, 386},{315, 385},{321, 384},{326, 383},{332, 381},{336, 379},{337, 377},{337, 374},
                  {336, 367},{332, 349},{325, 348.5}},currentScene.car2Body);//body
    Custom_Polygon({{255, 385},{257, 402},{270, 401},{277, 398},{282, 394},{288, 389},{292, 383}},currentScene.car2Window);//window
    Linestrip2({{162, 387.5},{246, 386}},currentScene.car2Tyre,2);//lines
    Linestrip2({{246, 386},{245, 350}},currentScene.car2Tyre,2);//lines
    Linestrip2({{332, 349},{198, 351}},currentScene.car2Tyre,2);//lines
    Custom_Polygon({{162, 368},{166, 368},{168, 372},{168, 378},{166, 382},{162, 382}},currentScene.car1Light);//light
    Custom_Polygon({{164, 366},{159, 362},{160, 358},{161, 356},{164, 354},{171, 354},{169, 364},{167, 365}},currentScene.car2Tyre);
    Custom_Polygon({{337, 374},{331, 374},{331, 367},{336, 367}},currentScene.car2Light);

    glPushMatrix();
    Halfcircle(17,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    Fullcircle(3.5,198,351,currentScene.car2Tyre);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(100,-2,0);
    Halfcircle(17,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    Fullcircle(3.5,198,351,currentScene.car2Tyre);
    glPopMatrix();

    glPopMatrix();

}
void Left3Car(){

    //Thired car
    glPushMatrix();
    //glTranslatef(-500,5,0);
    glTranslatef(moveCarsX3-500,20,0);
    Custom_Polygon({{375.5, 437},{375, 444},{376, 446},{378, 446},{380, 444},{382, 442},{384, 437}},currentScene.car3seat);//seatleft
    Custom_Polygon({{402, 435},{402, 443},{402, 445},{402, 445},{406, 445},{408, 442},{409, 440},{411, 435}},currentScene.car3seat);
    Custom_Polygon({{363, 402},{352, 408},{352, 420},{354, 422},{352, 428},{354, 434},{358, 438},{436, 434},
                   {448, 434},{455, 433},{461, 432},{468, 430},{472, 427},{475, 423},{479, 416},{479, 413},{477, 407},
                   {474, 402},{461, 402}},currentScene.car3Body);//body
    Custom_Polygon({{436, 434},{418, 452},{417, 450},{416, 452},{419, 451},{430, 446},{437, 442},{448, 434}},currentScene.car3Body);
    Custom_Polygon({{354, 434},{352, 428},{353, 426},{358, 426},{361, 431},{359, 434},{354, 434}},currentScene.car3Light);
    Custom_Polygon({{477, 419},{469, 419},{464, 425},{471, 425},{475, 423}},currentScene.car3Light);
    Custom_Polygon({{479, 413},{479, 414},{473, 414},{471, 410},{471, 409},{472, 408},{477, 408}},currentScene.car3seat);

    glPushMatrix();
    glTranslatef(179,52,0);
    Halfcircle(15,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(250,52,0);
    Halfcircle(15,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    glPopMatrix();
    glPopMatrix();

}



void RightCars()
{
    glMatrixMode(GL_MODELVIEW);
    //first car
    glPushMatrix();
    glScaled(-1,1,1);
    glTranslatef(-3000,-50,0);
    glTranslatef(moveCarsX,0,0);
    glPushMatrix();
    glTranslatef(400,0,0);
    Custom_Polygon({{24.5, 406.5},{12, 408},{11.5, 413},{12, 416.5},{13.2, 419},{16, 438},{22, 438},{47, 453},{50, 454},{82, 454},{87, 453},{111, 440},{115, 438},
                   {123, 436},{142, 431},{148, 422},{149, 419},{147.5, 415},{147.5, 406.5},{24.5, 406.5}},currentScene.rightCar1Body);//car1body
    Custom_Polygon({{108, 438},{28, 438},{48, 450},{54, 452},{82, 452},{88, 450}},currentScene.car1Window);//window
    Custom_Polygon({{69, 452},{70, 438},{74, 438},{71, 452}},currentScene.car1WindowLine);
    Custom_Polygon({{14, 436},{28, 436},{22, 430},{16, 428},{14, 428.5},{13, 430}},currentScene.car1Light);
    Custom_Polygon({{141, 430.5},{130, 432},{134, 428},{140, 426},{145, 426}},currentScene.car1Light);

    glPushMatrix();
    Halfcircle(16,42.5,406.5,currentScene.car1TyreUp);
    glTranslatef(42.5,406.5,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-42.5,-406.5,0);
    Fullcircle(12,42.5,406.5,currentScene.car1Tyre);
    FullcircleWithLines(7,42.5,406.5,currentScene.car1Body);
    Linestrip2({{36, 406},{49, 406}},currentScene.car1Body,2);
    Linestrip2({{42, 400},{42, 413}},currentScene.car1Body,2);
    Fullcircle(3.5,42.5,406.5,currentScene.car1Body);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(70,0,0);
    Halfcircle(16,42.5,406.5,currentScene.car1TyreUp);
    glTranslatef(42.5,406.5,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-42.5,-406.5,0);
    Fullcircle(12,42.5,406.5,currentScene.car1Tyre);
    FullcircleWithLines(7,42.5,406.5,currentScene.car1Body);
    Linestrip2({{36, 406},{49, 406}},currentScene.car1Body,2);
    Linestrip2({{42, 400},{42, 413}},currentScene.car1Body,2);
    Fullcircle(3.5,42.5,406.5,currentScene.car1Body);
    glPopMatrix();
    glPopMatrix();


    //second cars
    glPushMatrix();
    glTranslated(-200,55,0);
    Custom_Polygon({{184.5, 351.5},{165, 354},{163, 365},{162, 384},{164, 387.5},{246, 386},{245, 350}},currentScene.rightCar2Body);//body

    Custom_Polygon({{245, 350},{246, 386},{248, 400},{249, 403.5},{251, 405},{266.5, 405},{270, 404.5},{274, 403.5},{278, 402},{282, 400},
                  {284.5, 398.5},{299.5, 386.5},{307, 386},{315, 385},{321, 384},{326, 383},{332, 381},{336, 379},{337, 377},{337, 374},
                  {336, 367},{332, 349},{325, 348.5}},currentScene.rightCar2Body);//body
    Custom_Polygon({{255, 385},{257, 402},{270, 401},{277, 398},{282, 394},{288, 389},{292, 383}},currentScene.car2Window);//window
    Linestrip2({{162, 387.5},{246, 386}},currentScene.car2Tyre,2);//lines
    Linestrip2({{246, 386},{245, 350}},currentScene.car2Tyre,2);//lines
    Linestrip2({{332, 349},{198, 351}},currentScene.car2Tyre,2);//lines
    Custom_Polygon({{162, 368},{166, 368},{168, 372},{168, 378},{166, 382},{162, 382}},currentScene.car1Light);
    Custom_Polygon({{164, 366},{159, 362},{160, 358},{161, 356},{164, 354},{171, 354},{169, 364},{167, 365}},currentScene.car2Tyre);
    Custom_Polygon({{337, 374},{331, 374},{331, 367},{336, 367}},currentScene.car2Light);

    glPushMatrix();
    Halfcircle(17,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    Fullcircle(3.5,198,351,currentScene.car2Tyre);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(100,-2,0);
    Halfcircle(17,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    Fullcircle(3.5,198,351,currentScene.car2Tyre);
    glPopMatrix();

    glPopMatrix();


    //Thired car
     glPushMatrix();
     glTranslatef(500,5,0);
    Custom_Polygon({{375.5, 437},{375, 444},{376, 446},{378, 446},{380, 444},{382, 442},{384, 437}},currentScene.car3seat);
    Custom_Polygon({{402, 435},{402, 443},{402, 445},{402, 445},{406, 445},{408, 442},{409, 440},{411, 435}},currentScene.car3seat);
    Custom_Polygon({{363, 402},{352, 408},{352, 420},{354, 422},{352, 428},{354, 434},{358, 438},{436, 434},
                   {448, 434},{455, 433},{461, 432},{468, 430},{472, 427},{475, 423},{479, 416},{479, 413},{477, 407},
                   {474, 402},{461, 402}},currentScene.rightCar3Body);//body
    Custom_Polygon({{436, 434},{418, 452},{417, 450},{416, 452},{419, 451},{430, 446},{437, 442},{448, 434}},currentScene.rightCar3Body);
    Custom_Polygon({{354, 434},{352, 428},{353, 426},{358, 426},{361, 431},{359, 434},{354, 434}},currentScene.car3Light);
    Custom_Polygon({{477, 419},{469, 419},{464, 425},{471, 425},{475, 423}},currentScene.car3Light);
    Custom_Polygon({{479, 413},{479, 414},{473, 414},{471, 410},{471, 409},{472, 408},{477, 408}},currentScene.car3seat);

    glPushMatrix();
    glTranslatef(179,52,0);
    Halfcircle(15,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(250,52,0);
    Halfcircle(15,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheel,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    glPopMatrix();
    glPopMatrix();

    glPopMatrix();
}

void House()
{


    //house font land
    Custom_Polygon({{750, 490}},1170,30,currentScene.houseLand);
    Linestrip2({{750, 490},{1920, 490}},currentScene.houseLandShadow,2);
    Linestrip2({{750, 500},{1920, 500}},currentScene.houseRoad,4);
    Custom_Polygon({{750, 520},{750, 488},{780,488}},currentScene.landColor);

    Custom_Polygon({{822, 520},{852, 500},{874, 500},{840, 520}},currentScene.houseRoad);//house1
    Custom_Polygon({{990, 520},{1038, 490},{1100, 490},{1045, 520}},currentScene.houseRoad);//house1
    Linestrip2({{1100, 490},{1045, 520}},currentScene.landColor,2);

    Custom_Polygon({{1095, 520},{1124, 500},{1144, 500},{1110, 520}},currentScene.houseRoad);//house2
    Custom_Polygon({{1164, 520},{1212, 490},{1258, 490},{1200, 520}},currentScene.houseRoad);//house2
    Linestrip2({{1258, 490},{1200, 520}},currentScene.landColor,2);

    Custom_Polygon({{1235, 520},{1282, 490},{1350, 490},{1295, 520}},currentScene.houseRoad);//house3
    Linestrip2({{1350, 490},{1295, 520}},currentScene.landColor,2);
    Custom_Polygon({{1356, 520},{1388, 500},{1406, 500},{1374, 520}},currentScene.houseRoad);//house3

    Custom_Polygon({{1538, 520},{1568, 500},{1590, 500},{1558, 520}},currentScene.houseRoad);//house4
    Custom_Polygon({{1626, 520},{1674, 490},{1742, 490},{1685, 520}},currentScene.houseRoad);//house4
    Linestrip2({{1742, 490},{1685, 520}},currentScene.landColor,2);

    Custom_Polygon({{1786, 520},{1812, 500},{1832, 500},{1798, 520}},currentScene.houseRoad);//house5
    Custom_Polygon({{1870, 520},{1920, 490},{1920, 514},{1915, 520}},currentScene.houseRoad);//house5


    //Left to Right

    //House-5

     Linestrip2({{1710, 519},{1861, 519}},currentScene.houseLines,4);
     Custom_Polygon({{1858, 520},{1858, 542},{1896, 578},{1920, 554},{1920,520}},currentScene.house5);//parkingbody
      Linestrip2({{1896, 578},{1858, 542},{1896, 578},{1920, 554}},currentScene.houseLines,3);
     Custom_Polygon({{1854, 578},{1854, 542},{1858, 542},{1896, 578}},currentScene.house5top);//parkingtop
     Custom_Polygon({{1870, 520}},45,18,currentScene.houseLines);

     Custom_Polygon({{1888, 550}},12,11,currentScene.houseLines);
     Custom_Polygon({{1890, 551}},8,9,currentScene.houseWindow);



    Custom_Polygon({{1770, 520},{1770, 606},{1812, 652},{1856, 606},{1856,520}},currentScene.house55);//body
    Custom_Polygon({{1690, 520}},30,82,currentScene.house2Side);//side
    Custom_Polygon({{1686, 588},{1690, 586},{1695, 602},{1693, 607}},currentScene.house4top);//shadowlefttop
    Custom_Polygon({{1746, 520}},24,90,currentScene.house2Side);//sideMiddle
    Custom_Polygon({{1710, 520}},56,44,currentScene.house5);//bodyleft
    Custom_Polygon({{1706, 566},{1774, 566},{1748, 610},{1692, 610}},currentScene.house5top);//topLeft
    Linestrip2({{1706, 565},{1774, 565}},currentScene.houseLines,2);//linesleft
    Linestrip2({{1744, 607},{1768, 607},{1818, 660}},currentScene.houseLines,3);//topleftlines
    Custom_Polygon({{1744, 608},{1768, 608},{1816, 660},{1792, 660}},currentScene.house5top);//righttop
    Custom_Polygon({{1812, 652},{1816, 656},{1862, 606},{1856, 606}},currentScene.house2Side);//rightshadow
    Linestrip2({{1864, 606},{1814, 659}},currentScene.houseLines,4);//toprightlines
    Linestrip2({{1778, 565},{1860, 565}},currentScene.houseLines,3);//linesMiddle
    Custom_Polygon({{1772, 576},{1778, 566},{1860, 566},{1854, 576}},currentScene.house5top);
    Linestrip2({{1779,520},{1779, 565}},currentScene.houseLines,3);//fontlines
    Linestrip2({{1779,520},{1779, 565}},currentScene.houseLines,3,27);//fontlines
    Linestrip2({{1779,520},{1779, 565}},currentScene.houseLines,3,52);//fontlines
    Linestrip2({{1779,520},{1779, 565}},currentScene.houseLines,3,82);//fontlines


    Custom_Polygon({{1786, 578}},14,32,currentScene.houseLines);//topwindow
    Custom_Polygon({{1788, 580}},10,26,currentScene.houseWindow);//topwindow
    Linestrip2({{1788, 594},{1798, 594}},currentScene.houseLines,1.5);//topwindow

    Custom_Polygon({{1786, 578}},14,32,currentScene.houseLines,20);//top2window
    Custom_Polygon({{1788, 580}},10,26,currentScene.houseWindow,20);//top2window
    Linestrip2({{1788, 594},{1798, 594}},currentScene.houseLines,1.5,20);//top2window

    Custom_Polygon({{1786, 578}},14,32,currentScene.houseLines,40);//top3window
    Custom_Polygon({{1788, 580}},10,26,currentScene.houseWindow,40);//top3window
    Linestrip2({{1788, 594},{1798, 594}},currentScene.houseLines,1.5,40);//top3window

    Custom_Polygon({{1718, 529}},14,32,currentScene.houseLines);//Leftwindow
    Custom_Polygon({{1720, 531}},10,26,currentScene.houseWindow);//Leftwindow
    Linestrip2({{1720, 545},{1732, 545}},currentScene.houseLines,1.5);//Leftwindow

    Custom_Polygon({{1718, 529}},14,32,currentScene.houseLines,25);//Left2window
    Custom_Polygon({{1720, 531}},10,26,currentScene.houseWindow,25);//Left2window
    Linestrip2({{1720, 545},{1732, 545}},currentScene.houseLines,1.5,25);//Left2window

    Custom_Polygon({{1784,520}},16,38,currentScene.houseLines);
    Custom_Polygon({{1786,520}},12,32,currentScene.house2Door);
    Custom_Polygon({{1788, 538}},9,11,currentScene.houseWindow);
    Linestrip2({{1786, 555},{1798, 555}},currentScene.houseWindow,2);



    Custom_Polygon({{1718, 529}},14,32,currentScene.houseLines,92);//rightwindow
    Custom_Polygon({{1720, 531}},10,26,currentScene.houseWindow,92);//rightwindow
    Linestrip2({{1720, 545},{1732, 545}},currentScene.houseLines,1.5,92);//rightwindow

    Custom_Polygon({{1718, 529}},14,32,currentScene.houseLines,116);//rightwindow
    Custom_Polygon({{1720, 531}},10,26,currentScene.houseWindow,116);//rightwindow
    Linestrip2({{1720, 545},{1732, 545}},currentScene.houseLines,1.5,116);//rightwindow

    Fullcircle(8,1810,630,currentScene.houseLines);
    Fullcircle(6,1810,630,currentScene.houseWindow);

    //House-4
    Custom_Polygon({{1440, 520}},22,100,currentScene.house4Side);//side
    Custom_Polygon({{1462, 520}},238,43,currentScene.house4);//side
    Linestrip2({{1518.5, 520},{1518.5, 562}},currentScene.house4Side,5);//windowLeftUp
    Custom_Polygon({{1440, 622},{1458, 562},{1704, 562},{1670, 622}},currentScene.house4top);//top
    Custom_Polygon({{1522, 520},{1574,520},{1574, 562},{1549, 597},{1522, 562}},currentScene.house44);//top
    Custom_Polygon({{1510, 562},{1522, 562},{1549, 597},{1537, 597}},currentScene.house4TopSide);//topSideMiddle
    Linestrip2({{1458, 561},{1522, 561},{1549, 596},{1574, 561},{1704, 561}},currentScene.house4ParkingDoor,2.5);//lines
    Custom_Polygon({{1474, 578},{1474, 594},{1496, 620},{1518, 596},{1518, 578}},currentScene.house4);//topwindowleft
    Linestrip2({{1464, 593.5},{1472, 593.5},{1496, 619},{1522, 593}},currentScene.house4ParkingDoor,3);//topWindowLeftLines
    Custom_Polygon({{1464, 594},{1472, 594},{1496, 620},{1475, 620}},currentScene.house4TopSide);//topwindowleftSide
    Custom_Polygon({{1484, 582}},22,16,currentScene.house4ParkingDoor);//windowLeftUp
    Custom_Polygon({{1486, 584}},18,12,currentScene.houseWindow);//windowLeftUp
    Linestrip2({{1486, 592},{1504, 592}},currentScene.house4ParkingDoor,2);//windowLeftUp
    Linestrip2({{1492, 584},{1492, 596}},currentScene.house4ParkingDoor,2);//windowLeftUp
    Linestrip2({{1498, 584},{1498, 596}},currentScene.house4ParkingDoor,2);//windowLeftUp
    Linestrip2({{1482, 599},{1508, 599}},currentScene.house4ParkingDoor,2);//windowLeftUp
    Linestrip2({{1482, 582},{1508, 582}},currentScene.house4ParkingDoor,2);//windowLeftUp

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(110, 0, 0);
    Custom_Polygon({{1474, 578},{1474, 594},{1496, 620},{1518, 596},{1518, 578}},currentScene.house4);//topwindowleft
    Linestrip2({{1464, 593.5},{1472, 593.5},{1496, 619},{1522, 593}},currentScene.house4ParkingDoor,3);//topWindowLeftLines
    Custom_Polygon({{1464, 594},{1472, 594},{1496, 620},{1475, 620}},currentScene.house4TopSide);//topwindowleftSide
    Custom_Polygon({{1484, 582}},22,16,currentScene.house4ParkingDoor);//windowLeftUp
    Custom_Polygon({{1486, 584}},18,12,currentScene.houseWindow);//windowLeftUp
    Linestrip2({{1486, 592},{1504, 592}},currentScene.house4ParkingDoor,2);//windowLeftUp
    Linestrip2({{1492, 584},{1492, 596}},currentScene.house4ParkingDoor,2);//windowLeftUp
    Linestrip2({{1498, 584},{1498, 596}},currentScene.house4ParkingDoor,2);//windowLeftUp
    Linestrip2({{1482, 599},{1508, 599}},currentScene.house4ParkingDoor,2);//windowLeftUp
    Linestrip2({{1482, 582},{1508, 582}},currentScene.house4ParkingDoor,2);//windowLeftUp
    glPopMatrix();

    Custom_Polygon({{1470, 528}},34,28,currentScene.house4ParkingDoor);//windowLeftDown
    Custom_Polygon({{1472, 530}},30,24,currentScene.houseWindow);//windowLeftDown
    Linestrip2({{1468, 528},{1506, 528}},currentScene.house4ParkingDoor,2);//windowLeftDown
    Linestrip2({{1468, 556},{1506, 556}},currentScene.house4ParkingDoor,2);//windowLeftDown
    Linestrip2({{1472, 548},{1502, 548}},currentScene.house4ParkingDoor,2);//windowLeftDown
    Linestrip2({{1482, 530},{1482, 554}},currentScene.house4ParkingDoor,2);//windowLeftDown
    Linestrip2({{1482, 530},{1482, 554}},currentScene.house4ParkingDoor,2,10);//windowLeftDown

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(115, 0, 0);
    Custom_Polygon({{1470, 528}},34,28,currentScene.house4ParkingDoor);//windowLeftDown
    Custom_Polygon({{1472, 530}},30,24,currentScene.houseWindow);//windowLeftDown
    Linestrip2({{1468, 528},{1506, 528}},currentScene.house4ParkingDoor,2);//windowLeftDown
    Linestrip2({{1468, 556},{1506, 556}},currentScene.house4ParkingDoor,2);//windowLeftDown
    Linestrip2({{1472, 548},{1502, 548}},currentScene.house4ParkingDoor,2);//windowLeftDown
    Linestrip2({{1482, 530},{1482, 554}},currentScene.house4ParkingDoor,2);//windowLeftDown
    Linestrip2({{1482, 530},{1482, 554}},currentScene.house4ParkingDoor,2,10);//windowLeftDown
    glPopMatrix();
    Custom_Polygon({{1536, 520}},24,34,currentScene.house4ParkingDoor);//doorSide
    Custom_Polygon({{1538, 520}},20,32,currentScene.house2Door);//door
    Custom_Polygon({{1627, 520}},58,33,currentScene.house4ParkingDoor);//doorParking
    Linestrip2({{1687, 520},{1687, 553}},currentScene.house4Door,2);//doorParking

    Fullcircle(8,1548,570,currentScene.house4ParkingDoor);
    Fullcircle(6,1548,570,currentScene.houseWindow);


    //House-3
    Custom_Polygon({{1315,520}},125,115,currentScene.house3);//body
    Custom_Polygon({{1270, 635},{1315, 635},{1335, 668}},currentScene.house3Top1);//topleft
    Custom_Polygon({{1315, 635},{1450, 635},{1395, 668},{1335, 668}},currentScene.house3Top2);//topright
    Custom_Polygon({{1340, 635},{1347, 635},{1370, 662},{1354, 662}},currentScene.house3Top1);//topmiddle
    Custom_Polygon({{1326, 588},{1338, 578},{1452, 578},{1440, 588}},currentScene.house3Top2);//middle
    Custom_Polygon({{1340, 588},{1350, 582},{1350, 636},{1340, 636}},currentScene.house3Side);//sideMIddle
    Custom_Polygon({{1350, 640},{1350, 582},{1386, 582},{1386, 636},{1368, 660}},currentScene.house33);//middlebody
    Linestrip2({{1386, 636},{1368, 658}},currentScene.house3Top2,3);
    Custom_Polygon({{1275,520}},40,115,currentScene.house3Side);//sidemiddle
    Linestrip2({{1270, 634},{1315, 634}},currentScene.house2Door,3);//door
    Linestrip2({{1220,520},{1220, 575}},currentScene.house3Side,10);//sideleft
    Custom_Polygon({{1225,520}},85,45,currentScene.house3);//parking
    Linestrip2({{1220, 564},{1310, 564}},currentScene.houseLines,3);//topparkin
    Custom_Polygon({{1200, 595},{1215, 580},{1205, 600}},currentScene.houseTop11);//house2house3gap
    Custom_Polygon({{1220, 565},{1310, 565},{1295, 600},{1205, 600}},currentScene.house3Top2);//topParking
    Custom_Polygon({{1200, 595},{1210, 585},{1205, 600}},currentScene.houseTop11);
    Custom_Polygon({{1235,520}},60,35,currentScene.house3DoorParking);//parkingdoor
    Linestrip2({{1238, 550},{1253, 550}},currentScene.houseWindow,3);//doorwindow
    Linestrip2({{1238, 550},{1253, 550}},currentScene.houseWindow,3,20);//doorwindow
    Linestrip2({{1238, 550},{1253, 550}},currentScene.houseWindow,3,40);//doorwindow
    Linestrip2({{1297,520},{1297, 555}},currentScene.house3Top2,3);
    Linestrip2({{1315, 634},{1348, 634},{1368, 662},{1390, 634},{1450, 634}},currentScene.houseLines,3);//lines

    //window up left
    Custom_Polygon({{1323, 608}},14,14,currentScene.houseLines);
    Custom_Polygon({{1325, 610}},10,10,currentScene.houseWindow);

    //window up middle
    Custom_Polygon({{1358, 592}},20,34,currentScene.houseLines);
    Custom_Polygon({{1360, 594}},16,26,currentScene.houseWindow);
    Linestrip2({{1365, 592},{1365,623}},currentScene.houseLines,1);
    Linestrip2({{1372, 592},{1372,623}},currentScene.houseLines,1);
    Linestrip2({{1360,607},{1376,607}},currentScene.houseLines,2);

    //window up right
    Custom_Polygon({{1394, 591}},28,36,currentScene.houseLines);
    Custom_Polygon({{1396, 593}},24,32,currentScene.houseWindow);
    Linestrip2({{1392, 627},{1424, 627}},currentScene.houseLines,2);
    Linestrip2({{1396, 610},{1422, 610}},currentScene.houseLines,2);
    Linestrip2({{1408,591},{1408,626}},currentScene.houseLines,2);

    //window  down left
    Custom_Polygon({{1324, 550}},12,12,currentScene.houseLines);
    Custom_Polygon({{1326, 552}},8,8,currentScene.houseWindow);

    //window  down right
    Custom_Polygon({{1398, 526}},30,38,currentScene.houseLines);
    Custom_Polygon({{1400, 528}},26,34,currentScene.houseWindow);
    Linestrip2({{1400, 546},{1426, 546}},currentScene.houseLines,2);
    Linestrip2({{1413, 528},{1413, 562}},currentScene.houseLines,2);

    //door
    Custom_Polygon({{1348, 520}},34,46,currentScene.houseLines);
    Custom_Polygon({{1356, 520}},18,38,currentScene.house2Door);
    Linestrip2({{1352, 524},{1352, 554}},currentScene.houseWindow,3);
    Linestrip2({{1378, 524},{1378, 554}},currentScene.houseWindow,3);
    Linestrip2({{1350, 562},{1380, 562}},currentScene.houseWindow,4);


    Linestrip2({{1341, 520},{1341, 578}},currentScene.houseLines,3);
    Linestrip2({{1390, 520},{1390, 578}},currentScene.houseLines,3);
    Linestrip2({{1450, 520},{1450, 578}},currentScene.houseLines,4);
    Linestrip2({{1339, 577},{1450, 577}},currentScene.houseLines,2);

    Linestrip2({{1315,519},{1452, 519}},currentScene.houseLines,3);



    //House-2
    Custom_Polygon({{1070,520},{1070, 595},{1132, 658},{1215, 575},{1215,520}}, currentScene.house2);//body
    Custom_Polygon({{1040,520}},30,75,currentScene.house2Side);//sideleft
    Custom_Polygon({{1098, 580}},10,50,currentScene.house2Side);//sideright
    Custom_Polygon({{1145, 528}},5,57,currentScene.house2Side);//sideright
    Custom_Polygon({{1070, 590},{1080, 565},{1150, 565},{1145, 580},{1108, 580},{1098, 590}}, currentScene.houseTop11);//middleBlack
    Linestrip2({{1070, 590},{1080, 565},{1150, 565}}, currentScene.houseLines,2);//middleline
    Custom_Polygon({{1117, 590}},30,32,currentScene.house2WindowBorder);//windowtop
    Custom_Polygon({{1117, 622},{1147, 622},{1132, 629}},currentScene.house2WindowBorder);//windowtop
    Custom_Polygon({{1121, 594}},22,24,currentScene.houseWindow);//windowMiddle
    Linestrip2({{1132, 594},{1132,620}}, currentScene.house2WindowBorder,2);//windowMiddleborder
    Linestrip2({{1171, 615},{1132, 655}}, currentScene.houseTop1,5);//lineblack

    Linestrip2({{1031, 590},{1065, 590},{1132, 658},{1176, 615}}, currentScene.houseLines,4);//lines

    Custom_Polygon({{1030, 590},{1065, 590},{1132, 659},{1100, 659}}, currentScene.houseTop1);//top
    Linestrip2({{1218, 573},{1178, 614}}, currentScene.houseTop1,3);//lineblack
    Linestrip2({{1130, 575},{1141, 575},{1180, 615},{1219, 575}}, currentScene.houseLines,3);//line middle
    Custom_Polygon({{1130, 575},{1140, 575},{1180, 615},{1170, 615}}, currentScene.houseTop1);//top2middle
    Linestrip2({{1155, 549},{1220, 549}}, currentScene.houseLines,3);//lineblack
    Custom_Polygon({{1150, 560},{1155, 550},{1220, 550},{1215, 560}}, currentScene.houseTop11);//top2middleright

    Custom_Polygon({{1170, 564}},24,24,currentScene.house2WindowBorder);//windowRight
    Custom_Polygon({{1173, 566}},18,20,currentScene.houseWindow);//windowMiddleRight
    Linestrip2({{1183, 564},{1183, 588}}, currentScene.house2WindowBorder,2);//windowRightborder

    Custom_Polygon({{1164, 520}},35,25,currentScene.house2WindowBorder);//parkingDoor
    Linestrip2({{1200, 520},{1200, 546}}, currentScene.houseTop1,2);//parkingDoor
    Custom_Polygon({{1086, 528}},20,30,currentScene.house2Door);//Door
    Linestrip2({{1080, 528},{1080, 565}}, currentScene.houseLines,3);//Door
    Linestrip2({{1110, 528},{1110, 565}}, currentScene.houseLines,3);//Door
    Custom_Polygon({{1070, 520}},80,8,currentScene.house2WindowBorder);//ground


    Custom_Polygon({{1116, 536}},24,24,currentScene.house2WindowBorder);//windowLeftbottom
    Custom_Polygon({{1119, 539}},18,18,currentScene.houseWindow);//windowLeftbottom
    Linestrip2({{1128, 539},{1128, 557}}, currentScene.house2WindowBorder,2);//windowLeftbottom




    //House-1
    Custom_Polygon({{750,520}},150,95, currentScene.house1);//body
    //Custom_Polygon({{750, 520},{900,520},{900, 615},{750,615}}, currentScene.house1);//body
    Custom_Polygon({{900, 520},{900, 615},{935, 670},{965, 615},{965,520}}, currentScene.house11);//body
    Custom_Polygon({{750, 520}},20,95, currentScene.houseSide1);//houseside
    Custom_Polygon({{885, 520}},15,95, currentScene.houseSide1);//houseside
    Linestrip2({{740, 614},{900, 614}}, currentScene.houseLines,4);//
    Custom_Polygon({{740, 615},{900, 615},{870, 650},{800, 650}}, currentScene.houseTop11);//housetop
    Custom_Polygon({{885, 615},{900, 615},{935, 670},{890, 670},{870, 650}}, currentScene.houseTop1);//housetop
    Custom_Polygon({{785, 565},{900, 565},{886, 582},{770, 582}}, currentScene.houseTop11);//middle
    Linestrip2({{770, 582},{785, 565},{900, 565}}, currentScene.houseLines,2);//
    Custom_Polygon({{798, 582},{804, 575},{842, 640},{834, 640}}, currentScene.houseTop1);//middleTriangle
    Custom_Polygon({{804, 575},{842, 640},{880, 575}}, currentScene.house1);//middleTriangle
    Linestrip2({{875, 575},{842, 634}}, currentScene.houseTop11,5);//middleTriangle
    Linestrip2({{804, 576},{842, 640},{880, 576}}, currentScene.houseLines,4);//middleTriangle
    Linestrip2({{966, 615},{935, 665}}, currentScene.houseTop11,3);//rightTriangle
    Linestrip2({{970, 615},{935, 670},{900, 615}}, currentScene.houseLines,5);//rightTriangle
    //window right down
    Linestrip({{915, 525}},36,35, currentScene.houseLines,5);//window
    Custom_Polygon({{915, 525}},35,35, currentScene.houseWindow);//window
    Linestrip2({{927, 525},{927, 560}}, currentScene.houseLines,2);//windowline
    Linestrip2({{927, 525},{927, 560}}, currentScene.houseLines,2,12);//windowline
    //window right up
    Linestrip({{920, 585}},26,25, currentScene.houseLines,5);//window
    Custom_Polygon({{920, 585}},25,25, currentScene.houseWindow);//window
    Linestrip2({{932, 586},{932, 610}}, currentScene.houseLines,2);//windowline

    //window right up
    Linestrip({{926, 625}},13,13, currentScene.houseLines,5);//window
    Custom_Polygon({{926, 625}},13,13, currentScene.houseWindow);//window
    //window left-1
    Linestrip({{785, 525}},21,35, currentScene.houseLines,3);//window
    Custom_Polygon({{785, 525}},20,35, currentScene.houseWindow);//window
    Linestrip2({{785, 545},{805, 545}}, currentScene.houseLines,2);//windowline
    //window left-2
    Linestrip({{855, 525}},21,35, currentScene.houseLines,3);//window
    Custom_Polygon({{855, 525}},20,35, currentScene.houseWindow);//window
    Linestrip2({{855, 545},{875, 545}}, currentScene.houseLines,2);//windowline

    //window left up
    Linestrip({{830, 584}},16,22, currentScene.houseLines,2);//window
    Custom_Polygon({{830, 584}},16,22, currentScene.houseWindow);//window
    Linestrip2({{838, 606},{838, 584}}, currentScene.houseLines,2);//windowline

    Linestrip2({{820, 555},{820, 520},{841, 520},{841, 555},{820, 555}}, currentScene.houseLines,3);//door
    Custom_Polygon({{820, 555},{820, 520},{840, 520},{840, 555}}, currentScene.houseDoor);//door

    Linestrip2({{790, 565},{790, 520},{825, 520},{825,565}}, currentScene.houseLines,3);
    Linestrip2({{825, 520},{860, 520},{860, 565}}, currentScene.houseLines,3);
    Linestrip2({{860, 520},{900, 520},{900, 565}}, currentScene.houseLines,3);

    //car parking
    Custom_Polygon({{965, 520},{975, 520},{975, 545},{965, 545}}, currentScene.houseSide1);//side
    Custom_Polygon({{975, 520},{975, 545},{1020, 590},{1055, 550},{1055,520}}, currentScene.house11);//body
    Linestrip2({{965, 543},{975, 543},{1021, 590},{1058, 550}}, currentScene.houseLines,3);//lines
    Linestrip2({{1055, 550},{1020, 585}}, currentScene.houseTop11,2);//lines
    Linestrip2({{860, 520},{900, 520},{900, 565}}, currentScene.houseLines,3);
    Custom_Polygon({{965, 545},{975, 545},{1020, 590},{965, 590}}, currentScene.houseTop1);//top

    //window parking
    Linestrip2({{1010, 556},{1025, 556},{1025, 568},{1010, 568},{1010, 556}}, currentScene.houseLines,2);//window
    Custom_Polygon({{1010, 556},{1025, 556},{1025, 568},{1010, 568}}, currentScene.houseWindow);//window
    //Linestrip2({{838, 606},{838, 584}}, currentScene.houseLines,2);//windowline

    //door parking
    //Linestrip({{990, 520}},55,30, currentScene.houseLines,3);//window
    Custom_Polygon({{990, 520}},55,20, currentScene.houseDoor);//window
    Linestrip2({{990, 520},{990, 540},{1045, 540},{1045,520}}, currentScene.houseLines,4);//windowline






}


void Sky(Custom_Color skyColor = {48, 89, 124})
{
    // upper limits of the River to top
    Custom_Polygon({{0, 470},{1920, 470},{1920, 1080},{0, 1080}}, currentScene.skyColor, 0, 0);
}

void SunCoordinate(Custom_Color sunColor = {219, 202, 135}, Custom_Color moonLayers = {24, 101, 70})
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(moveSuntX+100, moveSunY, 0);

    Fullcircle(80, 800, 1200, currentScene.sunColor);
    //Fullcircle(80, 1096, 740, sun);
    Custom_Polygon({{1099, 697},{1102, 696},{1106, 699},{1107, 707},{1115, 717},{1109, 719},{1107, 725},{1094, 725}}, currentScene.moonLayers, -296, 460);
    Custom_Polygon({{1092, 725},{1090, 735},{1086, 734},{1080, 741},{1074, 739},{1066, 742},{1060, 737},{1060, 731}}, currentScene.moonLayers, -296, 460);
    Custom_Polygon({{1060, 730},{1055, 727},{1054, 719},{1058, 711},{1060, 707},{1068, 705},{1090, 706},{1107, 719},{1082, 734},{1064, 732}}, currentScene.moonLayers, -296, 460);
    Custom_Polygon({{1070, 708},{1070, 688},{1072, 686},{1070, 679},{1074, 675},{1073, 668},{1078, 657},{1088, 656},{1084, 662},{1086, 666},{1082, 668},{1082, 672},{1091, 676},{1097, 687}}, currentScene.moonLayers, -296, 480);
    Custom_Polygon({{1165, 765},{1156, 768},{1155, 773},{1143, 772},{1143, 771},{1134, 770},{1130, 768},{1131, 763},{1121, 757},{1124, 753},{1121, 743},{1130, 733},{1141, 732}}, currentScene.moonLayers, -296, 460);
    Custom_Polygon({{1155, 740},{1154, 726},{1161, 718},{1173, 720},{1175, 730},{1181, 741}}, currentScene.moonLayers, -310, 460);
    Custom_Polygon({{1156, 742},{1162, 735},{1173, 735},{1182, 739},{1181, 748},{1184, 750},{1178, 756}}, currentScene.moonLayers, -310, 460);
    Custom_Polygon({{1042, 764},{1056, 764},{1059, 761},{1061, 765},{1068, 770},{1069, 775},{1082, 785},{1088, 786},{1077, 793},{1069, 791}}, currentScene.moonLayers, -296, 460);
    Custom_Polygon({{1066, 791},{1064, 799},{1074, 807},{1068, 810},{1061, 815},{1056, 810},{1049, 809}}, currentScene.moonLayers, -296, 450);
    Custom_Polygon({{1049, 807},{1036, 801},{1033, 795},{1034, 785},{1046, 785},{1057, 779}}, currentScene.moonLayers, -286, 450);
    Custom_Polygon({{1049, 807},{1036, 801},{1033, 795},{1034, 785},{1046, 785},{1057, 779}}, currentScene.moonLayers, -296, 420);
    Custom_Polygon({{1049, 807},{1036, 801},{1033, 795},{1034, 785},{1046, 785},{1057, 779}}, currentScene.moonLayers, -296, 430);

    glPopMatrix();
}

void Hill()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0,40 , 0);

    //back hill right side
    Custom_Polygon({{1320, 760},{1470, 810},{1510, 790},{1510, 640},{1320, 640}},currentScene.hillColor1);//m1
    Custom_Polygon({{1510, 790},{1560, 820},{1560, 640},{1510, 640}},currentScene.hillColor1);//m1
    Custom_Polygon({{1590, 830},{1610, 860},{1645, 870},{1680, 860},{1680, 640},{1560,640},{1560, 820}},currentScene.hillColor1);//q1
    Custom_Polygon({{1680, 860},{1750, 850},{1800, 820},{1800,640},{1680,640}},currentScene.hillColor1);
    Custom_Polygon({{1800, 820},{1840, 835},{1880, 805},{1922, 785},{1922,640},{1800,640}},currentScene.hillColor1);//q1

    //hiddShadow
    Custom_Polygon({{1320, 760},{1470, 810},{1480, 790}},currentScene.hillShadow);
    Custom_Polygon({{1380, 760},{1470, 810},{1480, 790}},currentScene.hillShadow);
    Custom_Polygon({{1510, 790},{1470, 810},{1480, 790},{1580, 680}},currentScene.hillShadow1);
    Custom_Polygon({{1510, 790},{1580, 680},{1530, 802}},currentScene.hillShadow1);

    Custom_Polygon({{1600, 820},{1610, 860},{1645, 870}},currentScene.hillShadow);
    Custom_Polygon({{1560, 820},{1610, 810},{1590, 830}},currentScene.hillShadow);
    Custom_Polygon({{1590, 830},{1600, 820},{1640, 810},{1610, 860}},currentScene.hillShadow);

    Custom_Polygon({{1820, 810},{1825, 820},{1880, 760},{1860, 800},{1880, 790},{1880, 805},{1840, 835},{1800, 820}},currentScene.hillShadow2);
    Custom_Polygon({{1800, 820},{1820, 800},{1825, 820}},currentScene.hillShadow2);
    Custom_Polygon({{1820, 810},{1825, 820},{1800, 820}},currentScene.hillShadow1);
    Custom_Polygon({{1825, 820},{1840, 810},{1840, 835}},currentScene.hillShadow1);
    Custom_Polygon({{1800, 820},{1825, 820},{1840, 835}},currentScene.hillShadow1);

    Custom_Polygon({{1820, 640},{1640, 780},{1680, 770},{1730, 760},{1700, 800},{1780, 750},{1770, 780},{1790, 770},{1780, 800},{1920, 720},{1920,640}},currentScene.hillShadow2);
    Custom_Polygon({{1680, 770},{1670, 790},{1730, 760}},currentScene.hillShadow2);
    Custom_Polygon({{1860, 640},{1730, 760},{1700, 800},{1780, 750},{1900, 640}},currentScene.hillShadow3);
    Custom_Polygon({{1730, 760},{1720, 760},{1770, 730}},currentScene.hillShadow3);
    Custom_Polygon({{1790, 740},{1780, 760},{1860, 670}},currentScene.hillShadow3);


    //back hill right side
    Custom_Polygon({{0,760},{130, 800},{200, 790},{260, 640},{0,640}},currentScene.hillColor);//i
    Custom_Polygon({{200, 790},{260, 820},{330, 830},{330, 640},{260, 640}},currentScene.hillColor);//
    Custom_Polygon({{330, 830},{390, 870},{460, 895},{500, 890},{500, 640},{260, 640}},currentScene.hillColor);//p
    Custom_Polygon({{500, 890},{620, 940},{700, 970},{740, 960},{800, 940},{840, 900},{840,640},{500, 640}},currentScene.hillColor);//w
    Custom_Polygon({{840, 900},{880, 890},{920, 860},{940, 840},{940,640},{840,640}},currentScene.hillColor);//b1
    Custom_Polygon({{940, 840},{960, 840},{1000, 880},{1040, 880},{1080, 840},{1220, 820},{1380, 740},{1380,640},{940,640}},currentScene.hillColor);//j1
    Custom_Polygon({{1380, 740},{1435, 750},{1470, 770},{1660, 640},{1380,640}},currentScene.hillColor);//i1

    //hiddShadow
    Custom_Polygon({{640, 920},{640, 910},{700, 970},{620, 940},{500, 890}},currentScene.hillShadow);
    Custom_Polygon({{700, 970},{660, 940},{670, 890},{700, 940}},currentScene.hillShadow);
    Custom_Polygon({{700, 970},{740, 960},{800, 940},{780, 900},{700, 940}},currentScene.hillShadow1);
    Custom_Polygon({{800, 940},{720, 860},{840, 900}},currentScene.hillShadow1);
    Custom_Polygon({{500, 890},{460, 870},{480, 895}},currentScene.hillShadow1);
    Custom_Polygon({{480, 895},{460, 880},{460, 895}},currentScene.hillShadow1);
    Custom_Polygon({{390, 870},{330, 800},{330, 830}},currentScene.hillShadow2);
    Custom_Polygon({{310, 815},{320, 810},{330, 800},{330, 830},{295, 810}},currentScene.hillShadow2);
    Custom_Polygon({{240, 780},{220, 800},{260, 820},{330, 830},{295, 810}},currentScene.hillShadow2);
    Custom_Polygon({{180, 750},{150, 760},{200, 790},{260, 820}},currentScene.hillShadow2);
    Custom_Polygon({{60, 740},{90, 730},{120, 750},{150, 760},{200, 790},{130, 800},{60, 740}},currentScene.hillShadow2);
    Custom_Polygon({{860, 750},{920, 860},{940, 840},{900, 740}},currentScene.hillShadow3);
    Custom_Polygon({{1080, 840},{1000, 880},{1040, 880},{1220, 820},{1320, 770}},currentScene.hillShadow1);
    Custom_Polygon({{1380, 740},{1460, 720},{1435, 760}},currentScene.hillShadow3);
    Custom_Polygon({{1420, 750},{1440, 760},{1460, 760},{1480, 740},{1470, 770}},currentScene.hillShadow1);
    Custom_Polygon({{1460, 760},{1520, 735},{1470, 770}},currentScene.hillShadow1);
    Custom_Polygon({{1100, 800},{1080, 840},{1000, 880}},currentScene.hillShadow1);
    Custom_Polygon({{900, 740},{1000, 810},{1180, 740},{1180, 640},{900, 640}},currentScene.hillShadow2);
    Custom_Polygon({{1180, 740},{1160, 780},{1300, 720},{1300, 640},{1180, 640}},currentScene.hillShadow2);
    Custom_Polygon({{1300, 720},{1280, 750},{1600, 640},{1300, 640}},currentScene.hillShadow2);

    Custom_Polygon({{230, 730},{280, 760},{260, 730}},currentScene.hillShadow2);
    Custom_Polygon({{260, 730},{290, 750},{280, 710}},currentScene.hillShadow2);
    Custom_Polygon({{270, 720},{440, 820},{460, 780},{520, 800},{500, 760},{440, 640}},currentScene.hillShadow2);
    Custom_Polygon({{460, 680},{600, 780},{740, 840},{700, 780},{800, 800},{680, 700}},currentScene.hillShadow2);
    Custom_Polygon({{340, 680},{500, 780},{480, 740},{600, 820},{560, 760},{600, 780},{500, 680}},currentScene.hillShadow3);



    //fronthill
    Custom_Polygon({{0, 720},{20, 730},{60, 740},{90, 730},{90,640},{0,640}},currentScene.hillColor1);//d2
    Custom_Polygon({{90, 730},{120, 750},{150, 760},{150, 760},{180, 750},{180,640},{90,640}},currentScene.hillColor1);//g2
    Custom_Polygon({{180, 750},{210, 750},{230, 730},{230,640},{180,640}},currentScene.hillColor1);//i1
    Custom_Polygon({{230, 730},{260, 730},{320, 700},{320,640},{230,640}},currentScene.hillColor1);//l2
    Custom_Polygon({{400, 680},{480, 720},{560, 700},{580, 740},{620, 730},{620,640},{320,640},{320, 700}},currentScene.hillColor1);//l2
    Custom_Polygon({{620, 730},{660, 760},{700, 750},{780, 770},{820, 760},{900, 740},{960, 720},{1020, 700},{1160, 680},{1220, 640},{620,640}},currentScene.hillColor1);//q2
    //fronthill hiddShadow
    Custom_Polygon({{240, 640},{120, 720},{120, 735},{135, 735},{130, 745},{145, 740},{150, 760},{210, 750},{230, 730},{260, 730},{320, 700},{460, 680},{700,640}},currentScene.hillShadow4);
    Custom_Polygon({{120, 735},{130, 720},{120, 720}},currentScene.hillColor1);
    Custom_Polygon({{820, 640},{820, 760},{800, 765},{770, 760},{780, 750},{760, 730},{810, 720},{770, 700},{790, 690},{700, 640}},currentScene.hillShadow4);
    Custom_Polygon({{820, 640},{820, 760},{860, 750},{860, 730},{890, 700},{870, 700},{910, 680},{870, 690},{890, 670},{970,640}},currentScene.hillShadow4);
    Custom_Polygon({{860, 730},{890, 720},{860, 750}},currentScene.hillShadow4);

    glPopMatrix();
}



void LandRiverSide()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    //glScalef(1,1,0);
    glTranslatef(0, 0, 0);
    Custom_Polygon({{0,250},{1930,250},{1930,235},{0,235}},currentScene.landColor2);

    Custom_Polygon({{12,235},{8,250},{16,250},{18,240}},currentScene.groundColor1);
    Custom_Polygon({{27,237},{22,250},{35,250},{40,245}},currentScene.groundColor2);
    Custom_Polygon({{39,237},{51,250},{58,250}},currentScene.groundColor3);
    Custom_Polygon({{46,235},{64,250},{70,235}},currentScene.groundColor3);
    Custom_Polygon({{82,235},{78,244},{102,235}},currentScene.groundColor2);
    Custom_Polygon({{108,235},{89,250},{118,250},{113,235}},currentScene.groundColor1);
    Custom_Polygon({{117,235},{134,250},{142,250},{130,235}},currentScene.groundColor3);
    Custom_Polygon({{144,235},{155,246},{157,235}},currentScene.groundColor2);
    Custom_Polygon({{178,235},{160,250},{173,250},{214,235}},currentScene.groundColor1);
    Custom_Polygon({{192,250},{214,250},{223,236}},currentScene.groundColor3);
    Custom_Polygon({{244,235},{230,250},{269,250},{254,235}},currentScene.groundColor3);
    Custom_Polygon({{260,235},{275,250},{281,250},{277,235}},currentScene.groundColor2);
    glPopMatrix();

    // glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glScalef(1.5,1,0);
    glTranslatef(200, 0, 0);

    Custom_Polygon({{12,235},{8,250},{16,250},{18,240}},currentScene.groundColor1);
    Custom_Polygon({{27,237},{22,250},{35,250},{40,245}},currentScene.groundColor2);
    Custom_Polygon({{39,237},{51,250},{58,250}},currentScene.groundColor3);
    Custom_Polygon({{46,235},{64,250},{70,235}},currentScene.groundColor3);
    Custom_Polygon({{82,235},{78,244},{102,235}},currentScene.groundColor2);
    Custom_Polygon({{108,235},{89,250},{118,250},{113,235}},currentScene.groundColor1);
    Custom_Polygon({{117,235},{134,250},{142,250},{130,235}},currentScene.groundColor3);
    Custom_Polygon({{144,235},{155,246},{157,235}},currentScene.groundColor2);
    Custom_Polygon({{178,235},{160,250},{173,250},{214,235}},currentScene.groundColor1);
    Custom_Polygon({{192,250},{214,250},{223,236}},currentScene.groundColor3);
    Custom_Polygon({{244,235},{230,250},{269,250},{254,235}},currentScene.groundColor3);
    Custom_Polygon({{260,235},{275,250},{281,250},{277,235}},currentScene.groundColor2);
    glPopMatrix();

    // glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glScalef(1.7,1,0);
    glTranslatef(450, 0, 0);

    Custom_Polygon({{12,235},{8,250},{16,250},{18,240}},currentScene.groundColor1);
    Custom_Polygon({{27,237},{22,250},{35,250},{40,245}},currentScene.groundColor2);
    Custom_Polygon({{39,237},{51,250},{58,250}},currentScene.groundColor3);
    Custom_Polygon({{46,235},{64,250},{70,235}},currentScene.groundColor3);
    Custom_Polygon({{82,235},{78,244},{102,235}},currentScene.groundColor2);
    Custom_Polygon({{108,235},{89,250},{118,250},{113,235}},currentScene.groundColor1);
    Custom_Polygon({{117,235},{134,250},{142,250},{130,235}},currentScene.groundColor3);
    Custom_Polygon({{144,235},{155,246},{157,235}},currentScene.groundColor2);
    Custom_Polygon({{178,235},{160,250},{173,250},{214,235}},currentScene.groundColor1);
    Custom_Polygon({{192,250},{214,250},{223,236}},currentScene.groundColor3);
    Custom_Polygon({{244,235},{230,250},{269,250},{254,235}},currentScene.groundColor3);
    Custom_Polygon({{260,235},{275,250},{281,250},{277,235}},currentScene.groundColor2);
    glPopMatrix();

    //glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glScalef(1.5,1,0);
    glTranslatef(850, 0, 0);

    Custom_Polygon({{12,235},{8,250},{16,250},{18,240}},currentScene.groundColor1);
    Custom_Polygon({{27,237},{22,250},{35,250},{40,245}},currentScene.groundColor2);
    Custom_Polygon({{39,237},{51,250},{58,250}},currentScene.groundColor3);
    Custom_Polygon({{46,235},{64,250},{70,235}},currentScene.groundColor3);
    Custom_Polygon({{82,235},{78,244},{102,235}},currentScene.groundColor2);
    Custom_Polygon({{108,235},{89,250},{118,250},{113,235}},currentScene.groundColor1);
    Custom_Polygon({{117,235},{134,250},{142,250},{130,235}},currentScene.groundColor3);
    Custom_Polygon({{144,235},{155,246},{157,235}},currentScene.groundColor2);
    Custom_Polygon({{178,235},{160,250},{173,250},{214,235}},currentScene.groundColor1);
    Custom_Polygon({{192,250},{214,250},{223,236}},currentScene.groundColor3);
    Custom_Polygon({{244,235},{230,250},{269,250},{254,235}},currentScene.groundColor3);
    Custom_Polygon({{260,235},{275,250},{281,250},{277,235}},currentScene.groundColor2);
    glPopMatrix();

    // glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    // glScalef(1,1,0);
    glTranslatef(1700, 0, 0);

    Custom_Polygon({{12,235},{8,250},{16,250},{18,240}},currentScene.groundColor1);
    Custom_Polygon({{27,237},{22,250},{35,250},{40,245}},currentScene.groundColor2);
    Custom_Polygon({{39,237},{51,250},{58,250}},currentScene.groundColor3);
    Custom_Polygon({{46,235},{64,250},{70,235}},currentScene.groundColor3);
    Custom_Polygon({{82,235},{78,244},{102,235}},currentScene.groundColor2);
    Custom_Polygon({{108,235},{89,250},{118,250},{113,235}},currentScene.groundColor1);
    Custom_Polygon({{117,235},{134,250},{142,250},{130,235}},currentScene.groundColor3);
    Custom_Polygon({{144,235},{155,246},{157,235}},currentScene.groundColor2);
    Custom_Polygon({{178,235},{160,250},{173,250},{214,235}},currentScene.groundColor1);
    Custom_Polygon({{192,250},{214,250},{223,236}},currentScene.groundColor3);
    Custom_Polygon({{244,235},{230,250},{269,250},{254,235}},currentScene.groundColor3);
    Custom_Polygon({{260,235},{275,250},{281,250},{277,235}},currentScene.groundColor2);
    glPopMatrix();

}
void Land()
{

    Custom_Polygon({{0,680},{1930,680},{1930,250},{0,250}},currentScene.landColor);

}

void Flyover()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    //glScalef(1,1,0);
    glTranslatef(0, 18, 0);
    //Horizontal flyover
    Custom_Polygon({{0,460},{1930,460},{1930,440},{0,440}},currentScene.roadShoulder);
    Linestrip2({{0,460},{1930,460}},currentScene.roadShoulder2,4);
    Linestrip2({{0,444},{1930,444}},currentScene.roadColor,1.5);
    Custom_Polygon({{0,440},{1930,440},{1930,330},{0,330}},currentScene.roadColor);
    Linestrip2({{0,436},{1930,436}},currentScene.roadShadow,6);
    Custom_Polygon({{0,330},{1930,330},{1930,300},{0,300}},currentScene.roadShoulder);
    Linestrip2({{0,330},{1930,330}},currentScene.roadShoulder2,6);

    //flyover pier
    Custom_Polygon({{0,300},{80,300},{40,280},{40,240},{0,240}},currentScene.roadPier1);//body
    Linestrip2({{0,297},{80,297}},currentScene.roadShoulder3,4.5);
    Custom_Polygon({{40,280},{80,300},{105,300},{55,275},{55,250},{40,240}},currentScene.roadPier2);//shade 1


    //flyover pier 2
    Custom_Polygon({{560,280},{520,300},{640,300},{600,280},{600,240},{560,240}},currentScene.roadPier1);//body
    Linestrip2({{520,297},{640,297}},currentScene.roadShoulder3,4.5);
    Custom_Polygon({{560,280},{520,300},{500,300},{545,275},{545,240},{560,240}},currentScene.roadPier2);//shade 1
    Custom_Polygon({{600,280},{640,300},{660,300},{615,275},{615,250},{600,240}},currentScene.roadPier2);//shade 2



    //flyover pier 3
    Custom_Polygon({{1320,280},{1280,300},{1400,300},{1360,280},{1360,240},{1320,240}},currentScene.roadPier1);//body
    Linestrip2({{1280,297},{1400,297}},currentScene.roadShoulder3,4.5);
    Custom_Polygon({{1320,280},{1280,300},{1265,300},{1305,275},{1305,240},{1320,240}},currentScene.roadPier2);//shade 1
    Custom_Polygon({{1360,280},{1400,300},{1415,300},{1375,275},{1375,250},{1360,240}},currentScene.roadPier2);//shade 2



    //flyover pier 4
    Custom_Polygon({{1860,280},{1820,300},{1920,300},{1920,240},{1860,240}},currentScene.roadPier1);//body
    Linestrip2({{1820,297},{1920,297}},currentScene.roadShoulder3,4.5);
    Custom_Polygon({{1860,280},{1820,300},{1805,300},{1845,275},{1845,240},{1860,240}},currentScene.roadPier2);//shade 1



    //road divider line
    Linestrip2({{0,390},{80,390}},currentScene.roadDivider,4);
    Linestrip2({{160,390},{240,390}},currentScene.roadDivider,4);
    Linestrip2({{320,390},{400,390}},currentScene.roadDivider,4);
    Linestrip2({{480,390},{560,390}},currentScene.roadDivider,4);
    Linestrip2({{640,390},{720,390}},currentScene.roadDivider,4);
    Linestrip2({{800,390},{880,390}},currentScene.roadDivider,4);
    Linestrip2({{960,390},{1040,390}},currentScene.roadDivider,4);
    Linestrip2({{1120,390},{1200,390}},currentScene.roadDivider,4);
    Linestrip2({{1280,390},{1360,390}},currentScene.roadDivider,4);
    Linestrip2({{1440,390},{1520,390}},currentScene.roadDivider,4);
    Linestrip2({{1600,390},{1680,390}},currentScene.roadDivider,4);
    Linestrip2({{1760,390},{1840,390}},currentScene.roadDivider,4);
    Linestrip2({{1900,390},{1920,390}},currentScene.roadDivider,4);

    Left1Cars();
    Left3Car();
    Left2Car();
    RightCars();
    glPopMatrix();


}
void RocketStation()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glScalef(1.4,1.4,0);
    glTranslatef(0, -150, 0);
    //glTranslatef(0,moveRocketY,0);


    //Controm Senter
    Custom_Polygon({{22, 616},{46, 616},{46, 510},{22, 510}},currentScene.rocketGround);//black center
    Custom_Polygon({{40, 608},{54, 608},{54, 510},{40, 510}},currentScene.rocketTower1);
    Linestrip2({{55, 565},{12, 565}},currentScene.rocketBody2,10);//middle
    Linestrip2({{33.5, 570},{33.5, 510}},currentScene.rocketTower2,10);//middle
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,10);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,20);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,30);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,40);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,50);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,60);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,70);
    Linestrip2({{37, 600},{55, 600}},currentScene.rocketBody,2);
    Linestrip2({{37, 600},{37, 510}},currentScene.rocketBody,2);
    Linestrip2({{55, 600},{55, 510}},currentScene.rocketBody,2);


    glPushMatrix();
    glTranslatef(-25, 0, 0);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,10);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,20);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,30);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,40);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,50);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,60);
    Linestrip2({{55, 520},{37, 520},{55,530}},currentScene.rocketBody,1,0,70);
    Linestrip2({{37, 600},{55, 600}},currentScene.rocketBody,2);
    Linestrip2({{37, 600},{37, 510}},currentScene.rocketBody,2);
    Linestrip2({{55, 600},{55, 510}},currentScene.rocketBody,2);
    glPopMatrix();

    Custom_Polygon({{5, 532},{31, 532},{31, 510},{5, 510}},currentScene.rocketBody2);
    //tower antina
    Linestrip2({{35, 624},{35, 638}},currentScene.rocketTower2,2);
    Custom_Polygon({{28, 616},{35, 624},{35, 616}},currentScene.rocketBody2);
    Custom_Polygon({{42, 616},{35, 624},{35, 616}},currentScene.rocketTower2);




    //Rocket Ground
    Custom_Polygon({{75, 525},{205, 525},{235, 510},{45, 510}},currentScene.rocketGround);
    //Rocket stand black
    Linestrip2({{96, 640},{105, 648},{176, 648},{186, 640},{186, 525},{96, 525},{96, 640}},currentScene.rocketGround,2.5);

    //Rocket stand left
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,10);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,10);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,20);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,30);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,40);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,50);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,60);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,70);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,80);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,90);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,100);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,110);
    Linestrip2({{110,530},{90, 530},{110, 540}},currentScene.rocketBody,1,0,120);
    Linestrip2({{90, 525},{90, 658}},currentScene.rocketBody,2);
    Linestrip2({{110, 525},{110, 670}},currentScene.rocketBody,2);

    //Rocket stand right
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,10);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,20);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,30);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,40);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,50);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,60);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,70);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,80);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,90);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,100);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,110);
    Linestrip2({{175, 530},{195, 530},{175, 540}},currentScene.rocketBody,1,0,120);
    Linestrip2({{175, 525},{175, 670}},currentScene.rocketBody,2);
    Linestrip2({{195, 525},{195, 658}},currentScene.rocketBody,2);

    Linestrip2({{96, 640},{104, 648},{176, 648},{186, 640},{186, 525},{96, 525},{96, 640}},currentScene.rocketGround,1);
    glPopMatrix();




}
void Rocket()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glScalef(1.4,1.4,0);
    glTranslatef(3, -150, 0);
    glTranslatef(0,moveRocketY,0);
    Custom_Polygon({{120, 592},{140, 608},{160, 592},{165,530},{115,530}},currentScene.rocketBody);//groun body down side
    Custom_Polygon({{132, 612},{149, 612},{150, 600},{131,601}},currentScene.rocketBody);//groun body left
    Custom_Polygon({{126, 598},{131,601},{128, 530},{121,530}},currentScene.rocketBody2);//groun body left shadow
    Custom_Polygon({{153, 597},{160, 592},{165,530},{158,530}},currentScene.rocketBody2);//groun body right shadow
    Custom_Polygon({{132, 624},{132, 694},{149, 694},{149, 624}},currentScene.rocketBody); // upper body
    Linestrip2({{140, 705},{140, 720}},currentScene.rocketBody,1); //antina
    Custom_Polygon({{134, 702},{140, 710},{147, 702},{149,694},{132, 694}},currentScene.rocketHead);//head
    Custom_Polygon({{136.665, 702.418},{140, 710},{138.845, 700.846},{139.092,694},{135.143, 694}},currentScene.rocketHead2);// head shadow

    Custom_Polygon({{134, 621},{147, 621},{147, 615},{134, 615}},currentScene.rocketBody);//groun body middle white
    Custom_Polygon({{134, 621},{147, 621},{149, 624},{132, 624}},currentScene.rocketHead);//groun body middle upper
    Custom_Polygon({{132, 612},{134, 615},{147, 615},{149, 612}},currentScene.rocketHead);//groun body middle down

    //rock fire
    Custom_Polygon({{134, 530},{148, 530},{146, 526},{136, 526}},currentScene.rocketHead);
    Linestrip2({{135, 528},{147, 528}},currentScene.rocketBody,1);
    Custom_Polygon({{134, 530},{148, 530},{146, 526},{136, 526}},currentScene.rocketHead,15);
    Linestrip2({{135, 528},{147, 528}},currentScene.rocketBody,1,15);
    Custom_Polygon({{134, 530},{148, 530},{146, 526},{136, 526}},currentScene.rocketHead,-15);
    Linestrip2({{135, 528},{147, 528}},currentScene.rocketBody,1,-15);
    glPopMatrix();

}

void Road()
{

    Custom_Polygon({{1130, 90},{1120,106},{1203,61},{1185, 50},{1185, 15},{1130, 50}},currentScene.roadPier1);//body
    Linestrip2({{1125,105},{1203,61}},currentScene.roadShoulder3,8);
    Custom_Polygon({{1185, 50},{1203,61},{1214,54},{1200, 45},{1200, 25},{1185, 15}},currentScene.roadPier2);//shade 1

    Custom_Polygon({{1380,0},{340,520},{440,520},{1660,0}},currentScene.roadColor);//road
    Custom_Polygon({{1310,0},{840,262},{840,273},{1380,0}},currentScene.roadShoulder);//roadshoulderrever
    Custom_Polygon({{1360,0},{840,270},{840,273},{1380,0}},currentScene.roadShoulder2);//roadshoulderrever
    Custom_Polygon({{840,262},{330,520},{340,520},{840,270}},currentScene.roadShoulder2);//roadsider

    Custom_Polygon({{1660,0},{1030,268},{1030,278},{1730,0}},currentScene.roadShoulder);//roadshoulderrever
    Custom_Polygon({{1730,0},{1030,278},{1030,280},{1748,0}},currentScene.roadShoulder2);//roadshoulderrever
    Custom_Polygon({{1030,268},{440,520},{451,520},{1030,274}},currentScene.roadShoulder2);//roadsider

    Custom_Polygon({{340,520},{700,680},{750,680},{440,520}},currentScene.roadColor);
    Custom_Polygon({{330,520},{695,680},{700,680},{340,520}},currentScene.roadShoulder2);//roadsider
    Custom_Polygon({{440,520},{750,680},{753,680},{451,520}},currentScene.roadShoulder2);//roadsider

    //roadBorder
    Custom_Polygon({{1510,0},{393.5,520},{396.5,520},{1530,0}},currentScene.roadDivider);//roadsider

    //Custom_Polygon({{396.5,520},{624.82,617.30},{624, 617.5},{393.5,520}},currentScene.roadDivider);//roadsider
    //Linestrip2({{600,616.81},{725, 680}},currentScene.roadDivider,0.5);

    Linestrip2({{396.5,520},{725, 680}},currentScene.roadDivider,0.5);

}


void Boat(Custom_Color boatColor = {255, 255, 255}, Custom_Color boatbottomColor = {39,30,73}, Custom_Color boatwindowColor = {107,111,116})
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(moveboatX, moveboatY-157, 0);
    Custom_Polygon({{1679, 268},{1719, 237},{1753, 232},{1837, 229},{1858, 248},{1847, 257},{1760, 271}}, currentScene.boatColor, 300, -60);
    Custom_Polygon({{1807, 282},{1805, 286},{1828, 288},{1820, 290},{1784, 291}}, currentScene.boatColor, 300, -65);
    Custom_Polygon({{1679, 268},{1719, 237},{1753, 232},{1837, 229},{1854, 245},{1796, 251},{1755, 248}}, currentScene.boatbottomColor, 300, -60);
    Custom_Polygon({{1822, 261},{1803, 286},{1751, 291},{1729, 271},{1764, 271}}, currentScene.boatColor, 300, -60);
    Custom_Polygon({{1751, 289},{1735, 273},{1762, 272},{1766, 288}}, currentScene.boatwindowColor, 300, -60);
    Custom_Polygon({{1772, 287},{1766, 273},{1786, 269},{1787, 285}}, currentScene.boatwindowColor, 300, -60);
    Custom_Polygon({{1790, 286},{1790, 267},{1816, 262},{1801, 285}}, currentScene.boatwindowColor, 300, -60);
    Linestrip({{1681, 265},{1732, 264},{1780, 258},{1851, 246}}, currentScene.boatbottomColor, 300, -57);
    glPopMatrix();

}




void Riverflow(Custom_Color rivershade1Color = {61, 109, 186}, Custom_Color rivershade2Color = {54,102,192}, Custom_Color rivershade3Color = {33, 59, 122}, Custom_Color rivershade4Color = {110,161,233})
{
    //water
    Custom_Polygon({{1920, 0},{1920, 470},{0, 470},{0, 0}}, currentScene.riverColor, 0, 0);

    //moving water
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(movewatercurrentX, -200, 0);

    // manual shades
    //type 1
    Custom_Polygon({{1234, 403},{1402, 397},{1611, 413},{1414, 381}}, currentScene.rivershade1Color, -50);
    Custom_Polygon({{1234, 403},{1402, 397},{1611, 413},{1414, 381}}, currentScene.rivershade1Color, -150, 50);
    Custom_Polygon({{1234, 403},{1402, 397},{1611, 413},{1414, 381}}, currentScene.rivershade1Color, -270, 50);
    //type 2
    Custom_Polygon({{1328, 326},{1593, 337},{1897, 319},{1407, 307}}, currentScene.rivershade1Color);
    Custom_Polygon({{1328, 326},{1593, 337},{1897, 319},{1407, 307}}, currentScene.rivershade1Color, -750);

    //type 3
    Custom_Polygon({{568, 401},{829, 395},{1086, 410},{790, 374}}, currentScene.rivershade3Color);
    Custom_Polygon({{568, 401},{829, 395},{1086, 410},{790, 374}}, currentScene.rivershade3Color, -700, -50);
    Custom_Polygon({{568, 401},{829, 395},{1086, 410},{790, 374}}, currentScene.rivershade3Color, 100, -100);
    Custom_Polygon({{568, 401},{829, 395},{1086, 410},{790, 374}}, currentScene.rivershade3Color, -1200, -100);

    //type 4
    Custom_Polygon({{633, 399},{895, 433},{1216, 417},{778, 399}}, currentScene.rivershade2Color, -500, 20);
    Custom_Polygon({{633, 399},{895, 433},{1216, 417},{778, 399}}, currentScene.rivershade2Color, 200, -180);
    Custom_Polygon({{633, 399},{895, 433},{1216, 417},{778, 399}}, currentScene.rivershade2Color, 800, -200);
    Custom_Polygon({{633, 399},{895, 433},{1216, 417},{778, 399}}, currentScene.rivershade2Color, -800, -150);
    Custom_Polygon({{633, 399},{895, 433},{1216, 417},{778, 399}}, currentScene.rivershade2Color, -1200, -150);
    Custom_Polygon({{633, 399},{895, 433},{1216, 417},{778, 399}}, currentScene.rivershade2Color, -1200, -40);

    //type 5
    Custom_Polygon({{1248, 397},{1446, 388},{1676, 400},{1425, 399}}, currentScene.rivershade4Color, 0, 50);
    Custom_Polygon({{1248, 397},{1446, 388},{1676, 400},{1425, 399}}, currentScene.rivershade4Color, -700, 50);
    Custom_Polygon({{1248, 397},{1446, 388},{1676, 400},{1425, 399}}, currentScene.rivershade4Color, -1200, 20);
    Custom_Polygon({{1248, 397},{1446, 388},{1676, 400},{1425, 399}}, currentScene.rivershade4Color, -500, -10);

    glPopMatrix();

}

void StarsCoordinate(Custom_Color starsColor = {255, 255, 255})
{
    Custom_Points2({{1174, 970},{1348, 989},{1336, 945},{1435, 921},{1582, 927}}, currentScene.starsColor);
    Custom_Points2({{1174, 970},{1348, 989},{1336, 945},{1435, 921},{1582, 927}}, currentScene.starsColor, 400);
    Custom_Points2({{1174, 970},{1348, 989},{1336, 945},{1435, 921},{1582, 927}}, currentScene.starsColor, -200);
    Custom_Points2({{1174, 970},{1348, 989},{1336, 945},{1435, 921},{1582, 927}}, currentScene.starsColor, -600, -100);
    Custom_Points2({{1174, 970},{1348, 989},{1336, 945},{1435, 921},{1582, 927}}, currentScene.starsColor, -600, -150);
    Custom_Points2({{1174, 970},{1348, 989},{1336, 945},{1435, 921},{1582, 927}}, currentScene.starsColor, -1000, -150);

    Custom_Points1({{256, 1004},{349, 962},{279, 953},{283, 872},{406, 936},{406, 857},{370, 814},{341, 723},{321, 757},{584, 1021},{514, 983},{618, 970},{735, 962},
        {828, 893},{784, 1011},{915, 989},{932, 874},{835, 727},{780, 791},{854, 802},{990, 712},{918, 650},{765, 586},{1246, 561},{1374, 753},{1212, 893},
        {1306, 1030},{1369, 970},{1476, 913},{1480, 849},{1325, 870},{1240, 774},{1077, 1026},{1043, 942},{1204, 983},{1792, 761},{1779, 866},{1679, 810},
        {1603, 868},{1616, 893},{1537, 759},{1607, 744},{1514, 684},{1467, 537},{1376, 631},{1276, 667},{1249, 603},{1344, 535},{1823, 1011},{1872, 927},
        {1887, 1028},{1450, 1075}}, currentScene.starsColor, -150);
}





public:
void display()
{
    glClearColor(1, 1, 1, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    Sky();
    StarsCoordinate();
    SunCoordinate();
    Hill();
    Riverflow();
    Land();
    LandRiverSide();
    Boat();
    Road();
    MetroLine();
    House();
    Flyover();
    RocketStation();
    Rocket();
    glFlush();  // Render now
    glutSwapBuffers();

}

};
class SeaView
{




// animations function logics


// Custom Functions
void Custom_Points1(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255, 255, 255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glPointSize(2);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}

void Custom_Points2(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255, 255, 255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glPointSize(4);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}

void Custom_Points3(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255, 255, 255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glPointSize(10);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}

void Custom_Polygon(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255, 255, 255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POLYGON);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}
void FullcircleWithLines(float radius, float xC, float yC, Custom_Color Custom_Color = {255,255,255})
{
    glPointSize(0.5);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POINTS);
    for(int i=0; i<250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 3.1416;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+xC, y+yC);
    }
    glEnd();
}
void Halfcircle(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255, 255, 255})
{
    glBegin(GL_POLYGON);
    for (int i = 0; i < 250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i * 2 * pi) / 250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x + Tx, y + Ty);
    }
    glEnd();
}

void HalfcircleWithLines(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255, 255, 255})
{
    glPointSize(0.5);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POINTS);
    for (int i = 0; i < 250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i * 2 * pi) / 250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x + Tx, y + Ty);
    }
    glEnd();
}

void HalfcircleBorder(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255, 255, 255})
{
    glPointSize(0.1);
    glBegin(GL_POINTS);
    for (int i = 0; i < 250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i * 2 * pi) / 250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x + Tx, y + Ty);
    }
    glEnd();
}

void Fullcircle(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255, 255, 255})
{
    glBegin(GL_POLYGON);
    for (int i = 0; i < 250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 3.1416;
        float A = (i * 2 * pi) / 250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x + Tx, y + Ty);
    }
    glEnd();
}

void FullcircleBorder(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255, 255, 255})
{
    glLineWidth(3);
    glBegin(GL_LINES);
    for (int i = 0; i < 250; i++)
    {
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 3.1416;
        float A = (i * 2 * pi) / 250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x + Tx, y + Ty);
    }
    glEnd();
}

void Linestrip(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255, 255, 255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glLineWidth(1);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_LINE_STRIP);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}
void Linestrip2(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255, 255, 255}, float lineWidth = 1, float Tx = 0, float Ty = 0, float s = 1)
{
    glLineWidth(lineWidth);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_LINE_STRIP);
    for (int i = 0; i < coord.size(); i++)
    {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}


///////////////////////Day//////////////////////////////////

void beach()
{
    Custom_Polygon({{0, 333}, {1920, 333}, {1920, 17}, {0, 17}}, currentScene.sbwaterColor);
    // Custom_Polygon({{30, 23},{31, 277},{384, 260},{448, 297},{600,258},{971,283},{1273,274},{1571,286},{1818,301},{1920,16}}, currentScene.sbwaterColor);
}
void background()
{

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0, 100, 0);
    Custom_Polygon({{0, 700}, {1920, 700}, {1920, 1080}, {0, 1080}}, currentScene.sbbackground);
    /*Custom_Polygon({{655, 514},{657, 483},{635, 467},{639, 443},{659, 457},{652, 372},{705, 373},{685, 417},{686, 479},{684,515}}, currentScene.sbtreeu,-610,200);
    //Custom_Polygon({{0, 385},{0, 425},{70, 450},{98, 471},{131,452},{163,460},{173,441},{195,425},{232,422},{239,401},{218,385}}, currentScene.sbtreeColor,0,200);
     Fullcircle(40,25,760,currentScene.sbtreeColor);

      Fullcircle(40,65,790,currentScene.sbtreeColor);
       Fullcircle(40,95,760,currentScene.sbtreeColor);
        Fullcircle(35,50,750,currentScene.sbtreeColor2);
        Fullcircle(35,80,720,currentScene.sbtreeColor2);
         Fullcircle(35,25,720,currentScene.sbtreeColor2);
         Fullcircle(30,3,660,currentScene.sbtreeColor2);*/
    glPopMatrix();
}

void background2()
{
    Custom_Polygon({{0, 335}, {0, 710}, {1920, 710}, {1920, 335}}, currentScene.sbbackground2);
}

void cloud()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(50, 30, 0);
    Fullcircle(35, 400, 1000, currentScene.sbcloud);
    Fullcircle(35, 440, 1000, currentScene.sbcloud);
    Halfcircle(35, 430, 950, currentScene.sbcloud);
    Fullcircle(30, 1000, 970, currentScene.sbcloud);
    Fullcircle(30, 1020, 990, currentScene.sbcloud);
    Halfcircle(30, 1040, 950, currentScene.sbcloud);
    Halfcircle(60, 850, 970, currentScene.sbcloud);
    Halfcircle(60, 800, 950, currentScene.sbcloud);
    Halfcircle(60, 750, 960, currentScene.sbcloud);

    Fullcircle(30, 50, 970, currentScene.sbcloud);
    Fullcircle(30, 40, 1010, currentScene.sbcloud);
    Halfcircle(30, 30, 960, currentScene.sbcloud);
    glPopMatrix();
}
void tree3()
{
    Fullcircle(30, 660, 900, currentScene.sbtreeColor2);
    Fullcircle(30, 690, 920, currentScene.sbtreeColor2);
    Fullcircle(30, 720, 900, currentScene.sbtreeColor2);
}

void tree4()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0, 100, 0);

    Custom_Polygon({{655, 514}, {657, 483}, {635, 467}, {639, 443}, {659, 457}, {652, 372}, {705, 373}, {685, 417}, {686, 479}, {684, 515}}, currentScene.sbtreeu, -610, 200);
    // Custom_Polygon({{0, 385},{0, 425},{70, 450},{98, 471},{131,452},{163,460},{173,441},{195,425},{232,422},{239,401},{218,385}}, currentScene.sbtreeColor,0,200);
    Fullcircle(40, 25, 760, currentScene.sbtreeColor);

    Fullcircle(40, 65, 790, currentScene.sbtreeColor);
    Fullcircle(40, 95, 760, currentScene.sbtreeColor);
    Fullcircle(35, 50, 750, currentScene.sbtreeColor2);
    Fullcircle(35, 80, 720, currentScene.sbtreeColor2);
    Fullcircle(35, 25, 720, currentScene.sbtreeColor2);
    Fullcircle(30, 3, 660, currentScene.sbtreeColor2);
    Halfcircle(50, 130, 700, currentScene.sbtreeColor2);
    // Fullcircle(30,690,920,currentScene.sbtreeColor2);
    // Fullcircle(30,720,900,currentScene.sbtreeColor2);
    glPopMatrix();
}

void tree5()
{
    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 128, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -350, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -350, 295);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -350, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 228, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -250, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -250, 295);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -250, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 528, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 50, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 50, 295);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 50, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 698, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 220, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 220, 295);

    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 220, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 868, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 390, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 390, 295);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 390, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1038, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 560, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 560, 295);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 560, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1208, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 730, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 730, 295);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 730, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1378, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 900, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 900, 295);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 900, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1548, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1070, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1070, 295);

    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1070, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1718, 650);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1240, 290);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1240, 295);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1240, 300);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 128, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -350, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -350, 155);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -350, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 228, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -250, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -250, 155);

    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, -250, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 528, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 50, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 50, 155);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 50, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 698, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 220, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 220, 155);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 220, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 868, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 390, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 390, 155);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 390, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1038, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 560, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 560, 155);

    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 560, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1208, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 730, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 730, 155);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 730, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1378, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 900, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 900, 155);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 900, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1548, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1070, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1070, 155);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1070, 150);

    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbbuilding1, 5, 1718, 505);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1240, 160);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1240, 155);
    Custom_Polygon({{530, 455}, {550, 426}, {505, 426}}, currentScene.sbtreeColor3, 1240, 150);
}

void road()
{
    Custom_Polygon({{0, 580}, {0, 700}, {1920, 700}, {1920, 580}}, currentScene.sbroad);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 1300, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 1150, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 1000, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 850, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 700, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 550, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 400, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 250, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 100, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, -50, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 1450, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 1600, 585);
    Linestrip2({{50, 50}, {120, 50}}, currentScene.sbbuilding3, 8, 1750, 585);
}
void road1()
{

    Custom_Polygon({{0, 180}, {0, 270}, {1920, 270}, {1920, 180}}, currentScene.sbtreeColor2, 0, 530);
}
//////////////////////Left1////////////////
void building1()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(20, 500, 0);
    glScaled(1.2, 0.6, 0);
    Custom_Polygon({{131, 452}, {131, 791}, {148, 791}, {148, 842}, {225, 842}, {225, 791}, {244, 791}, {244, 401}}, currentScene.sbbuilding1);
    Custom_Polygon({{244, 793}, {244, 401}, {265, 401}, {265, 791}, {239, 401}}, currentScene.sbbuildingd);
    Custom_Polygon({{244, 791}, {244, 842}, {225, 842}, {225, 791}}, currentScene.sbbuildingd2);
    Custom_Polygon({{157, 831}, {170, 831}, {170, 460}, {157, 460}}, currentScene.sbbuildingd3);
    Custom_Polygon({{180, 831}, {194, 831}, {194, 430}, {180, 440}}, currentScene.sbbuildingd4);
    Custom_Polygon({{203, 831}, {215, 831}, {215, 427}, {203, 428}}, currentScene.sbbuildingd5);
    Custom_Polygon({{136, 775}, {150, 775}, {150, 762}, {136, 762}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 755}, {150, 755}, {150, 744}, {136, 744}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 736}, {150, 736}, {150, 726}, {136, 726}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 719}, {150, 719}, {150, 707}, {136, 707}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 700}, {150, 700}, {150, 690}, {136, 690}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 681}, {150, 681}, {150, 671}, {136, 671}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 663}, {150, 663}, {150, 653}, {136, 653}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 644}, {150, 644}, {150, 634}, {136, 634}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 625}, {150, 625}, {150, 616}, {136, 616}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 606}, {150, 606}, {150, 596}, {136, 596}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 588}, {150, 588}, {150, 578}, {136, 578}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 569}, {150, 569}, {150, 559}, {136, 559}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 552}, {150, 552}, {150, 543}, {136, 543}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 534}, {150, 534}, {150, 524}, {136, 524}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 514}, {150, 514}, {150, 505}, {136, 505}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 496}, {150, 496}, {150, 486}, {136, 486}}, currentScene.sbwindow1);
    Custom_Polygon({{136, 479}, {150, 479}, {150, 467}, {136, 467}}, currentScene.sbwindow1);

    Custom_Polygon({{228, 775}, {239, 775}, {239, 762}, {228, 762}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 755}, {239, 755}, {239, 744}, {228, 744}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 736}, {239, 736}, {239, 726}, {228, 726}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 719}, {239, 719}, {239, 707}, {228, 707}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 700}, {239, 700}, {239, 690}, {228, 690}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 681}, {239, 681}, {239, 671}, {228, 671}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 663}, {239, 663}, {239, 653}, {228, 653}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 644}, {239, 644}, {239, 634}, {228, 634}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 625}, {239, 625}, {239, 616}, {228, 616}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 606}, {239, 606}, {239, 596}, {228, 596}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 588}, {239, 588}, {239, 578}, {228, 578}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 569}, {239, 569}, {239, 559}, {228, 559}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 552}, {239, 552}, {239, 543}, {228, 543}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 534}, {239, 534}, {239, 524}, {228, 524}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 514}, {239, 514}, {239, 505}, {228, 505}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 496}, {239, 496}, {239, 486}, {228, 486}}, currentScene.sbwindow1);
    Custom_Polygon({{228, 479}, {239, 479}, {239, 467}, {228, 467}}, currentScene.sbwindow1);
    glPopMatrix();
}

///////////////////Left6///////////////
void building6()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(-200, 200, 0);
    glScaled(1, 0.9, 0);
    Custom_Polygon({{669, 394}, {841, 394}, {841, 600}, {669, 600}}, currentScene.sbbuilding6, 620, 205);
    Custom_Polygon({{822, 412}, {822, 425}, {688, 425}, {688, 412}}, currentScene.sbbuilding3, 620, 205);
    Custom_Polygon({{822, 412}, {822, 425}, {688, 425}, {688, 412}}, currentScene.sbbuilding3, 620, 230);
    Custom_Polygon({{822, 412}, {822, 425}, {688, 425}, {688, 412}}, currentScene.sbbuilding3, 620, 255);
    Custom_Polygon({{822, 412}, {822, 425}, {688, 425}, {688, 412}}, currentScene.sbbuilding3, 620, 280);
    Custom_Polygon({{822, 412}, {822, 425}, {688, 425}, {688, 412}}, currentScene.sbbuilding3, 620, 305);
    Custom_Polygon({{822, 412}, {822, 425}, {688, 425}, {688, 412}}, currentScene.sbbuilding3, 620, 330);
    Custom_Polygon({{822, 412}, {822, 425}, {688, 425}, {688, 412}}, currentScene.sbbuilding3, 620, 355);
    glPopMatrix();
}
//////////////////////Left5///////////////////
void building4()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(140, 450, 0);
    glScaled(1, 0.7, 0);
    Custom_Polygon({{603, 809}, {946, 809}, {946, 400}, {603, 400}}, currentScene.sbbuilding3);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 25);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 50);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 75);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 100);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 125);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 150);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 175);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 200);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 225);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 250);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 275);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 300);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 325);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 350);
    Custom_Polygon({{622, 412}, {622, 423}, {948, 423}, {948, 412}}, currentScene.sbwindow2, 0, 375);
    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3);
    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 25);
    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 50);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 75);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 100);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 125);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 150);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 175);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 200);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 225);
    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 250);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 275);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 300);

    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 325);
    Custom_Polygon({{946, 423}, {960, 423}, {960, 436}, {946, 436}}, currentScene.sbwindow3, 0, 350);

    glPopMatrix();
}
////////////////////////Left3////////////////
void building3()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(-70, 430, 0);
    glScaled(1.1, 0.8, 0);
    Custom_Polygon({{460, 683}, {576, 683}, {576, 396}, {460, 396}}, currentScene.sbbuilding3);
    Custom_Polygon({{468, 396}, {475, 396}, {475, 683}, {468, 683}}, currentScene.sbwindow2);
    Custom_Polygon({{468, 396}, {475, 396}, {475, 683}, {468, 683}}, currentScene.sbwindow2, 16, 0);
    Custom_Polygon({{468, 396}, {475, 396}, {475, 683}, {468, 683}}, currentScene.sbwindow2, 32, 0);
    Custom_Polygon({{468, 396}, {475, 396}, {475, 683}, {468, 683}}, currentScene.sbwindow2, 48, 0);
    Custom_Polygon({{468, 396}, {475, 396}, {475, 683}, {468, 683}}, currentScene.sbwindow2, 64, 0);
    Custom_Polygon({{468, 396}, {475, 396}, {475, 683}, {468, 683}}, currentScene.sbwindow2, 80, 0);
    Custom_Polygon({{468, 396}, {475, 396}, {475, 683}, {468, 683}}, currentScene.sbwindow2, 96, 0);

    glPopMatrix();
}
///////////////////////Left2///////////////
void building2()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(-65, 320, 0);
    glScaled(1.3, 1, 0);
    Custom_Polygon({{303, 585}, {399, 585}, {399, 393}, {303, 393}}, currentScene.sbbuilding2);
    Custom_Polygon({{312, 573}, {321, 573}, {321, 563}, {312, 563}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 573}, {341, 573}, {341, 563}, {329, 563}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 573}, {358, 573}, {358, 563}, {348, 563}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 573}, {374, 573}, {374, 563}, {367, 563}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 573}, {394, 573}, {394, 563}, {385, 563}}, currentScene.sbwindow1);
    Custom_Polygon({{312, 556}, {321, 556}, {321, 547}, {312, 547}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 556}, {341, 556}, {341, 547}, {329, 547}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 556}, {358, 556}, {358, 547}, {348, 547}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 556}, {374, 556}, {374, 547}, {367, 547}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 556}, {394, 556}, {394, 547}, {385, 547}}, currentScene.sbwindow1);

    Custom_Polygon({{312, 540}, {321, 540}, {321, 531}, {312, 531}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 540}, {341, 540}, {341, 531}, {329, 531}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 540}, {358, 540}, {358, 531}, {348, 531}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 540}, {374, 540}, {374, 531}, {367, 531}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 540}, {394, 540}, {394, 531}, {385, 531}}, currentScene.sbwindow1);
    Custom_Polygon({{312, 523}, {321, 523}, {321, 515}, {312, 515}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 523}, {341, 523}, {341, 515}, {329, 515}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 523}, {358, 523}, {358, 515}, {348, 515}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 523}, {374, 523}, {374, 515}, {367, 515}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 523}, {394, 523}, {394, 515}, {385, 515}}, currentScene.sbwindow1);

    Custom_Polygon({{312, 507}, {321, 507}, {321, 497}, {312, 497}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 507}, {341, 507}, {341, 497}, {329, 497}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 507}, {358, 507}, {358, 497}, {348, 497}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 507}, {374, 507}, {374, 497}, {367, 497}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 507}, {394, 507}, {394, 497}, {385, 497}}, currentScene.sbwindow1);
    Custom_Polygon({{312, 490}, {321, 490}, {321, 481}, {312, 481}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 490}, {341, 490}, {341, 481}, {329, 481}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 490}, {358, 490}, {358, 481}, {348, 481}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 490}, {374, 490}, {374, 481}, {367, 481}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 490}, {394, 490}, {394, 481}, {385, 481}}, currentScene.sbwindow1);

    Custom_Polygon({{312, 473}, {321, 473}, {321, 465}, {312, 465}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 473}, {341, 473}, {341, 465}, {329, 465}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 473}, {358, 473}, {358, 465}, {348, 465}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 473}, {374, 473}, {374, 465}, {367, 465}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 473}, {394, 473}, {394, 465}, {385, 465}}, currentScene.sbwindow1);
    Custom_Polygon({{312, 457}, {321, 457}, {321, 448}, {312, 448}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 457}, {341, 457}, {341, 448}, {329, 448}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 457}, {358, 457}, {358, 448}, {348, 448}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 457}, {374, 457}, {374, 448}, {367, 448}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 457}, {394, 457}, {394, 448}, {385, 448}}, currentScene.sbwindow1);

    Custom_Polygon({{312, 440}, {321, 440}, {321, 432}, {312, 432}}, currentScene.sbwindow1);
    Custom_Polygon({{329, 440}, {341, 440}, {341, 432}, {329, 432}}, currentScene.sbwindow1);
    Custom_Polygon({{348, 440}, {358, 440}, {358, 432}, {348, 432}}, currentScene.sbwindow1);
    Custom_Polygon({{367, 440}, {374, 440}, {374, 432}, {367, 432}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 440}, {394, 440}, {394, 432}, {385, 432}}, currentScene.sbwindow1);
    Custom_Polygon({{332, 424}, {376, 424}, {376, 420}, {332, 420}}, currentScene.sbwindow1);
    Custom_Polygon({{385, 424}, {394, 424}, {394, 409}, {385, 409}}, currentScene.sbwindow1);
    Custom_Polygon({{336, 412}, {370, 412}, {370, 393}, {336, 393}}, currentScene.sbwindow1);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbwindow1);
    glPopMatrix();
}
//////////////////Left4//////////////////////

void building5()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(-560, 0, 0);
    glScaled(1, 1.2, 0);
    Custom_Polygon({{513, 393}, {670, 393}, {670, 544}, {513, 544}}, currentScene.sbbuilding1, 600, 205);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 600, 215);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 600, 255);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 600, 295);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 650, 215);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 650, 255);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 650, 295);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 700, 215);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 700, 255);
    Custom_Polygon({{532, 406}, {558, 406}, {558, 431}, {532, 431}}, currentScene.sbbuilding3, 700, 295);
    Custom_Polygon({{531, 544}, {584, 544}, {584, 565}, {531, 565}}, currentScene.sbbuilding1, 601, 205);

    glPopMatrix();
}
///////////////Right//////////////////

void building7()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(1430, 460, 0);
    glScaled(0.8, 0.7, 0);
    Custom_Polygon({{303, 785}, {599, 785}, {599, 393}, {303, 393}}, currentScene.sbbuilding7);

    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, 25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, 50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, 75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, 100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, 125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, 150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, 175);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, -25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, -50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, -75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, -100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, -125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, -150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 0, -175);

    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, 0);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, 25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, 50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, 75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, 100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, 125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, 150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, 175);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, -25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, -50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, -75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, -100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, -125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, -150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 45, -175);

    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, 0);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, 25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, 50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, 75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, 100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, 125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, 150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, 175);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, -25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, -50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, -75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, -100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 90, -125);

    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, 0);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, 25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, 50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, 75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, 100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, 125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, 150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, 175);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, -25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, -50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, -75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, -100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 135, -125);

    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, 0);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, 25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, 50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, 75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, 100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, 125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, 150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, 175);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, -25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, -50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, -75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, -100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, -125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, -150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 180, -175);

    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, 0);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, 25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, 50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, 75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, 100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, 125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, 150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, 175);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, -25);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, -50);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, -75);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, -100);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, -125);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, -150);
    Custom_Polygon({{326, 585}, {326, 600}, {352, 600}, {352, 585}}, currentScene.sbbuilding3, 225, -175);
    Linestrip2({{50, 50}, {500, 50}}, currentScene.sbbuilding7u, 12, 250, 740);
    Linestrip2({{50, 50}, {50, 457}}, currentScene.sbbuilding7u, 12, 250, 345);

    glPopMatrix();
}
//////////////Right door////////////////
void door()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(110, 280, 0);
    glScaled(0.9, 0.7, 0);
    // Custom_Polygon({{1563, 450},{1563,500},{1640,500},{1640,450}}, currentScene.sbbuilding3,270,200);
    Custom_Polygon({{1565, 452}, {1565, 850}, {1635, 850}, {1635, 452}}, currentScene.sbbuilding7u, 270, 200);
    glPopMatrix();
}

void mosque()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(190, 410, 0);
    glScaled(1.4, 1.1, 0);
    Custom_Polygon({{894, 442}, {1031, 442}, {1031, 298}, {894, 298}}, currentScene.sbmosque);
    Custom_Polygon({{901, 492}, {954, 492}, {955, 442}, {901, 442}}, currentScene.sbmosque);
    Custom_Polygon({{911, 508}, {944, 508}, {944, 492}, {911, 492}}, currentScene.sbmosque);
    Custom_Polygon({{918, 508}, {919, 522}, {927, 546}, {936, 521}, {937, 508}}, currentScene.sbmosque);
    Custom_Polygon({{968, 442}, {968, 492}, {1023, 492}, {1023, 442}}, currentScene.sbmosque);
    Custom_Polygon({{978, 492}, {978, 514}, {996, 526}, {1013, 514}, {1013, 492}}, currentScene.sbmosque);
    Custom_Polygon({{908, 453}, {908, 474}, {926, 474}, {926, 453}}, currentScene.sbmosquew);
    Custom_Polygon({{908, 453}, {908, 474}, {926, 474}, {926, 453}}, currentScene.sbmosquew, 25, 0);
    Custom_Polygon({{908, 453}, {908, 474}, {926, 474}, {926, 453}}, currentScene.sbmosquew, 65, 0);
    Custom_Polygon({{908, 453}, {908, 474}, {926, 474}, {926, 453}}, currentScene.sbmosquew, 90, 0);

    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 18, 0);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 0, -15);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 18, -15);

    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 0, -40);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 18, -40);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 0, -55);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 18, -55);

    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 0, -80);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 18, -80);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 0, -95);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 18, -95);

    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 75, 0);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 92, 0);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 75, -15);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 92, -15);

    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 75, -40);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 92, -40);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 75, -55);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 92, -55);

    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 75, -80);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 92, -80);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 75, -95);
    Custom_Polygon({{906, 425}, {906, 438}, {921, 438}, {921, 425}}, currentScene.sbmosquew, 92, -95);

    Linestrip2({{50, 50}, {50, 150}}, currentScene.sbcloud, 8, 917, 280);
    Linestrip2({{50, 50}, {50, 150}}, currentScene.sbcloud, 8, 902, 280);
    Linestrip2({{50, 50}, {50, 80}}, currentScene.sbmosque, 6, 945, 470);

    glPopMatrix();
}

void chair1()

{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0, 100, 0);
    Custom_Polygon({{153, 271}, {155, 270}, {157, 272}, {153, 287}, {157, 287}, {192, 294}, {193, 295}, {197, 279}, {200, 278}, {201, 280}, {193, 306}, {175, 313}, {174, 311}, {167, 334}, {167, 342}, {165, 350}, {161, 352}, {156, 351}, {137, 349}, {122, 350}, {119, 349}, {116, 346}, {122, 321}, {128, 307}, {120, 285}, {121, 283}, {123, 283}, {131, 300}, {133, 296}, {147, 290}}, currentScene.sbumbrella);

    Custom_Polygon({{155, 290}, {151, 291}, {149, 301}, {132, 308}, {121, 339}, {124, 347}, {142, 347}, {157, 349}, {162, 348}, {164, 345}, {173, 307}, {187, 293}}, currentScene.sbseat);
    Custom_Polygon({{133, 302}, {135, 293}, {145, 288}, {143, 296}}, currentScene.sbseat);
    Custom_Polygon({{209, 323}, {210, 317}, {216, 317}, {217, 323}, {224, 322}, {229, 320}, {232, 318}, {232, 316}, {229, 314}, {225, 312}, {221, 311}, {215, 311}, {213, 307}, {213, 301}, {214, 296}, {215, 294}, {219, 292}, {218, 291}, {215, 290}, {210, 290}, {206, 291}, {203, 292}, {207, 294}, {208, 298}, {209, 303}, {209, 307}, {207, 310}, {200, 311}, {194, 313}, {190, 316}, {191, 319}, {199, 322}}, currentScene.sbumbrella);
    Custom_Polygon({{118, 381}, {154, 376}, {197, 378}, {235, 384}, {266, 395}, {191, 425}}, currentScene.sbumbrella);
    Custom_Polygon({{197, 322}, {204, 323}, {196, 390}, {204, 400}, {200, 399}, {195, 394}, {195, 399}, {191, 399}, {192, 393}, {186, 398}, {182, 398}, {192, 389}}, currentScene.sbshop3b);
    Custom_Polygon({{197, 311}, {204, 311}, {204, 300}, {197, 300}}, currentScene.sbshop3b);
    Custom_Polygon({{216, 280}, {217, 279}, {221, 280}, {225, 295}, {226, 294}, {262, 287}, {264, 288}, {260, 273}, {262, 271}, {264, 272}, {270, 290}, {284, 297}, {286, 301}, {294, 283}, {296, 282}, {298, 285}, {289, 307}, {301, 342}, {299, 347}, {296, 349}, {273, 349}, {259, 352}, {255, 351}, {252, 348}, {248, 330}, {243, 311}, {241, 313}, {224, 306}}, currentScene.sbumbrella);

    Custom_Polygon({{232, 297}, {268, 306}, {255, 346}, {256, 348}, {260, 347}, {289, 345}, {294, 345}, {296, 342}, {268, 301}, {265, 291}, {262, 290}}, currentScene.sbseat);

    Custom_Polygon({{275, 295}, {282, 308}, {285, 299}, {280, 290}}, currentScene.sbseat);

    glPopMatrix();
}

void chair2()
{

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0, 100, 0);
    Custom_Polygon({{153, 271}, {155, 270}, {157, 272}, {153, 287}, {157, 287}, {192, 294}, {193, 295}, {197, 279}, {200, 278}, {201, 280}, {193, 306}, {175, 313}, {174, 311}, {167, 334}, {167, 342}, {165, 350}, {161, 352}, {156, 351}, {137, 349}, {122, 350}, {119, 349}, {116, 346}, {122, 321}, {128, 307}, {120, 285}, {121, 283}, {123, 283}, {131, 300}, {133, 296}, {147, 290}}, currentScene.sbumbrella, 500, 0);

    Custom_Polygon({{155, 290}, {151, 291}, {149, 301}, {132, 308}, {121, 339}, {124, 347}, {142, 347}, {157, 349}, {162, 348}, {164, 345}, {173, 307}, {187, 293}}, currentScene.sbseat, 500, 0);
    Custom_Polygon({{133, 302}, {135, 293}, {145, 288}, {143, 296}}, currentScene.sbseat, 500, 0);
    Custom_Polygon({{209, 323}, {210, 317}, {216, 317}, {217, 323}, {224, 322}, {229, 320}, {232, 318}, {232, 316}, {229, 314}, {225, 312}, {221, 311}, {215, 311}, {213, 307}, {213, 301}, {214, 296}, {215, 294}, {219, 292}, {218, 291}, {215, 290}, {210, 290}, {206, 291}, {203, 292}, {207, 294}, {208, 298}, {209, 303}, {209, 307}, {207, 310}, {200, 311}, {194, 313}, {190, 316}, {191, 319}, {199, 322}}, currentScene.sbumbrella, 500, 0);
    Custom_Polygon({{118, 381}, {154, 376}, {197, 378}, {235, 384}, {266, 395}, {191, 425}}, currentScene.sbumbrella, 500, 0);
    Custom_Polygon({{197, 322}, {204, 323}, {196, 390}, {204, 400}, {200, 399}, {195, 394}, {195, 399}, {191, 399}, {192, 393}, {186, 398}, {182, 398}, {192, 389}}, currentScene.sbshop3b, 500, 0);
    Custom_Polygon({{197, 311}, {204, 311}, {204, 300}, {197, 300}}, currentScene.sbshop3b, 500, 0);
    Custom_Polygon({{216, 280}, {217, 279}, {221, 280}, {225, 295}, {226, 294}, {262, 287}, {264, 288}, {260, 273}, {262, 271}, {264, 272}, {270, 290}, {284, 297}, {286, 301}, {294, 283}, {296, 282}, {298, 285}, {289, 307}, {301, 342}, {299, 347}, {296, 349}, {273, 349}, {259, 352}, {255, 351}, {252, 348}, {248, 330}, {243, 311}, {241, 313}, {224, 306}}, currentScene.sbumbrella, 500, 0);

    Custom_Polygon({{232, 297}, {268, 306}, {255, 346}, {256, 348}, {260, 347}, {289, 345}, {294, 345}, {296, 342}, {268, 301}, {265, 291}, {262, 290}}, currentScene.sbseat, 500, 0);

    Custom_Polygon({{275, 295}, {282, 308}, {285, 299}, {280, 290}}, currentScene.sbseat, 500, 0);
    glPopMatrix();
}
void chair3()

{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0, 100, 0);
    Custom_Polygon({{153, 271}, {155, 270}, {157, 272}, {153, 287}, {157, 287}, {192, 294}, {193, 295}, {197, 279}, {200, 278}, {201, 280}, {193, 306}, {175, 313}, {174, 311}, {167, 334}, {167, 342}, {165, 350}, {161, 352}, {156, 351}, {137, 349}, {122, 350}, {119, 349}, {116, 346}, {122, 321}, {128, 307}, {120, 285}, {121, 283}, {123, 283}, {131, 300}, {133, 296}, {147, 290}}, currentScene.sbumbrella, 1000, 0);

    Custom_Polygon({{155, 290}, {151, 291}, {149, 301}, {132, 308}, {121, 339}, {124, 347}, {142, 347}, {157, 349}, {162, 348}, {164, 345}, {173, 307}, {187, 293}}, currentScene.sbseat, 1000, 0);
    Custom_Polygon({{133, 302}, {135, 293}, {145, 288}, {143, 296}}, currentScene.sbseat, 1000, 0);
    Custom_Polygon({{209, 323}, {210, 317}, {216, 317}, {217, 323}, {224, 322}, {229, 320}, {232, 318}, {232, 316}, {229, 314}, {225, 312}, {221, 311}, {215, 311}, {213, 307}, {213, 301}, {214, 296}, {215, 294}, {219, 292}, {218, 291}, {215, 290}, {210, 290}, {206, 291}, {203, 292}, {207, 294}, {208, 298}, {209, 303}, {209, 307}, {207, 310}, {200, 311}, {194, 313}, {190, 316}, {191, 319}, {199, 322}}, currentScene.sbumbrella, 1000, 0);
    Custom_Polygon({{118, 381}, {154, 376}, {197, 378}, {235, 384}, {266, 395}, {191, 425}}, currentScene.sbumbrella, 1000, 0);
    Custom_Polygon({{197, 322}, {204, 323}, {196, 390}, {204, 400}, {200, 399}, {195, 394}, {195, 399}, {191, 399}, {192, 393}, {186, 398}, {182, 398}, {192, 389}}, currentScene.sbshop3b, 1000, 0);
    Custom_Polygon({{197, 311}, {204, 311}, {204, 300}, {197, 300}}, currentScene.sbshop3b, 1000, 0);
    Custom_Polygon({{216, 280}, {217, 279}, {221, 280}, {225, 295}, {226, 294}, {262, 287}, {264, 288}, {260, 273}, {262, 271}, {264, 272}, {270, 290}, {284, 297}, {286, 301}, {294, 283}, {296, 282}, {298, 285}, {289, 307}, {301, 342}, {299, 347}, {296, 349}, {273, 349}, {259, 352}, {255, 351}, {252, 348}, {248, 330}, {243, 311}, {241, 313}, {224, 306}}, currentScene.sbumbrella, 1000, 0);

    Custom_Polygon({{232, 297}, {268, 306}, {255, 346}, {256, 348}, {260, 347}, {289, 345}, {294, 345}, {296, 342}, {268, 301}, {265, 291}, {262, 290}}, currentScene.sbseat, 1000, 0);

    Custom_Polygon({{275, 295}, {282, 308}, {285, 299}, {280, 290}}, currentScene.sbseat, 1000, 0);

    glPopMatrix();
}

void chair4()

{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0, 100, 0);
    Custom_Polygon({{153, 271}, {155, 270}, {157, 272}, {153, 287}, {157, 287}, {192, 294}, {193, 295}, {197, 279}, {200, 278}, {201, 280}, {193, 306}, {175, 313}, {174, 311}, {167, 334}, {167, 342}, {165, 350}, {161, 352}, {156, 351}, {137, 349}, {122, 350}, {119, 349}, {116, 346}, {122, 321}, {128, 307}, {120, 285}, {121, 283}, {123, 283}, {131, 300}, {133, 296}, {147, 290}}, currentScene.sbumbrella, 1500, 0);

    Custom_Polygon({{155, 290}, {151, 291}, {149, 301}, {132, 308}, {121, 339}, {124, 347}, {142, 347}, {157, 349}, {162, 348}, {164, 345}, {173, 307}, {187, 293}}, currentScene.sbseat, 1500, 0);
    Custom_Polygon({{133, 302}, {135, 293}, {145, 288}, {143, 296}}, currentScene.sbseat, 1500, 0);
    Custom_Polygon({{209, 323}, {210, 317}, {216, 317}, {217, 323}, {224, 322}, {229, 320}, {232, 318}, {232, 316}, {229, 314}, {225, 312}, {221, 311}, {215, 311}, {213, 307}, {213, 301}, {214, 296}, {215, 294}, {219, 292}, {218, 291}, {215, 290}, {210, 290}, {206, 291}, {203, 292}, {207, 294}, {208, 298}, {209, 303}, {209, 307}, {207, 310}, {200, 311}, {194, 313}, {190, 316}, {191, 319}, {199, 322}}, currentScene.sbumbrella, 1500, 0);
    Custom_Polygon({{118, 381}, {154, 376}, {197, 378}, {235, 384}, {266, 395}, {191, 425}}, currentScene.sbumbrella, 1500, 0);
    Custom_Polygon({{197, 322}, {204, 323}, {196, 390}, {204, 400}, {200, 399}, {195, 394}, {195, 399}, {191, 399}, {192, 393}, {186, 398}, {182, 398}, {192, 389}}, currentScene.sbshop3b, 1500, 0);
    Custom_Polygon({{197, 311}, {204, 311}, {204, 300}, {197, 300}}, currentScene.sbshop3b, 1500, 0);
    Custom_Polygon({{216, 280}, {217, 279}, {221, 280}, {225, 295}, {226, 294}, {262, 287}, {264, 288}, {260, 273}, {262, 271}, {264, 272}, {270, 290}, {284, 297}, {286, 301}, {294, 283}, {296, 282}, {298, 285}, {289, 307}, {301, 342}, {299, 347}, {296, 349}, {273, 349}, {259, 352}, {255, 351}, {252, 348}, {248, 330}, {243, 311}, {241, 313}, {224, 306}}, currentScene.sbumbrella, 1500, 0);

    Custom_Polygon({{232, 297}, {268, 306}, {255, 346}, {256, 348}, {260, 347}, {289, 345}, {294, 345}, {296, 342}, {268, 301}, {265, 291}, {262, 290}}, currentScene.sbseat, 1500, 0);

    Custom_Polygon({{275, 295}, {282, 308}, {285, 299}, {280, 290}}, currentScene.sbseat, 1500, 0);

    glPopMatrix();
}
//////////////Right
void tree()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(750, 400, 0);

    glScaled(0.5, 0.5, 0);

    Custom_Polygon({{1344, 433}, {1320, 401}, {1291, 403}, {1280, 394}, {1265, 387}, {1248, 395}, {1228, 388}, {1207, 396}, {1202, 418}, {1165, 436}, {1168, 474}, {1183, 492}, {1216, 498}, {1212, 530}, {1229, 555}, {1255, 560}, {1275, 588}, {1305, 597}, {1336, 589}, {1358, 552}, {1392, 576}, {1428, 568}, {1449, 548}, {1459, 526}, {1454, 508}, {1486, 487}, {1489, 454}, {1480, 432}, {1458, 419}, {1445, 404}, {1429, 386}, {1392, 387}, {1378, 399}, {1369, 409}, {1359, 411}}, currentScene.sbtreeColor, -130, 380);
    Custom_Polygon({{1320, 401}, {1291, 403}, {1280, 394}, {1304, 374}, {1291, 262}, {1265, 230}, {1291, 232}, {1313, 242}, {1337, 223}, {1340, 240}, {1393, 228}, {1373, 255}, {1357, 314}, {1359, 373}, {1378, 399}, {1369, 409}, {1359, 411}, {1335, 390}}, currentScene.sbtreeu, -130, 380);
    Fullcircle(60, 1290, 850, currentScene.sbtreeColor2);
    Fullcircle(60, 1300, 900, currentScene.sbtreeColor2);
    Fullcircle(60, 1250, 950, currentScene.sbtreeColor2);
    Fullcircle(60, 1180, 940, currentScene.sbtreeColor2);
    Fullcircle(60, 1130, 910, currentScene.sbtreeColor2);
    Fullcircle(60, 1100, 850, currentScene.sbtreeColor2);
    Fullcircle(60, 1200, 870, currentScene.sbtreeColor2);
    Fullcircle(60, 1200, 845, currentScene.sbtreeColor2);
    glPopMatrix();
}
/////////////middle
void tree2()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(-10, 270, 0);
    Fullcircle(20, 500, 500, currentScene.sbtreeColor);
    Fullcircle(20, 480, 488, currentScene.sbtreeColor);
    Fullcircle(20, 520, 488, currentScene.sbtreeColor);
    Custom_Polygon({{669, 636}, {679, 646}, {677, 623}, {687, 603}, {653, 602}, {661, 623}, {660, 647}}, currentScene.sbtreeu, -172, -170);
    glPopMatrix();
}

void shop()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0, 40, 0);
    Linestrip2({{50, 55}, {50, 120}}, currentScene.sbshopf, 5, 400, 400);
    Halfcircle(40, 450, 520, currentScene.sbseat);
    Custom_Polygon({{360, 443}, {360, 480}, {430, 480}, {430, 443}}, currentScene.sbshop3, 55, 10);
    Halfcircle(10, 450, 490, currentScene.sbtreeColoro);
    Halfcircle(10, 440, 490, currentScene.sbtreeColoro);
    Halfcircle(10, 430, 490, currentScene.sbtreeColoro);
    Halfcircle(10, 430, 500, currentScene.sbtreeColoro);
    Halfcircle(10, 440, 500, currentScene.sbtreeColoro);
    Halfcircle(10, 450, 500, currentScene.sbtreeColoro);
    Fullcircle(5, 468, 495, currentScene.sbshopf);
    Fullcircle(5, 475, 495, currentScene.sbshopf);
    Fullcircle(5, 482, 495, currentScene.sbshopf);

    glPopMatrix();
}

void shop2()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(1000, -60, 0);
    Linestrip2({{50, 55}, {50, 120}}, currentScene.sbshopf, 5, 400, 400);
    Halfcircle(40, 450, 520, currentScene.sbshop3);
    Custom_Polygon({{360, 443}, {360, 480}, {430, 480}, {430, 443}}, currentScene.sbshop3b, 55, 10);
    Halfcircle(10, 450, 490, currentScene.sbtreeColoro);
    Halfcircle(10, 440, 490, currentScene.sbtreeColoro);
    Halfcircle(10, 430, 490, currentScene.sbtreeColoro);
    Halfcircle(10, 430, 500, currentScene.sbtreeColoro);
    Halfcircle(10, 440, 500, currentScene.sbtreeColoro);
    Halfcircle(10, 450, 500, currentScene.sbtreeColoro);
    Fullcircle(5, 468, 495, currentScene.sbshopf);
    Fullcircle(5, 475, 495, currentScene.sbshopf);
    Fullcircle(5, 482, 495, currentScene.sbshopf);

    glPopMatrix();
}

void moon()
{
    // glMatrixMode(GL_MODELVIEW);
    // glPushMatrix();
    // glTranslatef(1000,60,0);

    Fullcircle(35, 1300, 1050, currentScene.sbmoon);
    Fullcircle(2, 1200, 1050, currentScene.sbstar);

    Fullcircle(2, 1210, 1048, currentScene.sbstar);

    Fullcircle(2, 1180, 1034, currentScene.sbstar);
    Fullcircle(2, 1080, 1029, currentScene.sbstar);
    Fullcircle(2, 975, 1042, currentScene.sbstar);
    Fullcircle(2, 1000, 1055, currentScene.sbstar);
    Fullcircle(2, 1022, 1024, currentScene.sbstar);
    Fullcircle(2, 1008, 1029, currentScene.sbstar);
    Fullcircle(2, 1150, 950, currentScene.sbstar);
    Fullcircle(2, 1166, 966, currentScene.sbstar);
    Fullcircle(2, 1198, 972, currentScene.sbstar);
    Fullcircle(2, 1240, 1000, currentScene.sbstar);
    Fullcircle(2, 1300, 915, currentScene.sbstar);

    Fullcircle(2, 1270, 982, currentScene.sbstar);
    Fullcircle(2, 1350, 1072, currentScene.sbstar);
    Fullcircle(2, 1345, 1077, currentScene.sbstar);
    Fullcircle(2, 1388, 1056, currentScene.sbstar);
    Fullcircle(2, 1108, 788, currentScene.sbstar);
    Fullcircle(2, 1440, 1009, currentScene.sbstar);
    Fullcircle(2, 1500, 1017, currentScene.sbstar);
    Fullcircle(2, 1620, 1029, currentScene.sbstar);

    Fullcircle(2, 1700, 1039, currentScene.sbstar);
    Fullcircle(2, 1900, 1044, currentScene.sbstar);
    Fullcircle(2, 1850, 1066, currentScene.sbstar);
    Fullcircle(2, 1330, 990, currentScene.sbstar);
    Fullcircle(2, 1380, 940, currentScene.sbstar);
    Fullcircle(2, 20, 1055, currentScene.sbstar);
    Fullcircle(2, 22, 1043, currentScene.sbstar);
    Fullcircle(2, 31, 950, currentScene.sbstar);
    Fullcircle(2, 57, 980, currentScene.sbstar);

    Fullcircle(2, 77, 940, currentScene.sbstar);
    Fullcircle(2, 137, 880, currentScene.sbstar);
    Fullcircle(2, 127, 950, currentScene.sbstar);

    Fullcircle(2, 137, 1050, currentScene.sbstar);

    Fullcircle(2, 205, 1045, currentScene.sbstar);

    Fullcircle(2, 295, 1035, currentScene.sbstar);
    Fullcircle(2, 375, 1000, currentScene.sbstar);
    Fullcircle(2, 360, 955, currentScene.sbstar);
    Fullcircle(2, 665, 1042, currentScene.sbstar);
    Fullcircle(2, 555, 1037, currentScene.sbstar);
    Fullcircle(2, 400, 1075, currentScene.sbstar);
    Fullcircle(2, 595, 965, currentScene.sbstar);
    Fullcircle(2, 605, 995, currentScene.sbstar);
    Fullcircle(2, 795, 1054, currentScene.sbstar);
    Fullcircle(2, 865, 1057, currentScene.sbstar);

    // glPopMatrix();
}

void Riverflow(Custom_Color rivershade1Color = {61, 109, 186}, Custom_Color rivershade2Color = {54, 102, 192}, Custom_Color rivershade3Color = {33, 59, 122}, Custom_Color rivershade4Color = {110, 161, 233})
{
    // water
    Custom_Polygon({{1920, 0}, {1920, 350}, {0, 350}, {0, 0}}, currentScene.riverColor, 0, 0);

    // moving water
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(movewatercurrentXs, -120, 0);

    // manual shades
    // type 1
    Custom_Polygon({{1234, 403}, {1402, 397}, {1611, 413}, {1414, 381}}, currentScene.rivershade1Color, -50);
    Custom_Polygon({{1234, 403}, {1402, 397}, {1611, 413}, {1414, 381}}, currentScene.rivershade1Color, -150, 50);
    Custom_Polygon({{1234, 403}, {1402, 397}, {1611, 413}, {1414, 381}}, currentScene.rivershade1Color, -270, 50);
    // type 2
    Custom_Polygon({{1328, 326}, {1593, 337}, {1897, 319}, {1407, 307}}, currentScene.rivershade1Color);
    Custom_Polygon({{1328, 326}, {1593, 337}, {1897, 319}, {1407, 307}}, currentScene.rivershade1Color, -750);

    // type 3
    Custom_Polygon({{568, 401}, {829, 395}, {1086, 410}, {790, 374}}, currentScene.rivershade3Color);
    Custom_Polygon({{568, 401}, {829, 395}, {1086, 410}, {790, 374}}, currentScene.rivershade3Color, -700, -50);
    Custom_Polygon({{568, 401}, {829, 395}, {1086, 410}, {790, 374}}, currentScene.rivershade3Color, 100, -100);
    Custom_Polygon({{568, 401}, {829, 395}, {1086, 410}, {790, 374}}, currentScene.rivershade3Color, -1200, -100);

    // type 4
    Custom_Polygon({{633, 399}, {895, 433}, {1216, 417}, {778, 399}}, currentScene.rivershade2Color, -500, 20);
    Custom_Polygon({{633, 399}, {895, 433}, {1216, 417}, {778, 399}}, currentScene.rivershade2Color, 200, -180);
    Custom_Polygon({{633, 399}, {895, 433}, {1216, 417}, {778, 399}}, currentScene.rivershade2Color, 800, -200);
    Custom_Polygon({{633, 399}, {895, 433}, {1216, 417}, {778, 399}}, currentScene.rivershade2Color, -800, -150);
    Custom_Polygon({{633, 399}, {895, 433}, {1216, 417}, {778, 399}}, currentScene.rivershade2Color, -1200, -150);
    Custom_Polygon({{633, 399}, {895, 433}, {1216, 417}, {778, 399}}, currentScene.rivershade2Color, -1200, -40);

    // type 5
    Custom_Polygon({{1248, 397}, {1446, 388}, {1676, 400}, {1425, 399}}, currentScene.rivershade4Color, 0, 50);
    Custom_Polygon({{1248, 397}, {1446, 388}, {1676, 400}, {1425, 399}}, currentScene.rivershade4Color, -700, 50);
    Custom_Polygon({{1248, 397}, {1446, 388}, {1676, 400}, {1425, 399}}, currentScene.rivershade4Color, -1200, 20);
    Custom_Polygon({{1248, 397}, {1446, 388}, {1676, 400}, {1425, 399}}, currentScene.rivershade4Color, -500, -10);

    glPopMatrix();
}
void Left1Cars()
{

    glMatrixMode(GL_MODELVIEW);
    //first car
    glPushMatrix();
    //glTranslatef(-200,0,0);
    glTranslatef(moveCarsXs-1100,200,0);
    Custom_Polygon({{24.5, 406.5},{12, 408},{11.5, 413},{12, 416.5},{13.2, 419},{16, 438},{22, 438},{47, 453},{50, 454},{82, 454},{87, 453},{111, 440},{115, 438},
                   {123, 436},{142, 431},{148, 422},{149, 419},{147.5, 415},{147.5, 406.5},{24.5, 406.5}},currentScene.car1Body);//car1body
    Custom_Polygon({{108, 438},{28, 438},{48, 450},{54, 452},{82, 452},{88, 450}},currentScene.car1Window);//window
    Custom_Polygon({{69, 452},{70, 438},{74, 438},{71, 452}},currentScene.car1WindowLine);
    Custom_Polygon({{14, 436},{28, 436},{22, 430},{16, 428},{14, 428.5},{13, 430}},currentScene.car1Light);
    Custom_Polygon({{141, 430.5},{130, 432},{134, 428},{140, 426},{145, 426}},currentScene.car1Light);

    glPushMatrix();
    Halfcircle(16,42.5,406.5,currentScene.car1TyreUp);
    glTranslatef(42.5,406.5,0);
    glRotatef(rotateWheels,0,0,1);
    glTranslatef(-42.5,-406.5,0);
    Fullcircle(12,42.5,406.5,currentScene.car1Tyre);
    FullcircleWithLines(7,42.5,406.5,currentScene.car1Body);
    Linestrip2({{36, 406},{49, 406}},currentScene.car1Body,2);
    Linestrip2({{42, 400},{42, 413}},currentScene.car1Body,2);
    Fullcircle(3.5,42.5,406.5,currentScene.car1Body);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(70,0,0);
    Halfcircle(16,42.5,406.5,currentScene.car1TyreUp);
    glTranslatef(42.5,406.5,0);
    glRotatef(rotateWheels,0,0,1);
    glTranslatef(-42.5,-406.5,0);
    Fullcircle(12,42.5,406.5,currentScene.car1Tyre);
    FullcircleWithLines(7,42.5,406.5,currentScene.car1Body);
    Linestrip2({{36, 406},{49, 406}},currentScene.car1Body,2);
    Linestrip2({{42, 400},{42, 413}},currentScene.car1Body,2);
    Fullcircle(3.5,42.5,406.5,currentScene.car1Body);
    glPopMatrix();
    glPopMatrix();



}
void Left2Car()
{

    //second cars
    glPushMatrix();
    //glTranslated(-350,55,0);
    glTranslatef(moveCarsXs-800,250,0);
    Custom_Polygon({{184.5, 351.5},{165, 354},{163, 365},{162, 384},{164, 387.5},{246, 386},{245, 350}},currentScene.car2Body);//body

    Custom_Polygon({{245, 350},{246, 386},{248, 400},{249, 403.5},{251, 405},{266.5, 405},{270, 404.5},{274, 403.5},{278, 402},{282, 400},
                  {284.5, 398.5},{299.5, 386.5},{307, 386},{315, 385},{321, 384},{326, 383},{332, 381},{336, 379},{337, 377},{337, 374},
                  {336, 367},{332, 349},{325, 348.5}},currentScene.car2Body);//body
    Custom_Polygon({{255, 385},{257, 402},{270, 401},{277, 398},{282, 394},{288, 389},{292, 383}},currentScene.car2Window);//window
    Linestrip2({{162, 387.5},{246, 386}},currentScene.car2Tyre,2);//lines
    Linestrip2({{246, 386},{245, 350}},currentScene.car2Tyre,2);//lines
    Linestrip2({{332, 349},{198, 351}},currentScene.car2Tyre,2);//lines
    Custom_Polygon({{162, 368},{166, 368},{168, 372},{168, 378},{166, 382},{162, 382}},currentScene.car1Light);//light
    Custom_Polygon({{164, 366},{159, 362},{160, 358},{161, 356},{164, 354},{171, 354},{169, 364},{167, 365}},currentScene.car2Tyre);
    Custom_Polygon({{337, 374},{331, 374},{331, 367},{336, 367}},currentScene.car2Light);

    glPushMatrix();
    Halfcircle(17,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheels,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    Fullcircle(3.5,198,351,currentScene.car2Tyre);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(100,-2,0);
    Halfcircle(17,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheels,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    Fullcircle(3.5,198,351,currentScene.car2Tyre);
    glPopMatrix();

    glPopMatrix();

}
void Left3Car(){

    //Thired car
    glPushMatrix();
    //glTranslatef(-500,5,0);
    glTranslatef(moveCarsXs-500,250,0);
    Custom_Polygon({{375.5, 437},{375, 444},{376, 446},{378, 446},{380, 444},{382, 442},{384, 437}},currentScene.car3seat);//seatleft
    Custom_Polygon({{402, 435},{402, 443},{402, 445},{402, 445},{406, 445},{408, 442},{409, 440},{411, 435}},currentScene.car3seat);
    Custom_Polygon({{363, 402},{352, 408},{352, 420},{354, 422},{352, 428},{354, 434},{358, 438},{436, 434},
                   {448, 434},{455, 433},{461, 432},{468, 430},{472, 427},{475, 423},{479, 416},{479, 413},{477, 407},
                   {474, 402},{461, 402}},currentScene.car3Body);//body
    Custom_Polygon({{436, 434},{418, 452},{417, 450},{416, 452},{419, 451},{430, 446},{437, 442},{448, 434}},currentScene.car3Body);
    Custom_Polygon({{354, 434},{352, 428},{353, 426},{358, 426},{361, 431},{359, 434},{354, 434}},currentScene.car3Light);
    Custom_Polygon({{477, 419},{469, 419},{464, 425},{471, 425},{475, 423}},currentScene.car3Light);
    Custom_Polygon({{479, 413},{479, 414},{473, 414},{471, 410},{471, 409},{472, 408},{477, 408}},currentScene.car3seat);

    glPushMatrix();
    glTranslatef(179,52,0);
    Halfcircle(15,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheels,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(250,52,0);
    Halfcircle(15,198,351,currentScene.car1TyreUp);
    glTranslatef(198,351,0);
    glRotatef(rotateWheels,0,0,1);
    glTranslatef(-198,-351,0);
    Fullcircle(13,198,351,currentScene.car1Tyre);
    FullcircleWithLines(8,198,351,currentScene.car1Body);
    Linestrip2({{194, 358},{202, 344}},currentScene.car1Body,2);
    Linestrip2({{194, 344},{202, 358}},currentScene.car1Body,2);
    Linestrip2({{191, 351},{205, 351}},currentScene.car1Body,2);
    glPopMatrix();
    glPopMatrix();

}

public:
void display()
{
    glClearColor(1, 1, 1, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    beach();
    background();
    background2();

    cloud();
    tree3();
    tree4();
    road();
    road1();
    Left1Cars();
    Left2Car();
    Left3Car();
    building1();

    building6();
    building4();
    building3();
    building2();
    building5();
    // building6();
    building7();
    mosque();

    chair1();
    chair2();
    chair3();
    chair4();
    door();
    tree();
    tree2();

    tree5();

    shop();
    shop2();
    moon();
    Riverflow();

    glFlush(); // Render now

    // glutSwapBuffers();
}
};
class TopView
{
    struct Custom_Color
{
    int r;
    int g;
    int b;
};


struct Scene
{
     string T_scene;
    Custom_Color roadShoulder;
    Custom_Color roadShoulder2;
    Custom_Color roadShoulder3;
    Custom_Color roadColor;
    Custom_Color roadDivider;
    Custom_Color roadPier1;
    Custom_Color roadPier2;
    Custom_Color roadShadow;
    Custom_Color landColor;
    Custom_Color landColor2;
    Custom_Color groundColor1;
    Custom_Color groundColor2;
    Custom_Color groundColor3;
    Custom_Color white;
    Custom_Color grass;
    Custom_Color plotGrass;
    Custom_Color orangeLight;
    Custom_Color orangeLight1;
    Custom_Color orangeDark;
    Custom_Color blue1;
    Custom_Color blue2;
    Custom_Color blue3;
    Custom_Color blue4;
    Custom_Color umbrella1;
    Custom_Color umbrella2;
    Custom_Color umbrella3;
    Custom_Color umbrella4;
    Custom_Color lightAsh;
    Custom_Color grassDark;
    Custom_Color ashDark;
    Custom_Color umbrella5;
    Custom_Color silver;
    Custom_Color greenroof;

};

Scene Day =
{
    "Day",
    {183, 183, 183},     //roadShoulder
    {200, 200, 200},     //roadShoulder2
    {160, 160, 160},     //roadShoulder3
    {102, 104, 103},     //roadColor
    {255, 230, 81},      //roadBorder;
    {183, 183, 183},     //roadPier1
    {148, 148, 146},     //roadPier2
    {84, 84, 84},        //roadShadow
    {142, 185, 33},     //landColor
    {151, 105, 71},      //landColor2
    {180, 122, 79},       // groundColor1;
    {73, 26, 10},       //groundColor2;
    {115, 66, 35},         //groundColor3;
    {255,255,255},      // White
    {120, 188, 39},      // grass
    {147, 191, 80},      // plotGrass
    {229, 141, 67},      // orangeLight
    {249, 154, 72},      // orangeLight1
    {204, 118, 57},      // orangeDark
    {56, 145, 205},      // blue1
    {38, 127, 190},      // blue2
    {79, 149, 208},      // blue3
    {95, 165, 217},      // blue4
    {187, 163, 51},      // umbrella1
    {202, 179, 51},      // umbrella2
    {229, 209, 62},      // umbrella3
    {200, 175, 46},      // umbrella4
    {186, 192, 192},      // lightAsh
    {117, 145, 58},      // grassDark
    {116, 135, 131},      // ashDark
    {247, 236, 71},      // umbrella5
    {188, 193, 194},      // silver
    {73, 97, 97},      // greenroof


};

Scene array[1] = {Day};
int daynighttracker = 0;
Scene currentScene = array[daynighttracker];


// Custom Functions
void Custom_Points1(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glPointSize(2);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++) {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}


void Custom_Points2(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glPointSize(4);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++) {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}


void Custom_Points3(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glPointSize(10);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POINTS);
    for (int i = 0; i < coord.size(); i++) {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}


void Custom_Polygon(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_POLYGON);
    for (int i = 0; i < coord.size(); i++) {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}



void Halfcircle(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255,255,255})
{
    glBegin(GL_POLYGON);
    for(int i=0; i<250; i++){
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+Tx, y+Ty);
    }
    glEnd();
}


void HalfcircleWithLines(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255,255,255})
{
    glPointSize(0.5);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POINTS);
    for(int i=0; i<250; i++){
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+Tx, y+Ty);
    }
    glEnd();
}



void HalfcircleBorder(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255,255,255})
{
    glPointSize(0.1);
    glBegin(GL_POINTS);
    for(int i=0; i<250; i++){
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 1.5708;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+Tx, y+Ty);
    }
    glEnd();
}



void Fullcircle(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255,255,255})
{
    glBegin(GL_POLYGON);
    for(int i=0; i<250; i++){
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 3.1416;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+Tx, y+Ty);
    }
    glEnd();
}



void FullcircleBorder(float radius, float Tx, float Ty, Custom_Color Custom_Color = {255,255,255})
{
    glLineWidth(3);
    glBegin(GL_LINES);
    for(int i=0; i<250; i++){
        glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
        float pi = 3.1416;
        float A = (i*2*pi)/250;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+Tx, y+Ty);
    }
    glEnd();
}




void Linestrip(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255}, float Tx = 0, float Ty = 0, float s = 1)
{
    glLineWidth(1);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_LINE_STRIP);
    for (int i = 0; i < coord.size(); i++) {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}


void Linestrip2(vector<pair<float, float>> coord, Custom_Color Custom_Color = {255,255,255},float lineWidth=1, float Tx = 0, float Ty = 0, float s = 1)
{
    glLineWidth(lineWidth);
    glColor3ub(Custom_Color.r, Custom_Color.g, Custom_Color.b);
    glBegin(GL_LINE_STRIP);
    for (int i = 0; i < coord.size(); i++) {
        glVertex2f(Tx + s * coord[i].first, Ty + s * coord[i].second);
    }
    glEnd();
}

void Road1()
{
    Custom_Polygon({{473,1080}, {886,1080}, {886,0}, {473,0}},currentScene.roadColor); //Road
    Linestrip2({{500,1080},{500,0}},currentScene.white,5);// Road Side Color (white)
    Linestrip2({{855,1080},{855,0}},currentScene.white,5);// Road Side Color (white)

     //road divider line
    Linestrip2({{675,0},{675,80}},currentScene.roadDivider,4);
    Linestrip2({{675,160},{675,240}},currentScene.roadDivider,4);
    Linestrip2({{675,320},{675,400}},currentScene.roadDivider,4);
    Linestrip2({{675,480},{675,560}},currentScene.roadDivider,4);
    Linestrip2({{675,640},{675,720}},currentScene.roadDivider,4);
    Linestrip2({{675,800},{675,880}},currentScene.roadDivider,4);
    Linestrip2({{675,960},{675,1040}},currentScene.roadDivider,4);
    Linestrip2({{675,1120},{675,1200}},currentScene.roadDivider,4);






     //red car start


      //red car body
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslated(0,moveRedCar,0);

       glBegin(GL_POLYGON);
    glColor3ub(190, 70, 60);
    glVertex2f(732, 1007);
    glVertex2f(767, 1007);
    glVertex2f(774, 994);
    glVertex2f(774, 904);
    glVertex2f(760, 894);
    glVertex2f(736, 894);
    glVertex2f(722, 904);
    glVertex2f(722, 994);
    glVertex2f(732, 1007);



     glEnd();


      //red car  orange top body

       glBegin(GL_POLYGON);
    glColor3ub(244, 89, 41);
    glVertex2f(730, 968);
    glVertex2f(730, 990);
    glVertex2f(740, 1000);
    glVertex2f(756, 1000);
    glVertex2f(766, 990);
    glVertex2f(766, 968);
    glVertex2f(758, 972);
    glVertex2f(740, 972);
    glVertex2f(730, 968);



     glEnd();



      //red car  blue glass front body

       glBegin(GL_POLYGON);
    glColor3ub(0, 59, 67);
    glVertex2f(730, 968);
    glVertex2f(736, 954);
    glVertex2f(762, 954);
    glVertex2f(766, 968);
    glVertex2f(758, 972);
    glVertex2f(740, 972);
    glVertex2f(730, 968);



     glEnd();


      //red car  blue glass left body

       glBegin(GL_POLYGON);
    glColor3ub(0, 59, 67);
    glVertex2f(728, 962);
    glVertex2f(735, 950);
    glVertex2f(735, 928);
    glVertex2f(728, 918);
    glVertex2f(728, 962);




     glEnd();


      //red car  blue glass right body

    glBegin(GL_POLYGON);
    glColor3ub(0, 59, 67);
    glVertex2f(764, 952);
    glVertex2f(770, 966);
    glVertex2f(770, 920);
    glVertex2f(764, 928);
    glVertex2f(764, 952);




     glEnd();

       //red car  blue glass back body

       glBegin(GL_POLYGON);
    glColor3ub(0, 59, 67);
    glVertex2f(738, 926);
    glVertex2f(760, 926);
    glVertex2f(766, 914);
    glVertex2f(760, 912);
    glVertex2f(740, 912);
    glVertex2f(734, 914);
    glVertex2f(738, 926);



     glEnd();


      //red car  mirror R

    glBegin(GL_POLYGON);
    glColor3ub(244, 89, 41);
    glVertex2f(774, 972);
    glVertex2f(786, 966);
    glVertex2f(774, 966);
    glVertex2f(774, 972);





     glEnd();


      //red car  mirror R

    glBegin(GL_POLYGON);
    glColor3ub(244, 89, 41);
    glVertex2f(722, 972);
    glVertex2f(722, 966);
    glVertex2f(712, 966);
    glVertex2f(722, 972);
    glEnd();
    glPopMatrix();


     //red car end





}



void Road2()
{
    Custom_Polygon({{1038,1080}, {1453,1080}, {1453,0}, {1038,0}},currentScene.roadColor); //Road
    Linestrip2({{1065,1080},{1065,0}},currentScene.white,5);// Road Side Color (white)
    Linestrip2({{1426,1080},{1426,0}},currentScene.white,5);// Road Side Color (white)

     //road divider line
    Linestrip2({{1240,0},{1240,80}},currentScene.roadDivider,4);
    Linestrip2({{1240,160},{1240,240}},currentScene.roadDivider,4);
    Linestrip2({{1240,320},{1240,400}},currentScene.roadDivider,4);
    Linestrip2({{1240,480},{1240,560}},currentScene.roadDivider,4);
    Linestrip2({{1240,640},{1240,720}},currentScene.roadDivider,4);
    Linestrip2({{1240,800},{1240,880}},currentScene.roadDivider,4);
    Linestrip2({{1240,960},{1240,1040}},currentScene.roadDivider,4);
    Linestrip2({{1240,1120},{1240,1200}},currentScene.roadDivider,4);


    //bus start
             //bus 1st border
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslated(0,moveBus+300,0);

     glBegin(GL_POLYGON);
    glColor3ub(198, 204, 204);
    glVertex2f(1257,1076);
    glVertex2f(1402,1076);
    glVertex2f(1402,865);
    glVertex2f(1257,865);
    glVertex2f(1257,1076);


    glEnd();


     glBegin(GL_POLYGON);
    glColor3ub(148, 149, 144);
    glVertex2f(1278,1065);
    glVertex2f(1377,1065);
    glVertex2f(1377,875);
    glVertex2f(1278,875);
    glVertex2f(1278,1065);


    glEnd();


     glBegin(GL_POLYGON);
    glColor3ub(244, 244, 244);
    glVertex2f(1282,1061);
    glVertex2f(1373,1061);
    glVertex2f(1373,879);
    glVertex2f(1282,879);
    glVertex2f(1282,1061);


    glEnd();


     glBegin(GL_POLYGON);
    glColor3ub(190, 188, 171);
    glVertex2f(1256,865);
    glVertex2f(1404,865);
    glVertex2f(1404,834);
    glVertex2f(1382,826);
    glVertex2f(1282,826);
    glVertex2f(1256,834);
    glVertex2f(1256,865);



    glEnd();


     glBegin(GL_POLYGON);
    glColor3ub(244, 244, 244);
    glVertex2f(1279,844);
    glVertex2f(1382,844);
    glVertex2f(1382,835);
    glVertex2f(1373,831);
    glVertex2f(1282,831);
    glVertex2f(1278,835);
    glVertex2f(1279,844);



    glEnd();


//head light big

     glBegin(GL_POLYGON);
    glColor3ub(7, 57, 77);
    glVertex2f(1292,852);
    glVertex2f(1371,852);
    glVertex2f(1382,844);
    glVertex2f(1279,844);
    glVertex2f(1292,852);




    glEnd();

//uper part of big head light

     glBegin(GL_POLYGON);
    glColor3ub(153, 151, 139);
    glVertex2f(1297,862);
    glVertex2f(1361,862);
    glVertex2f(1361,854);
    glVertex2f(1297,854);
    glVertex2f(1297,862);




    glEnd();


    //right head light


     glBegin(GL_POLYGON);
    glColor3ub(7, 57, 77);
    glVertex2f(1371,861);
    glVertex2f(1393,861);
    glVertex2f(1392,849);
    glVertex2f(1371,854);
    glVertex2f(1371,861);




    glEnd();


    //left head light


     glBegin(GL_POLYGON);
    glColor3ub(7, 57, 77);
    glVertex2f(1268,861);
    glVertex2f(1286,861);
    glVertex2f(1284,854);
    glVertex2f(1268,847);
    glVertex2f(1268,861);




    glEnd();


    //body ase line

     glBegin(GL_POLYGON);
    glColor3ub(147, 148, 143);
    glVertex2f(1278,1065);
    glVertex2f(1375,1062);
    glVertex2f(1375,875);
    glVertex2f(1278,875);
    glVertex2f(1278,1065);




    glEnd();



     //body white line

     glBegin(GL_POLYGON);
    glColor3ub(244, 244, 244);
    glVertex2f(1282,1061);
    glVertex2f(1373,1061);
    glVertex2f(1373,879);
    glVertex2f(1282,879);
    glVertex2f(1282,1061);




    glEnd();




    glBegin(GL_LINES);
    glColor3ub(156, 161, 155);
    glVertex2f(1265,1070);
    glVertex2f(1265,871);


    glEnd();



     glBegin(GL_LINES);
    glColor3ub(156, 161, 155);
    glVertex2f(1393,1070);
    glVertex2f(1393,871);






    glEnd();


    glPopMatrix();
    //bus end



    //blue car start

    //car blue body
    glPushMatrix();
    glTranslated(0,moveBlueCar,0);


     glBegin(GL_POLYGON);
    glColor3ub(76, 116, 188);
    glVertex2f(1100,920);
    glVertex2f(1120, 940);
    glVertex2f(1190,940);
    glVertex2f(1205,920);
    glVertex2f(1205,825);
    glVertex2f(1205,805);
    glVertex2f(1183,794);
    glVertex2f(1119,794);
    glVertex2f(1100,805);
    glVertex2f(1100,815);
    glVertex2f(1100,940);

     glEnd();


     //car left mirror

      glBegin(GL_POLYGON);
       glColor3ub(76, 116, 188);
       glVertex2f(1100,815);
      glVertex2f(1084,820);
      glVertex2f(1100,825);
      glVertex2f(1100,815);




       glEnd();


    //car right mirror


      glBegin(GL_POLYGON);
       glColor3ub(76, 116, 188);
       glVertex2f(1205, 825);
      glVertex2f(1221,820);
      glVertex2f(1205,815);
      glVertex2f(1205,825);



    glEnd();




    //car white top


     glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2f(1110,920);
    glVertex2f(1125, 930);
    glVertex2f(1185,930);
    glVertex2f(1200,920);
    glVertex2f(1200,840);
    glVertex2f(1180,840);
    glVertex2f(1180,848);
    glVertex2f(1128,848);
    glVertex2f(1128,840);
    glVertex2f(1110,840);
    glVertex2f(1110,910);





    glEnd();





    //car blue top

      glBegin(GL_POLYGON);
    glColor3ub(67, 133, 245);
    glVertex2f(1120,920);
    glVertex2f(1190,920);
    glVertex2f(1190,850);
    glVertex2f(1120,850);
    glVertex2f(1120,920);




    glEnd();






     glBegin(GL_POLYGON);
    glColor3ub(67, 133, 245);
    glVertex2f(1128,848);
    glVertex2f(1180,848);
    glVertex2f(1180,840);
    glVertex2f(1128,840);
    glVertex2f(1128,848);


     glEnd();



     //car left light

       glBegin(GL_POLYGON);
    glColor3ub(12, 64, 91);
    glVertex2f(1108, 838);
    glVertex2f(1126, 838);
     glVertex2f(1126, 836);
    glVertex2f(1114, 824);
    glVertex2f(1110, 826);
    glVertex2f(1108, 830);
     glVertex2f(1108, 838);


     glEnd();


      //car right light

       glBegin(GL_POLYGON);
    glColor3ub(12, 64, 91);
    glVertex2f(1180, 838);
    glVertex2f(1196, 838);
    glVertex2f(1198, 834);
    glVertex2f(1198, 830);
    glVertex2f(1194, 826);
     glVertex2f(1180, 834);
      glVertex2f(1180, 838);


     glEnd();


     //car big light


      glBegin(GL_POLYGON);
    glColor3ub(12, 64, 91);
    glVertex2f(1130, 835);
    glVertex2f(1175, 835);
    glVertex2f(1185, 825);
    glVertex2f(1180, 820);
    glVertex2f(1125, 820);
     glVertex2f(1120, 825);
      glVertex2f(1130, 835);


     glEnd();


      //car blue front bodyC


      glBegin(GL_POLYGON);
    glColor3ub(125, 168, 247);
    glVertex2f(1115, 820);
    glVertex2f(1190, 820);
    glVertex2f(1190, 810);
    glVertex2f(1175, 800);
    glVertex2f(1130, 800);
     glVertex2f(1115, 810);
      glVertex2f(1115, 820);


     glEnd();



     //blue car emd
     glPopMatrix();





}

void Bridge()
{
   Linestrip2({{0,671},{1920,671}},currentScene.roadShoulder3,15);//Light Shade
   Custom_Polygon({{0,661}, {1920,661}, {1920,430}, {0,430}},currentScene.roadColor); //Road
   Linestrip2({{0,420},{1920,420}},currentScene.roadShoulder3,15);//Light Shade

   Linestrip2({{0,640},{1920,640}},currentScene.white,5);// Road Side Color (white)
   Linestrip2({{0,451},{1920,451}},currentScene.white,5);// Road Side Color (white)

   //Pillars
   glBegin(GL_POLYGON);
   glColor3ub(130, 130, 138);
   glVertex2f(675,411);
   glVertex2f(760,411);
   glColor3ub(255,255,255);
   glVertex2f(760,384);
   glVertex2f(675,384);


   glEnd();



   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();

   glTranslatef(565,0,0);
   glBegin(GL_POLYGON);
   glColor3ub(130, 130, 138);
   glVertex2f(675,411);
   glVertex2f(760,411);
   glColor3ub(255,255,255);
   glVertex2f(760,384);
   glVertex2f(675,384);


   glEnd();
   glPopMatrix();



   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();

   glTranslatef(0,295,0);
   glBegin(GL_POLYGON);
   glColor3ub(255,255,255);

   glVertex2f(675,411);
   glVertex2f(760,411);
   glColor3ub(130, 130, 138);

   glVertex2f(760,384);
   glVertex2f(675,384);


   glEnd();
   glPopMatrix();



   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();

   glTranslatef(565,295,0);
   glBegin(GL_POLYGON);
   glColor3ub(255,255,255);

   glVertex2f(675,411);
   glVertex2f(760,411);
   glColor3ub(130, 130, 138);

   glVertex2f(760,384);
   glVertex2f(675,384);


   glEnd();
   glPopMatrix();
   //end pilars






   //road divider line
    Linestrip2({{0,545},{80,545}},currentScene.roadDivider,4);
    Linestrip2({{160,545},{240,545}},currentScene.roadDivider,4);
    Linestrip2({{320,545},{400,545}},currentScene.roadDivider,4);
    Linestrip2({{480,545},{560,545}},currentScene.roadDivider,4);
    Linestrip2({{640,545},{720,545}},currentScene.roadDivider,4);
    Linestrip2({{800,545},{880,545}},currentScene.roadDivider,4);
    Linestrip2({{960,545},{1040,545}},currentScene.roadDivider,4);
    Linestrip2({{1120,545},{1200,545}},currentScene.roadDivider,4);
    Linestrip2({{1280,545},{1360,545}},currentScene.roadDivider,4);
    Linestrip2({{1440,545},{1520,545}},currentScene.roadDivider,4);
    Linestrip2({{1600,545},{1680,545}},currentScene.roadDivider,4);
    Linestrip2({{1760,545},{1840,545}},currentScene.roadDivider,4);
    Linestrip2({{1900,545},{1920,545}},currentScene.roadDivider,4);


     //White Car on bridge Start

     //white car ase body


    glPushMatrix();
    glTranslated(moveWhiteCar,0,0);

    glBegin(GL_POLYGON);
    glColor3ub(212, 211, 197);
    glVertex2f(580, 617);
    glVertex2f(696, 617);
    glVertex2f(716, 604);
    glVertex2f(716, 560);
    glVertex2f(694, 547);
    glVertex2f(580, 547);
    glVertex2f(570,552);
    glVertex2f(560, 560);
    glVertex2f(560, 600);
    glVertex2f(570, 610);
    glVertex2f(580, 617);



     glEnd();

  //white car blue topL

       glBegin(GL_POLYGON);
    glColor3ub(9, 56, 72);
     glVertex2f(588, 606);
    glVertex2f(604, 598);
    glVertex2f(604, 566);
    glVertex2f(588, 556);
    glVertex2f(582, 566);
     glVertex2f(582, 594);
      glVertex2f(588, 606);


     glEnd();




     //white car start

     //white car blue topT

       glBegin(GL_POLYGON);
    glColor3ub(9, 56, 72);
    glVertex2f(590, 612);
    glVertex2f(655, 612);
    glVertex2f(642, 602);
    glVertex2f(606, 602);
    glVertex2f(590, 612);


     glEnd();


      //white car blue topR

       glBegin(GL_POLYGON);
    glColor3ub(9, 56, 72);
     glVertex2f(644, 598);
    glVertex2f(660, 608);
    glVertex2f(668, 600);
    glVertex2f(668, 568);
    glVertex2f(664, 556);
     glVertex2f(644, 564);
      glVertex2f(644, 598);


     glEnd();




     //white car blue topL

       glBegin(GL_POLYGON);
    glColor3ub(9, 56, 72);
    glVertex2f(606, 562);
    glVertex2f(642, 562);
    glVertex2f(660, 552);
    glVertex2f(594, 552);
    glVertex2f(606, 562);


     glEnd();


      //white car white front

       glBegin(GL_POLYGON);
    glColor3ub(248, 247, 237);
     glVertex2f(665, 608);
    glVertex2f(696, 608);
    glVertex2f(708, 596);
    glVertex2f(708, 564);
    glVertex2f(696, 556);
     glVertex2f(667, 556);
      glVertex2f(668, 568);
     glVertex2f(668, 600);
      glVertex2f(665, 608);


     glEnd();



      //white car white back

       glBegin(GL_POLYGON);
    glColor3ub(248, 247, 237);
     glVertex2f(570, 605);
    glVertex2f(586, 607);
    glVertex2f(582, 594);
    glVertex2f(582, 566);
    glVertex2f(587, 554);
     glVertex2f(570, 560);
      glVertex2f(570, 605);



     glEnd();



     //white car left mirror

       glBegin(GL_POLYGON);
    glColor3ub(9, 56, 72);
     glVertex2f(660, 617);
    glVertex2f(660, 626);
    glVertex2f(667, 619);
    glVertex2f(668, 617);
    glVertex2f(660, 617);


     glEnd();




      //white car right mirror

       glBegin(GL_POLYGON);
    glColor3ub(9, 56, 72);
     glVertex2f(660,547);
    glVertex2f(660, 536);
    glVertex2f(667, 543);
    glVertex2f(668, 547);
    glVertex2f(660,547);
    glEnd();

     //white car end

    glPopMatrix();





     //yollow car start



      //yollow car  white body

      glPushMatrix();
    glTranslated(moveYellowCar-300,0,0);

    glBegin(GL_POLYGON);
    glColor3ub(238, 234, 226);
    glVertex2f(370, 540);
    glVertex2f(490, 540);
    glVertex2f(490, 470);
    glVertex2f(370, 470);
     glVertex2f(370, 540);





     glEnd();




      //yollow car  yollow body body

    glBegin(GL_POLYGON);
    glColor3ub(242, 209, 66);
    glVertex2f(505, 545);
    glVertex2f(570, 545);
    glVertex2f(588, 536);
    glVertex2f(588, 478);
    glVertex2f(570, 465);
    glVertex2f(505, 465);
    glVertex2f(505, 545);




     glEnd();


       //yollow car  ase body

    glBegin(GL_POLYGON);
    glColor3ub(208, 207, 211);
    glVertex2f(370, 520);
    glVertex2f(490, 520);
    glVertex2f(490, 490);
    glVertex2f(370, 490);
     glVertex2f(370, 520);





     glEnd();


      //yollow car  blue top body

    glBegin(GL_POLYGON);
    glColor3ub(41, 107, 129);
    glVertex2f(414, 516);
    glVertex2f(442, 516);
    glVertex2f(446, 510);
    glVertex2f(446, 502);
    glVertex2f(442, 496);
    glVertex2f(414, 496);
    glVertex2f(410, 502);
    glVertex2f(410, 510);
    glVertex2f(414, 516);




     glEnd();


      //yollow  car  blue glass left

    glBegin(GL_POLYGON);
    glColor3ub(25, 68, 86);
    glVertex2f(527, 539);
    glVertex2f(542, 539);
    glVertex2f(544, 536);
    glVertex2f(527, 526);
    glVertex2f(527, 539);





     glEnd();

      //yollow  car  blue glass right

    glBegin(GL_POLYGON);
    glColor3ub(25, 68, 86);
    glVertex2f(530, 484);
    glVertex2f(548, 476);
    glVertex2f(544, 472);
    glVertex2f(530, 472);
    glVertex2f(530, 484);





     glEnd();



      //yollow  car  blue glass front

    glBegin(GL_POLYGON);
    glColor3ub(25, 68, 86);
    glVertex2f(534, 522);
    glVertex2f(547, 533);
    glVertex2f(550, 532);
    glVertex2f(550, 480);
    glVertex2f(547, 479);
     glVertex2f(534, 486);
      glVertex2f(534, 522);






     glEnd();



      //yollow  car  orange top

    glBegin(GL_POLYGON);
    glColor3ub(207, 102, 58);
    glVertex2f(514, 524);
    glVertex2f(530, 524);
    glVertex2f(532, 522);
    glVertex2f(532, 488);
    glVertex2f(530, 486);
     glVertex2f(514, 486);
      glVertex2f(514, 524);






     glEnd();



      //yollow  car  orange front

    glBegin(GL_POLYGON);
    glColor3ub(207, 102, 58);
    glVertex2f(550, 535);
    glVertex2f(570, 535);
    glVertex2f(580, 525);
    glVertex2f(580, 485);
    glVertex2f(570, 475);
     glVertex2f(550, 475);
       glVertex2f(550, 535);





     glEnd();



      //yollow  car  orange front

    glBegin(GL_POLYGON);
    glColor3ub(49, 53, 56);
    glVertex2f(505, 530);
    glVertex2f(490, 530);
    glVertex2f(490, 480);
    glVertex2f(505, 480);
   glVertex2f(505, 530);





     glEnd();





      //yollow  car  mirror r

    glBegin(GL_POLYGON);
    glColor3ub(254, 218, 83);
    glVertex2f(545, 465);
    glVertex2f(556, 465);
    glVertex2f(545, 456);
    glVertex2f(552, 465);





     glEnd();



      //yollow  car  mirror l

    glBegin(GL_POLYGON);
    glColor3ub(254, 218, 83);
    glVertex2f(545, 555);
    glVertex2f(556, 545);
     glVertex2f(545, 545);
    glVertex2f(545, 555);


     glEnd();

     glPopMatrix();
     //yollow car end





}

void DividerLand()
{
    Custom_Polygon({{885,0}, {1040,0}, {1040,1080}, {885,1080}},currentScene.grass); //grass


    //Lamp post -1

    Linestrip2({{960,992},{891,992}},currentScene.silver,4); //1
    Custom_Polygon({{892,1003}, {892,981}, {843,975}, {843,1007}},currentScene.silver); //1

    Linestrip2({{960,992},{1029,992}},currentScene.silver,4); //1.1
    Custom_Polygon({{1028,1003}, {1028,981}, {1075,975}, {1075,1007}},currentScene.silver); //1.1

    Fullcircle(15, 960, 992, currentScene.roadPier2); //1 & 1.1
    Fullcircle(4, 960, 992, currentScene.silver); //1 & 1.1


    //Lamp post -2

    Linestrip2({{960,992},{891,992}},currentScene.silver,4,0,-200); //2
    Custom_Polygon({{892,1003}, {892,981}, {843,975}, {843,1007}},currentScene.silver,0,-200); //2

    Linestrip2({{960,992},{1029,992}},currentScene.silver,4,0,-200); //2.1
    Custom_Polygon({{1028,1003}, {1028,981}, {1075,975}, {1075,1007}},currentScene.silver,0,-200); //2.1


    Fullcircle(15, 960, 792, currentScene.roadPier2 ); //2 & 2.1
    Fullcircle(4, 960, 792, currentScene.silver ); //2 & 2.1




    //Lamp post -3

    Linestrip2({{960,992},{891,992}},currentScene.silver,4,0,-642); //3
    Custom_Polygon({{892,1003}, {892,981}, {843,975}, {843,1007}},currentScene.silver,0,-642); //3

    Linestrip2({{960,992},{1029,992}},currentScene.silver,4,0,-642); //3.1
    Custom_Polygon({{1028,1003}, {1028,981}, {1075,975}, {1075,1007}},currentScene.silver,0,-642); //3.1

    Fullcircle(15, 960, 350, currentScene.roadPier2); //3 & 3.1
    Fullcircle(4, 960, 350, currentScene.silver); //3 & 3.1





    //Lamp post -4

    Linestrip2({{960,992},{891,992}},currentScene.silver,4,0,-842); //4
    Custom_Polygon({{892,1003}, {892,981}, {843,975}, {843,1007}},currentScene.silver,0,-842); //4

    Linestrip2({{960,992},{1029,992}},currentScene.silver,4,0,-842); //4.1
    Custom_Polygon({{1028,1003}, {1028,981}, {1075,975}, {1075,1007}},currentScene.silver,0,-842); //4.1

    Fullcircle(15, 960, 150, currentScene.roadPier2); //4 & 4.1
    Fullcircle(4, 960, 150, currentScene.silver); //4 & 4.1











}

void Plot1()
{
     Custom_Polygon({{0,1080}, {473,1080}, {473,672}, {0,672}},currentScene.plotGrass);//Plot-1 grass

     //house orange
     Custom_Polygon({{0,1065}, {416,1065}, {416,922}, {0,922}},currentScene.grassDark);// Shadow

     Custom_Polygon({{0,1054}, {380,1054}, {310,983}, {0,983}},currentScene.orangeLight);
     Custom_Polygon({{380,1054}, {310,983}, {380,912}},currentScene.orangeLight1);
     Custom_Polygon({{0,983}, {310,983}, {380,912},{0,912}},currentScene.orangeDark);

     //Entry house orange
     Custom_Polygon({{380,1008}, {473,1008}, {473,956}, {380,956}},currentScene.white);


     //house blue
     Custom_Polygon({{40,777}, {40,798}, {415,798}, {415,708},{40,708}},currentScene.grassDark);// Shadow

     Linestrip2({{96,842},{148,802},{213,773}},currentScene.white,14);//white road
     Custom_Polygon({{25,777}, {400,777}, {355,730}, {69,730}},currentScene.blue1);
     Custom_Polygon({{400,777}, {355,730}, {400,687}},currentScene.blue2);
     Custom_Polygon({{69,730},{355,730},{400,687}, {25,687}},currentScene.blue3);
     Custom_Polygon({{25,777},{69,730},{25,687}},currentScene.blue4);

     //Entry house Blue

     Custom_Polygon({{400,761}, {473,761}, {473,709}, {400,709}},currentScene.white);


     //Umbrella
     Custom_Polygon({{0,880}, {47,885}, {16,845}, {0,855}},currentScene.umbrella1);
     Custom_Polygon({{47,885}, {103,852}, {16,845}},currentScene.umbrella2);
     Custom_Polygon({{16,845}, {103,852},{73,812}},currentScene.umbrella3);
     Custom_Polygon({{16,845}, {73,812},{0,806},{0,823}},currentScene.umbrella1);
     Custom_Polygon({{16,845}, {0,823},{0,844}},currentScene.umbrella4);
     Custom_Polygon({{16,845}, {0,844},{0,855}},currentScene.umbrella3);


      Linestrip2({{0,882},{48,886},{106,853},{75,811},{0,804}},currentScene.white,4);


}

void Plot2()
{
     Custom_Polygon({{1453,1080}, {1920,1080}, {1920,672}, {1453,672}},currentScene.plotGrass);//Plot-2 grass



     Linestrip2({{1593,978},{1770,978},{1770,801},{1641,801},{1593,978}},currentScene.white,4);




     Custom_Polygon({{1486,1044}, {1863,1044}, {1863,920}, {1486,920}},currentScene.ashDark);//
     Custom_Polygon({{1832,943}, {1892,943}, {1892,847}, {1832,847}},currentScene.ashDark);//
     Custom_Polygon({{1832,847}, {1848,847}, {1848,787}, {1832,787}},currentScene.ashDark);//
     Custom_Polygon({{1690,1050}, {1690,1060}, {1803,1060}, {1803,1050}},currentScene.ashDark);//


     Custom_Polygon({{1640,1020}, {1824,1020}, {1824,717}, {1707,717}},currentScene.greenroof);//xx



     Custom_Polygon({{1597,976}, {1769,975}, {1769,805}, {1642,805}},currentScene.ashDark);//
     Custom_Polygon({{1832,926}, {1870,926}, {1870,879}, {1832,879}},currentScene.greenroof);//

     Custom_Polygon({{1736,709}, {1785,709}, {1785,691}, {1736,691}},currentScene.ashDark);//

     Custom_Polygon({{1731,784}, {1773,784}, {1773,756}, {1731,756}},currentScene.ashDark);//
     Custom_Polygon({{1789,784}, {1808,784}, {1808,756}, {1789,756}},currentScene.ashDark);//


     Custom_Polygon({{1740,960}, {1754,960}, {1754,823}, {1740,823}},currentScene.lightAsh);//
     Custom_Polygon({{1740,933}, {1754,920}, {1696,920}, {1696,933}},currentScene.lightAsh);//
     Custom_Polygon({{1740,933}, {1754,920}, {1696,920}, {1696,933}},currentScene.lightAsh,0,-35);//
     Custom_Polygon({{1740,933}, {1754,920}, {1696,920}, {1696,933}},currentScene.lightAsh,0,-70);//


     Fullcircle(15, 1690, 927, currentScene.lightAsh);
     Fullcircle(10, 1690, 927, currentScene.roadPier2);
     Fullcircle(15, 1690, 892, currentScene.lightAsh);
     Fullcircle(10, 1690, 892, currentScene.roadPier2);
     Fullcircle(15, 1690, 857, currentScene.lightAsh);
     Fullcircle(10, 1690, 857, currentScene.roadPier2);




     Fullcircle(15, 1534, 1011, currentScene.lightAsh);
     Fullcircle(15, 1596, 1011, currentScene.lightAsh);
     Fullcircle(15, 1534, 962, currentScene.lightAsh);


     Linestrip2({{1645,978},{1636,1023},{1829,1023},{1830,712},{1703,712},{1636,1023}},currentScene.white,4);
     Linestrip2({{1484,1046},{1865,1046},{1865,946},{1895,946},{1897,844},{1851,843},{1851,784},{1830,784},{1830,712},{1789,712},{1789,688},{1733,688},{1733,712},{1703,712},{1685,801},{1641,801},{1609,918},{1483,918},{1484,1046}},currentScene.white,4);
     Linestrip2({{1460,1022},{1500,1022},{1500,950},{1460,950},{1460,1022}},currentScene.white,4);
     Custom_Polygon({{1465,1017}, {1495,1017}, {1495,953}, {1465,953}},currentScene.greenroof);//nn












}

void Plot3()
{
     Custom_Polygon({{0,410}, {473,410}, {473,0}, {0,0}},currentScene.plotGrass);//Plot-3 grass

     //house-1

     Custom_Polygon({{216,392}, {192,392}, {192,157}, {394,157},{394,392}},currentScene.grassDark);//shade

     Custom_Polygon({{216,403}, {419,403}, {419,165}, {216,165}},currentScene.white);
     Custom_Polygon({{232,395}, {405,395}, {405,173}, {232,173}},currentScene.lightAsh);

     Custom_Polygon({{419,382}, {471,382}, {471,329}, {419,329}},currentScene.white); //Entarence

     Custom_Polygon({{356,374}, {377,374}, {377,352}, {356,352}},currentScene.ashDark);
     Custom_Polygon({{356,374}, {377,374}, {377,352}, {356,352}},currentScene.ashDark,0, -40);
     Custom_Polygon({{356,374}, {377,374}, {377,352}, {356,352}},currentScene.ashDark,0, -80);
     Custom_Polygon({{356,374}, {377,374}, {377,352}, {356,352}},currentScene.ashDark,0, -120);


     // house -2

     Custom_Polygon({{0,57}, {49,8}, {245,45},{233,58},{0,65}},currentScene.grassDark);//shade

     Linestrip2({{0,161},{127,185},{253,62},{46,22},{0,67}},currentScene.white,4); //white boarder
     Linestrip2({{0,160},{125,183},{248,63},{47,24},{0,70}},currentScene.lightAsh,4); //ash boarder

     Custom_Polygon({{0,160},{125,183},{41,149}, {0,148}},currentScene.umbrella1);
     Custom_Polygon({{41,149},{125,183},{248,63}, {132,60}},currentScene.umbrella3);
     Custom_Polygon({{132,60},{248,63},{47,24}},currentScene.umbrella5);
     Custom_Polygon({{0,148},{41,149},{132,60},{47,24},{0,70}},currentScene.umbrella2);


     Linestrip2({{301,166},{345,166}},currentScene.white,10); //ash boarder
     Linestrip2({{301,166},{345,166}},currentScene.lightAsh,10,0,-14);
     Linestrip2({{301,166},{345,166}},currentScene.white,10,0,-28);
     Linestrip2({{301,166},{345,166}},currentScene.lightAsh,10,0,-42);
     Linestrip2({{301,166},{345,166}},currentScene.white,10,0,-56);
     Linestrip2({{301,166},{345,166}},currentScene.lightAsh,10,0,-70);
     Linestrip2({{301,166},{345,166}},currentScene.white,10,0,-84);
     Linestrip2({{301,166},{345,166}},currentScene.lightAsh,10,0,-98);
     Linestrip2({{301,166},{345,166}},currentScene.white,10,0,-112);
     Linestrip2({{301,166},{345,166}},currentScene.lightAsh,10,0,-126);
     Linestrip2({{301,166},{345,166}},currentScene.white,10,0,-140);
     Linestrip2({{301,166},{345,166}},currentScene.lightAsh,10,0,-154);





}

void Plot4()
{
     Custom_Polygon({{1452,410}, {1920,410}, {1920,0}, {1452,0}},currentScene.plotGrass);//Plot-4 grass


     //House start

      //House shawdow

    glBegin(GL_POLYGON);
    glColor3ub(117, 145, 58);
    glVertex2f(1565, 395);
    glVertex2f(1510,370);
    glVertex2f(1510,320);
    glVertex2f(1490,320);
    glVertex2f(1490, 280);
    glVertex2f(1470, 260);
    glVertex2f(1470,20);
    glVertex2f(1680,20);
    glVertex2f(1680,80);
    glVertex2f(1680,395);





     glEnd();

     //house shawdow



      glBegin(GL_POLYGON);
    glColor3ub(117, 145, 580);
    glVertex2f(1852, 115);
    glVertex2f(1765,115);
    glVertex2f(1765,80);
    glVertex2f(1680,80);
    glVertex2f(1680, 20);
    glVertex2f(1852, 115);





     glEnd();


      //house shawdow



      glBegin(GL_POLYGON);
    glColor3ub(117, 145, 58);
    glVertex2f(1860,260);
    glVertex2f(1890,260);
    glVertex2f(1860,244);
   glVertex2f(1860,260);





     glEnd();




      //house shawdow



      glBegin(GL_POLYGON);
    glColor3ub(117, 145, 58);
    glVertex2f(1860,150);
    glVertex2f(1890,150);
    glVertex2f(1860,134);
   glVertex2f(1860,150);





     glEnd();







      //House out side  white border

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1765, 360);
    glVertex2f(1765, 395);
     glVertex2f(1565, 395);
     glVertex2f(1565, 80);
    glVertex2f(1765, 80);
     glVertex2f(1765, 360);




     glEnd();





      //House out side  white border

    glBegin(GL_POLYGON);
    glColor3ub(82, 88, 100);
    glVertex2f(1760, 360);
    glVertex2f(1760, 390);
     glVertex2f(1570, 390);
     glVertex2f(1570, 85);
    glVertex2f(1760, 85);
     glVertex2f(1760, 360);




     glEnd();






           //House white top

    glBegin(GL_POLYGON);
    glColor3ub(220, 220, 220);
    glVertex2f(1655, 360);
    glVertex2f(1860, 360);
     glVertex2f(1860, 115);
     glVertex2f(1655, 115);
     glVertex2f(1655, 360);




     glEnd();



           //House green top

    glBegin(GL_POLYGON);
    glColor3ub(71, 95, 96);
    glVertex2f(1664, 356);
    glVertex2f(1854, 356);
     glVertex2f(1854, 120);
     glVertex2f(1664, 120);
    glVertex2f(1664, 356);





     glEnd();

       //House low window white border

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1860,215);
    glVertex2f(1890, 215);
     glVertex2f(1890, 150);
     glVertex2f(1860, 150);
    glVertex2f(1860,215);





     glEnd();


      //House low window

    glBegin(GL_POLYGON);
    glColor3ub(81, 87, 99);
    glVertex2f(1860,155);
    glVertex2f(1885, 155);
     glVertex2f(1885, 210);
     glVertex2f(1860, 210);
    glVertex2f(1860,155);



     glEnd();



      //House low window white border

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1860,260);
    glVertex2f(1890, 260);
     glVertex2f(1890, 324);
     glVertex2f(1860, 324);
    glVertex2f(1860,260);





     glEnd();



      //House low window

    glBegin(GL_POLYGON);
    glColor3ub(81, 87, 99);
    glVertex2f(1860,320);
    glVertex2f(1885, 320);
     glVertex2f(1885, 264);
     glVertex2f(1860, 264);
    glVertex2f(1860,320);



     glEnd();


        //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1780, 318);
    glVertex2f(1804, 318);
     glVertex2f(1804, 306);
     glVertex2f(1780, 306);
    glVertex2f(1780, 318);




     glEnd();



        //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1780, 304);
    glVertex2f(1804, 304);
     glVertex2f(1804, 292);
     glVertex2f(1780, 292);
    glVertex2f(1780, 304);




     glEnd();



        //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1780, 231);
    glVertex2f(1804, 231);
     glVertex2f(1804, 220);
     glVertex2f(1780, 220);
    glVertex2f(1780, 231);




     glEnd();



     //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1780, 217);
    glVertex2f(1804, 217);
     glVertex2f(1804, 206);
     glVertex2f(1780, 206);
    glVertex2f(1780, 217);




     glEnd();



       //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1780, 172);
    glVertex2f(1804, 172);
     glVertex2f(1804, 160);
     glVertex2f(1780, 160);
    glVertex2f(1780, 172);




     glEnd();


       //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1780, 144);
    glVertex2f(1804, 144);
     glVertex2f(1804, 132);
     glVertex2f(1780, 132);
    glVertex2f(1780, 144);




     glEnd();



       //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1710, 144);
    glVertex2f(1734, 144);
     glVertex2f(1734, 132);
     glVertex2f(1710, 132);
    glVertex2f(1710, 144);




     glEnd();



       //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1710, 172);
    glVertex2f(1734, 172);
     glVertex2f(1734, 160);
     glVertex2f(1710, 160);
    glVertex2f(1710, 172);




     glEnd();


     //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1710, 231);
    glVertex2f(1734, 231);
     glVertex2f(1734, 220);
     glVertex2f(1710, 220);
    glVertex2f(1710, 231);




     glEnd();


     //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1710, 218);
    glVertex2f(1734, 218);
     glVertex2f(1734, 206);
     glVertex2f(1710, 206);
    glVertex2f(1710, 218);




     glEnd();


     //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1710, 318);
    glVertex2f(1734, 318);
     glVertex2f(1734, 306);
     glVertex2f(1710, 306);
    glVertex2f(1710, 318);




     glEnd();


      //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(206, 206, 205);
    glVertex2f(1710, 304);
    glVertex2f(1734, 304);
     glVertex2f(1734, 292);
     glVertex2f(1710, 292);
    glVertex2f(1710, 304);




     glEnd();

      //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(127, 127, 123);
    glVertex2f(1655, 325);
    glVertex2f(1625, 325);
     glVertex2f(1625, 260);
     glVertex2f(1655, 260);
     glVertex2f(1655, 325);




     glEnd();



         //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(85, 91, 103);
    glVertex2f(1655, 320);
    glVertex2f(1630, 320);
     glVertex2f(1630, 265);
     glVertex2f(1655, 265);
     glVertex2f(1655, 320);




     glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(127, 127, 123);
    glVertex2f(1655, 215);
    glVertex2f(1625, 215);
     glVertex2f(1625, 150);
     glVertex2f(1655, 150);
     glVertex2f(1655, 215);




     glEnd();




         //House top white dGN

    glBegin(GL_POLYGON);
    glColor3ub(85, 91, 103);
    glVertex2f(1655, 210);
    glVertex2f(1630,210);
    glVertex2f(1630, 155);
    glVertex2f(1655, 155);
    glVertex2f(1655, 210);

     glEnd();
}

public:
void display() {
	glClearColor(1, 1, 1, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);
	Road1();
	Road2();
	DividerLand();
	Plot1();
	Plot2();
	Plot3();
	Plot4();
	Bridge();
	glFlush();  // Render now

	glutSwapBuffers();
}
};
class Details
{
    void renderBitmapString(int x, int y, int z, void *font, char *string)
    {
        char *c;
        glRasterPos3f(x, y, z);
        for (c = string; *c != '\0'; c++)
        {
            glutBitmapCharacter(font, *c);
        }
    }
    void Custom_renderBitmapString(int x, int y, int z, void *font, char *string,int x1=0,int y1=0)
    {
        char *c;
        glRasterPos3f(x+x1, y+y1, z);
        for (c = string; *c != '\0'; c++)
        {
            glutBitmapCharacter(font, *c);
        }
    }

public:
    void display()
    {
        glClearColor(1, 1, 1, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        glColor3f(0.0, 0.0, 0.0);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Project Title: Dynamic city view");
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Computer Graphics Section: E",0,-40);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "ID",-170,-120);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Name",400,-120);

        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "22-45999-1",-210,-180);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Sazid Al-Abedin",360,-180);

        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "22-46006-1",-210,-215);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Md.Saiduzzaman Sohag",360,-215);

        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "22-46061-1",-210,-250);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Md.Sadman Hossain",360,-250);

        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "22-46062-1",-210,-285);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Nouroze Tarannum Anannya",360,-285);

        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Supervised by:",80,-390);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Mahfujur Rahman",50,-430);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Lecturer",120,-470);
        Custom_renderBitmapString(700, 900, 0, GLUT_BITMAP_TIMES_ROMAN_24, "Department of Computer Science",-60,-510);

        glFlush();
    }
};

Details d;
MainView mv;
SeaView sv;
TopView tv;


void display()
{
    d.display();
}
void display1()
{
    mv.display();
}
void display2()
{
    sv.display();
}
void display3()
{
    tv.display();
}
void KeyboardPress(unsigned char key, int x, int y)
{
    switch(key)
    {
    case 'd':
        currentScene = array[0];
        glutPostRedisplay();
        break;
    case 'n':
        currentScene = array[1];
        glutPostRedisplay();
        break;
    case '1':
        glutDisplayFunc(display1);
        glutPostRedisplay();
        break;
    case '2':
        glutDisplayFunc(display2);
        glutPostRedisplay();
        break;
     case '3':
        glutDisplayFunc(display3);
        glutPostRedisplay();
        break;

    }
}



int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(1920, 1080);


    glutInitWindowPosition(0, 0);
    glutCreateWindow("City View");

    glutKeyboardFunc(KeyboardPress);

    //this line must be below of glutCreateWindow();
    gluOrtho2D(0, 1920, 0, 1080);
    glutDisplayFunc(display);

    glutTimerFunc(20, AnimateRocket, 0);
    glutTimerFunc(20, AnimateSun, 0);
    glutTimerFunc(20, AnimateBoatLeft, 0);
    glutTimerFunc(20, AnimateWaterCurrentRight, 0);
    glutTimerFunc(20, RotateCarWheel, 0);
    glutTimerFunc(20, AnimateLeftCars1, 0);
    glutTimerFunc(20, AnimateCars1, 0);
    glutTimerFunc(20, AnimateCars2, 0);
    glutTimerFunc(20, AnimateCars3, 0);
    glutTimerFunc(20, AnimateMetroTrain,0);
    glutTimerFunc(20, AnimateWaterCurrentRights, 0);
    glutTimerFunc(20, AnimateLeftCarss, 0);
    glutTimerFunc(20,RotateCarWheels , 0);
    glutTimerFunc(20, AnimateBus, 0);
	glutTimerFunc(20, AnimateBlueCar, 0);
	glutTimerFunc(20, AnimateRedCar, 0);
	glutTimerFunc(20, AnimateWhiteCar, 0);
	glutTimerFunc(20, AnimateYellowCar, 0);

    glutMainLoop();
    return 0;
}
